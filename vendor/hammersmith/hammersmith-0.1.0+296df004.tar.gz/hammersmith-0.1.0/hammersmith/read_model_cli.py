"""CLI entry point for maintaining the SQLite read model."""
from __future__ import annotations

import argparse

from .catalog import default_catalog_path
from .config import AppConfig
from .model_identity import default_model_registry_path
from .model_paths import default_read_model_db_path
from .read_model import rebuild_read_model_db, sync_read_model_db

def run_db_command(config: AppConfig, args: argparse.Namespace) -> int:
    db_path = (args.db or default_read_model_db_path()).expanduser().resolve()
    log_path = (args.log or config.eval.jsonl_path).expanduser().resolve()
    catalog_path = (getattr(args, "catalog_file", None) or default_catalog_path()).expanduser().resolve()
    registry_path = (getattr(args, "registry", None) or default_model_registry_path()).expanduser().resolve()
    if args.db_command == "rebuild":
        result = rebuild_read_model_db(
            db_path,
            log_path,
            catalog_path=catalog_path,
            registry_path=registry_path,
        )
    else:
        result = sync_read_model_db(
            db_path,
            log_path,
            catalog_path=catalog_path,
            registry_path=registry_path,
        )
    action = "rebuild" if result.rebuilt else "sync"
    print(
        f"db {action}: {result.db_path} "
        f"attempts={result.attempts_inserted} skipped={result.skipped} offset={result.offset}"
    )
    return 0
