"""Model scoreboard aggregation, ranking, and cost estimation."""

from __future__ import annotations

from typing import Any

from .model_log import (
    group_model_log_tasks,
    median_int,
    model_log_failure_owner,
    model_log_int,
    model_log_row_engine,
    model_log_row_is_model_eligible,
    model_log_row_is_reserved_fixture,
    model_log_row_is_retry,
    model_log_row_is_unattributed,
    model_log_row_model,
    model_log_row_reasoning_effort,
    model_log_row_task_type,
    model_log_text,
    model_reasoning_effort_keys,
)

# Promotion ladder: 3+ tasks and first-try >= 2/3 ("2 of 3"). The exact
# fraction matters; 0.67 would misclassify a literal 2-of-3 record.
PROVEN_MIN_TASKS = 3
PROVEN_MIN_FIRST_TRY = 2 / 3


def model_scoreboard_tier(tasks: int, first_try_pass_rate: float) -> str:
    # Volume alone never proves a model: a 0% pass rate with many tasks is
    # evidence against, not for.
    if tasks >= PROVEN_MIN_TASKS and first_try_pass_rate >= PROVEN_MIN_FIRST_TRY:
        return "proven"
    return "probation"


def model_scoreboard_tier_rank(tier: str) -> int:
    return {"proven": 0, "probation": 1}.get(tier, 3)


def aggregate_model_scoreboard_rows(
    rows: list[dict[str, Any]],
    *,
    task_type: str | None = None,
    model: str | None = None,
) -> list[dict[str, Any]]:
    models: dict[tuple[str, str, str, bool], dict[str, Any]] = {}
    effort_keys = model_reasoning_effort_keys(rows)
    for task_rows in group_model_log_tasks(rows):
        ordered = sorted(
            task_rows,
            key=lambda row: (
                model_log_text(row.get("logged_at")),
                1 if model_log_row_is_retry(row) else 0,
            ),
        )
        first = ordered[0]
        final = ordered[-1]
        if model_log_row_is_reserved_fixture(final):
            continue
        group_engine = model_log_row_engine(final)
        group_model = model_log_row_model(final)
        group_task_type = model_log_row_task_type(final)
        unattributed = model_log_row_is_unattributed(final)
        reasoning_effort = None if unattributed else model_log_row_reasoning_effort(final)
        if model is not None and group_model != model:
            continue
        if task_type is not None and group_task_type != task_type:
            continue
        model_key = (group_engine, group_model, reasoning_effort or "", unattributed)
        model_entry = models.setdefault(
            model_key,
            {
                "engine": group_engine,
                "model": group_model,
                "reasoning_effort": reasoning_effort,
                "show_reasoning_effort": (group_engine, group_model, unattributed) in effort_keys,
                "unattributed": unattributed,
                "tasks": 0,
                "attempts": 0,
                "passed": 0,
                "failed": 0,
                "retries": 0,
                "first_try_passed": 0,
                "adjusted_tasks": 0,
                "adjusted_passed": 0,
                "adjusted_failed": 0,
                "adjusted_first_try_passed": 0,
                "excluded_infrastructure": 0,
                "excluded_contract": 0,
                "parent_accepted": 0,
                "parent_rejected_after_pass": 0,
                "last_seen": "",
                "_duration_ms": [],
                "_tokens": [],
                "_task_types": {},
            },
        )
        breakdown = model_entry["_task_types"].setdefault(
            group_task_type,
            {
                "task_type": group_task_type,
                "tasks": 0,
                "attempts": 0,
                "passed": 0,
                "failed": 0,
                "first_try_passed": 0,
                "adjusted_tasks": 0,
                "adjusted_passed": 0,
                "adjusted_failed": 0,
                "excluded_infrastructure": 0,
                "excluded_contract": 0,
                "parent_accepted": 0,
                "parent_rejected_after_pass": 0,
                "last_seen": "",
            },
        )
        passed = model_log_text(final.get("verdict")).upper() == "PASS"
        first_passed = model_log_text(first.get("verdict")).upper() == "PASS"
        eligible = model_log_row_is_model_eligible(final)
        failure_owner = model_log_failure_owner(final)
        parent_outcome = model_log_text(final.get("parent_outcome"))
        for target in (model_entry, breakdown):
            target["tasks"] += 1
            target["attempts"] += len(ordered)
            target["passed"] += 1 if passed else 0
            target["failed"] += 0 if passed else 1
            target["first_try_passed"] += 1 if first_passed else 0
            if eligible:
                target["adjusted_tasks"] += 1
                target["adjusted_passed"] += 1 if passed else 0
                target["adjusted_failed"] += 0 if passed else 1
            elif failure_owner in {"provider", "host"} or parent_outcome == "infrastructure":
                target["excluded_infrastructure"] += 1
            else:
                target["excluded_contract"] += 1
            target["parent_accepted"] += 1 if parent_outcome == "parent-accepted" else 0
            target["parent_rejected_after_pass"] += 1 if passed and parent_outcome == "parent-rejected" else 0
            logged_at = model_log_text(final.get("logged_at"))
            if logged_at > target["last_seen"]:
                target["last_seen"] = logged_at
        model_entry["retries"] += max(0, len(ordered) - 1)
        if eligible and first_passed:
            model_entry["adjusted_first_try_passed"] += 1
        duration_ms = model_log_int(final.get("duration_ms"))
        if duration_ms is not None:
            model_entry["_duration_ms"].append(duration_ms)
        for row in ordered:
            tokens = model_log_int(row.get("worker_tokens"))
            if tokens is not None:
                model_entry["_tokens"].append(tokens)

    finalized: list[dict[str, Any]] = []
    for entry in models.values():
        tasks_count = int(entry["tasks"])
        breakdown_rows = []
        for breakdown in entry["_task_types"].values():
            b_tasks = int(breakdown["tasks"])
            breakdown_rows.append({
                "task_type": breakdown["task_type"],
                "tasks": b_tasks,
                "attempts": breakdown["attempts"],
                "passed": breakdown["passed"],
                "failed": breakdown["failed"],
                "first_try_pass_rate": breakdown["first_try_passed"] / b_tasks if b_tasks else 0.0,
                "pass_rate": breakdown["passed"] / b_tasks if b_tasks else 0.0,
                "last_seen": breakdown["last_seen"],
                "adjusted_tasks": breakdown["adjusted_tasks"],
                "adjusted_passed": breakdown["adjusted_passed"],
                "adjusted_failed": breakdown["adjusted_failed"],
                "adjusted_pass_rate": (
                    breakdown["adjusted_passed"] / breakdown["adjusted_tasks"]
                    if breakdown["adjusted_tasks"] else 0.0
                ),
                "excluded_infrastructure": breakdown["excluded_infrastructure"],
                "excluded_contract": breakdown["excluded_contract"],
                "parent_accepted": breakdown["parent_accepted"],
                "parent_rejected_after_pass": breakdown["parent_rejected_after_pass"],
            })
        breakdown_rows.sort(key=lambda item: (-item["tasks"], item["task_type"]))
        adjusted_count = int(entry["adjusted_tasks"])
        first_try_rate = entry["adjusted_first_try_passed"] / adjusted_count if adjusted_count else 0.0
        tier = "unranked" if entry["unattributed"] else model_scoreboard_tier(adjusted_count, first_try_rate)
        finalized.append({
            "engine": entry["engine"],
            "model": entry["model"],
            "reasoning_effort": entry["reasoning_effort"],
            "show_reasoning_effort": entry["show_reasoning_effort"],
            "unattributed": entry["unattributed"],
            "tier": tier,
            "tasks": tasks_count,
            "attempts": entry["attempts"],
            "retries": entry["retries"],
            "passed": entry["passed"],
            "failed": entry["failed"],
            "first_try_pass_rate": entry["first_try_passed"] / tasks_count if tasks_count else 0.0,
            "pass_rate": entry["passed"] / tasks_count if tasks_count else 0.0,
            "raw_pass_rate": entry["passed"] / tasks_count if tasks_count else 0.0,
            "adjusted_tasks": adjusted_count,
            "adjusted_passed": entry["adjusted_passed"],
            "adjusted_failed": entry["adjusted_failed"],
            "adjusted_pass_rate": entry["adjusted_passed"] / adjusted_count if adjusted_count else 0.0,
            "adjusted_first_try_pass_rate": first_try_rate,
            "excluded_infrastructure": entry["excluded_infrastructure"],
            "excluded_contract": entry["excluded_contract"],
            "parent_accepted": entry["parent_accepted"],
            "parent_rejected_after_pass": entry["parent_rejected_after_pass"],
            "median_duration_ms": median_int(entry["_duration_ms"]),
            "median_tokens": median_int(entry["_tokens"]),
            "last_seen": entry["last_seen"],
            "task_types": breakdown_rows,
        })
    return finalized


def estimated_task_cost(row: dict[str, Any], catalog_model: dict[str, Any] | None) -> float | None:
    median_tokens = row.get("median_tokens")
    if median_tokens is None or catalog_model is None or catalog_model.get("variable_pricing"):
        return None
    if catalog_model.get("free"):
        return 0.0
    try:
        tokens = float(median_tokens)
        prompt_per_m = float(catalog_model.get("prompt_per_m") or 0)
        completion_per_m = float(catalog_model.get("completion_per_m") or 0)
    except (TypeError, ValueError):
        return None
    return tokens * ((prompt_per_m + completion_per_m) / 2.0) / 1_000_000


def model_sort_cost(row: dict[str, Any], catalog_model: dict[str, Any] | None) -> float:
    cost = estimated_task_cost(row, catalog_model)
    if cost is not None:
        return cost
    if row.get("median_tokens") is None:
        return 0.0
    return float("inf")


def order_model_scoreboard_rows(
    rows: list[dict[str, Any]],
    catalog_by_id: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    return sorted(
        rows,
        key=lambda row: (
            1 if row.get("unattributed") else 0,
            model_scoreboard_tier_rank(str(row.get("tier") or "")),
            -float(row.get("first_try_pass_rate") or 0),
            -float(row.get("pass_rate") or 0),
            model_sort_cost(row, catalog_by_id.get(str(row.get("model") or ""))),
            str(row.get("engine") or ""),
            str(row.get("model") or ""),
            str(row.get("reasoning_effort") or ""),
        ),
    )
