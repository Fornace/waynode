"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import json
import urllib.parse
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import Any

from hammersmith.state_io import read_json_object
from hammersmith.control_plane.evidence import RunEvidence
from hammersmith.control_plane.paths import PathCapability

from hammersmith.artifacts.core import artifact_content_type

def send_response_body(
    handler: BaseHTTPRequestHandler,
    status: HTTPStatus,
    body: bytes,
    *,
    content_type: str,
    no_store: bool = False,
) -> None:
    handler.send_response(status)
    handler.send_header("Content-Type", content_type)
    if no_store:
        handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)

def send_json_response(
    handler: BaseHTTPRequestHandler,
    data: dict[str, Any],
    *,
    status: HTTPStatus = HTTPStatus.OK,
) -> None:
    body = json.dumps(data, sort_keys=True).encode("utf-8")
    send_response_body(
        handler,
        status,
        body,
        content_type="application/json; charset=utf-8",
        no_store=True,
    )

def resolve_artifact_http_path(artifact_root: Path, request_path: str) -> Path | None:
    if request_path == "/artifacts/library.json":
        relative = "library.json"
    elif request_path.startswith("/artifacts/"):
        relative = request_path[len("/artifacts/") :]
    else:
        return None
    if not relative:
        return None
    decoded = urllib.parse.unquote(relative)
    root = artifact_root.resolve()
    return PathCapability((root,)).resolve_relative(root, decoded)

def task_log_path_from_state(state_path: Path, task_key: str) -> Path | None:
    try:
        evidence = RunEvidence(state_path.parent.parent, state_path.stem)
    except (FileNotFoundError, OSError, ValueError):
        return None
    return evidence.task_file(task_key, "log_path", "worker.log")

def run_state_path_for_id(state_dir: Path, run_id: str) -> Path | None:
    if not run_id:
        return None
    runs_root = (state_dir / "runs").resolve()
    candidate = (runs_root / f"{run_id}.json").resolve()
    if candidate.parent != runs_root:
        return None
    return candidate

def hud_task_log_path(state_dir: Path, run_id: str, task_key: str) -> Path | None:
    try:
        evidence = RunEvidence(state_dir, run_id)
    except (FileNotFoundError, OSError, ValueError):
        return None
    return evidence.task_file(task_key, "log_path", "worker.log")

def serve_artifact_path(handler: BaseHTTPRequestHandler, artifact_root: Path, path: str) -> bool:
    artifact_path = resolve_artifact_http_path(artifact_root, path)
    if artifact_path is None:
        return False
    try:
        if not artifact_path.is_file():
            raise FileNotFoundError
        body = artifact_path.read_bytes()
    except (FileNotFoundError, OSError):
        handler.send_error(HTTPStatus.NOT_FOUND)
        return True
    send_response_body(
        handler,
        HTTPStatus.OK,
        body,
        content_type=artifact_content_type(artifact_path),
        no_store=True,
    )
    return True
