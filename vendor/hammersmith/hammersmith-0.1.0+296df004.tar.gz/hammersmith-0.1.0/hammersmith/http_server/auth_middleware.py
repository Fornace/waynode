"""Authentication, role, origin, Fetch Metadata, and CSRF enforcement."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from collections import defaultdict, deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hammersmith.auth import AuthManager, User


class AuthMiddleware:
    def __init__(self, auth_manager: AuthManager) -> None:
        self.auth_manager = auth_manager
        self.auth_disabled = os.environ.get("HAMMERSMITH_NO_AUTH", "").lower() in (
            "1", "true", "yes"
        )
        self._csrf_secret = secrets.token_bytes(32)
        self._login_attempts: dict[str, deque[float]] = defaultdict(deque)
        self._login_lock = threading.Lock()

    @staticmethod
    def _error(handler: BaseHTTPRequestHandler, status: HTTPStatus, code: str) -> None:
        body = json.dumps({"error": {"code": code, "message": code.replace("_", " ")}}).encode()
        handler.send_response(status)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Cache-Control", "no-store")
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)

    def allowed_login_attempt(self, handler: BaseHTTPRequestHandler) -> bool:
        address = str(handler.client_address[0]) if handler.client_address else "loopback"
        now = time.monotonic()
        with self._login_lock:
            attempts = self._login_attempts[address]
            while attempts and now - attempts[0] > 60:
                attempts.popleft()
            if len(attempts) >= 8:
                return False
            attempts.append(now)
            return True

    def get_session_token(self, handler: BaseHTTPRequestHandler) -> str | None:
        cookie_header = handler.headers.get("Cookie", "")
        for cookie in cookie_header.split(";"):
            name, separator, value = cookie.strip().partition("=")
            if separator and name == "session" and value:
                return value
        auth_header = handler.headers.get("Authorization", "")
        if auth_header.startswith("Bearer ") and auth_header[7:]:
            return auth_header[7:]
        return None

    def user(self, handler: BaseHTTPRequestHandler) -> User | None:
        token = self.get_session_token(handler)
        return self.auth_manager.validate_session(token) if token else None

    def actor(self, handler: BaseHTTPRequestHandler) -> tuple[str, str]:
        user = self.user(handler)
        if user is None:
            return "anonymous", "viewer"
        role = user.role if user.role in {"viewer", "user", "admin"} else "viewer"
        return user.username, role

    def csrf_token(self, handler: BaseHTTPRequestHandler) -> str | None:
        token = self.get_session_token(handler)
        if token is None or self.user(handler) is None:
            return None
        return hmac.new(self._csrf_secret, token.encode("utf-8"), hashlib.sha256).hexdigest()

    @staticmethod
    def _allowed_authorities(handler: BaseHTTPRequestHandler) -> tuple[set[str], set[str]]:
        port = int(handler.server.server_address[1])
        hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        origins = {f"http://{host}" for host in hosts}
        return hosts, origins

    def require_valid_host(self, handler: BaseHTTPRequestHandler) -> bool:
        hosts, _origins = self._allowed_authorities(handler)
        if handler.headers.get("Host", "") not in hosts:
            self._error(handler, HTTPStatus.BAD_REQUEST, "invalid_host")
            return False
        return True

    def require_origin(self, handler: BaseHTTPRequestHandler) -> bool:
        if not self.require_valid_host(handler):
            return False
        _hosts, origins = self._allowed_authorities(handler)
        if handler.headers.get("Origin", "") not in origins:
            self._error(handler, HTTPStatus.FORBIDDEN, "invalid_origin")
            return False
        if handler.headers.get("Sec-Fetch-Site", "").casefold() == "cross-site":
            self._error(handler, HTTPStatus.FORBIDDEN, "cross_site_request_rejected")
            return False
        return True

    def is_authenticated(self, handler: BaseHTTPRequestHandler) -> bool:
        """Whether a request may access protected resources.

        Returns True in open mode (auth disabled or no admin created yet);
        otherwise whether a valid session user is present. Used by GET
        handlers to decide between serving content and redirecting to
        ``/login`` without emitting an error response.
        """
        if self.auth_disabled or not self.auth_manager.has_admin():
            return True
        return self.user(handler) is not None

    def require_auth(self, handler: BaseHTTPRequestHandler) -> bool:
        if self.auth_disabled or not self.auth_manager.has_admin():
            return True
        if self.user(handler) is None:
            self._error(handler, HTTPStatus.UNAUTHORIZED, "authentication_required")
            return False
        return True

    def require_mutation(
        self, handler: BaseHTTPRequestHandler, *, roles: set[str]
    ) -> bool:
        if not self.require_origin(handler):
            return False
        if self.auth_disabled or not self.auth_manager.has_admin():
            self._error(handler, HTTPStatus.FORBIDDEN, "authentication_required_for_mutation")
            return False
        if not self.require_auth(handler):
            return False
        _actor, role = self.actor(handler)
        if role not in roles:
            self._error(handler, HTTPStatus.FORBIDDEN, "role_is_read_only")
            return False
        expected = self.csrf_token(handler)
        supplied = handler.headers.get("X-CSRF-Token", "")
        if expected is None or not hmac.compare_digest(expected, supplied):
            self._error(handler, HTTPStatus.FORBIDDEN, "invalid_csrf_token")
            return False
        return True
