"""Authentication page handlers for the persistent HUD."""
from __future__ import annotations

from http import HTTPStatus
from http.server import BaseHTTPRequestHandler

from hammersmith.auth import AuthManager

from .login_page import LOGIN_HTML
from .responses import send_response_body


def serve_login_page(
    handler: BaseHTTPRequestHandler,
    auth_manager: AuthManager,
) -> None:
    """Serve the login page or first-user setup page."""
    html = LOGIN_HTML
    html = html.replace(
        "data.error || 'Login failed'",
        "(data.error && (data.error.message || data.error)) || 'Login failed'",
    )
    if not auth_manager.has_admin():
        html = html.replace(
            "<h1>Hammersmith Login</h1>",
            "<h1>Hammersmith Login</h1>"
            "<p>No user exists yet. Create one with:<br>"
            "<code>hammersmith user create admin --role admin</code></p>",
        )
    send_response_body(
        handler,
        HTTPStatus.OK,
        html.encode("utf-8"),
        content_type="text/html; charset=utf-8",
    )
