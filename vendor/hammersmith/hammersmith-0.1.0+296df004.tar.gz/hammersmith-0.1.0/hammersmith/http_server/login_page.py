"""Accessible login page HTML for the local Hammersmith dashboard."""

LOGIN_HTML = """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign in · Hammersmith</title>
  <link rel="stylesheet" href="/assets/hammersmith-login.css">
</head>
<body>
  <main class="login-shell">
    <section class="login-card" aria-labelledby="login-title">
      <p class="wordmark">Hammersmith</p>
      <h1 id="login-title">Sign in</h1>
      <p class="intro">Continue to the local workspace.</p>
      <form id="login-form" novalidate>
        <label for="username">Username</label>
        <input type="text" id="username" name="username" autocomplete="username" required aria-describedby="login-error">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" autocomplete="current-password" required aria-describedby="login-error">
        <button id="login-submit" type="submit">Sign in</button>
        <div id="login-error" class="error" role="alert" tabindex="-1" hidden></div>
      </form>
    </section>
  </main>
  <script src="/assets/hammersmith-contract.js"></script>
  <script src="/assets/hammersmith-login.js"></script>
</body>
</html>"""
