"""Bounded HTTP delivery of persisted run logs and evidence archives."""

from __future__ import annotations

import json
import urllib.parse
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import Any

from hammersmith.constants import WORKER_LOG_TAIL_BYTES
from hammersmith.control_plane.exports import ExportService
from hammersmith.control_plane.evidence import RunEvidence
from hammersmith.utils.activity import tail_file_text

from .responses import hud_task_log_path, send_response_body


def serve_run_export(
    handler: BaseHTTPRequestHandler,
    path: str,
    *,
    exporter: ExportService,
    auth_middleware: Any,
) -> bool:
    if not (path.startswith("/api/runs/") and path.endswith("/export")):
        return False
    if not auth_middleware.require_auth(handler):
        return True
    run_id = urllib.parse.unquote(path[len("/api/runs/"):-len("/export")])
    try:
        filename, body = exporter.build(run_id)
    except (FileNotFoundError, OSError, ValueError, json.JSONDecodeError):
        handler.send_error(HTTPStatus.NOT_FOUND)
        return True
    handler.send_response(HTTPStatus.OK)
    handler.send_header("Content-Type", "application/zip")
    handler.send_header("Content-Disposition", f'attachment; filename="{filename}"')
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)
    return True


def serve_run_log(
    handler: BaseHTTPRequestHandler,
    path: str,
    *,
    state_dir: Path,
    auth_middleware: Any,
) -> bool:
    if not path.startswith("/logs/"):
        return False
    if not auth_middleware.require_auth(handler):
        return True
    relative = path[len("/logs/"):]
    if "/" not in relative:
        handler.send_error(HTTPStatus.NOT_FOUND)
        return True
    run_id_raw, task_key_raw = relative.split("/", 1)
    run_id = urllib.parse.unquote(run_id_raw)
    task_key = urllib.parse.unquote(task_key_raw)
    log_path = hud_task_log_path(state_dir, run_id, task_key)
    if log_path is None:
        handler.send_error(HTTPStatus.NOT_FOUND)
        return True
    try:
        evidence = RunEvidence(state_dir, run_id)
        if evidence.sensitive_path(log_path):
            raise FileNotFoundError("sensitive log name")
        body = evidence.redact_text(
            tail_file_text(log_path, max_bytes=WORKER_LOG_TAIL_BYTES)
        ).encode("utf-8")
    except (FileNotFoundError, OSError, ValueError):
        handler.send_error(HTTPStatus.NOT_FOUND)
        return True
    send_response_body(
        handler,
        HTTPStatus.OK,
        body,
        content_type="text/plain; charset=utf-8",
        no_store=True,
    )
    return True
