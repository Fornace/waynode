"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from hammersmith.active_runs import read_active_runs_snapshot
from hammersmith.project_state import PROJECT_STALE_AFTER_S

from hammersmith.identity import product_identity, project_identity, project_selection_key
from hammersmith.utils.io import interprocess_lock

def read_json_object(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, json.JSONDecodeError, UnicodeDecodeError):
        return default
    return data if isinstance(data, dict) else default

def scan_hud_run_states(
    state_dir: Path, *, limit: int | None = 12
) -> list[dict[str, Any]]:
    runs_dir = state_dir / "runs"
    runs_root = runs_dir.resolve()
    runs: list[dict[str, Any]] = []
    with interprocess_lock(state_dir / ".state.lock"):
        try:
            paths = [path for path in runs_dir.glob("*.json") if path.is_file()]
        except OSError:
            return []

        def path_mtime(path: Path) -> float:
            try:
                return path.stat().st_mtime
            except OSError:
                return 0.0

        paths.sort(key=lambda item: (path_mtime(item), item.name), reverse=True)
        selected_paths = paths if limit is None else paths[:limit]
        for path in selected_paths:
            try:
                if path.resolve().parent != runs_root:
                    continue
            except OSError:
                continue
            data = read_json_object(path, {})
            if not data:
                continue
            run_id = data.get("run_id")
            if not isinstance(run_id, str) or not run_id.strip():
                run_id = path.stem
            project_raw = data.get("project")
            project = project_raw if isinstance(project_raw, str) else ""
            project_id, project_label = project_identity(project)
            enriched = dict(data)
            enriched["run_id"] = run_id
            enriched.setdefault("product", product_identity())
            enriched.setdefault("project", project)
            enriched["project_id"] = project_id
            enriched["project_label"] = project_label
            enriched["selection_key"] = project_selection_key(project_id, run_id)
            mtime = path_mtime(path)
            enriched["last_activity_at"] = datetime.fromtimestamp(
                mtime, tz=timezone.utc
            ).isoformat()
            enriched["_snapshot_mtime"] = mtime
            runs.append(enriched)
    return runs

def read_active_runs_file() -> dict[str, Any]:
    return read_active_runs_snapshot()

def _monitor_int(value: Any) -> int:
    if isinstance(value, bool):
        return 0
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError, OverflowError):
        return 0

def _monitor_float(value: Any) -> float:
    if isinstance(value, bool):
        return 0.0
    try:
        return max(0.0, float(value or 0.0))
    except (TypeError, ValueError, OverflowError):
        return 0.0

def _run_monitor_status(
    run: dict[str, Any], active: dict[str, dict[str, Any]], now_timestamp: float
) -> tuple[str, str, str | None]:
    """Return status, health, and a causal hint for one monitoring row."""
    run_id = str(run.get("run_id", ""))
    raw_state = str(run.get("state", "")).casefold()
    finished = bool(run.get("finished")) or raw_state == "finished"
    totals = run.get("totals") if isinstance(run.get("totals"), dict) else {}
    failed = _monitor_int(totals.get("fail", run.get("fail", 0)))
    if raw_state == "died":
        return "died", "degraded", "host_interrupted"
    if finished:
        return ("fail", "degraded", "task_failure") if failed else ("pass", "healthy", None)
    if run_id not in active:
        return "died", "degraded", "host_interrupted"
    age = max(0.0, now_timestamp - _monitor_float(run.get("_snapshot_mtime")))
    if age > PROJECT_STALE_AFTER_S:
        return "running", "stale", "worker_stall"
    return "running", "healthy", None

def build_projects_snapshot(
    state_dir: Path, *, now: datetime | None = None
) -> dict[str, Any]:
    """Build one deterministic, project-qualified view of every run state."""
    generated = now or datetime.now(timezone.utc)
    now_timestamp = generated.timestamp()
    active = read_active_runs_snapshot()
    runs = scan_hud_run_states(state_dir, limit=None)
    grouped: dict[str, dict[str, Any]] = {}
    for raw_run in runs:
        run_id = str(raw_run.get("run_id", "")).strip()
        if not run_id:
            continue
        project_raw = raw_run.get("project")
        project = project_raw if isinstance(project_raw, str) else ""
        project_id, project_label = project_identity(project)
        status, run_health, cause = _run_monitor_status(raw_run, active, now_timestamp)
        tasks_raw = raw_run.get("tasks")
        tasks = tasks_raw if isinstance(tasks_raw, list) else []
        task_counts = {
            "total": 0,
            "queued": 0,
            "running": 0,
            "pass": 0,
            "fail": 0,
            "done": 0,
        }
        causes: dict[str, int] = {}
        for task in tasks:
            if not isinstance(task, dict):
                continue
            task_counts["total"] += 1
            task_status = str(task.get("status", "queued")).casefold()
            if task_status in {"running", "verifying", "retrying"}:
                task_counts["running"] += 1
            elif task_status == "pass":
                task_counts["pass"] += 1
                task_counts["done"] += 1
            elif task_status in {"fail", "failed", "error", "timeout", "died"}:
                task_counts["fail"] += 1
                task_counts["done"] += 1
            else:
                task_counts["queued"] += 1
            failure_class = task.get("failure_class")
            if isinstance(failure_class, str) and failure_class:
                causes[failure_class] = causes.get(failure_class, 0) + 1
        if cause:
            causes[cause] = causes.get(cause, 0) + 1
        engine_health_raw = raw_run.get("engine_health")
        engine_health = engine_health_raw if isinstance(engine_health_raw, dict) else {}
        circuits: list[dict[str, Any]] = []
        for engine_name, health_raw in engine_health.items():
            if not isinstance(engine_name, str) or not isinstance(health_raw, dict):
                continue
            circuit_state = str(health_raw.get("state", "closed")).casefold()
            circuit_open = bool(health_raw.get("circuit_open")) or circuit_state in {
                "open",
                "tripped",
            }
            if not circuit_open:
                continue
            failure_class_raw = health_raw.get("failure_class")
            failure_class = (
                failure_class_raw
                if isinstance(failure_class_raw, str) and failure_class_raw
                else "provider_failure"
            )
            causes[failure_class] = causes.get(failure_class, 0) + 1
            circuits.append(
                {
                    "engine": engine_name,
                    "state": circuit_state,
                    "failure_class": failure_class,
                    "reason": str(health_raw.get("reason", "")),
                }
            )
        totals_raw = raw_run.get("totals")
        totals = totals_raw if isinstance(totals_raw, dict) else {}
        root_run_id_raw = raw_run.get("root_run_id")
        root_run_id = (
            root_run_id_raw.strip()
            if isinstance(root_run_id_raw, str) and root_run_id_raw.strip()
            else run_id
        )
        parent_raw = raw_run.get("parent_run_id")
        parent_run_id = parent_raw if isinstance(parent_raw, str) else ""
        replay_raw = raw_run.get("replay_of")
        replay_of = replay_raw if isinstance(replay_raw, str) else ""
        duplicate_raw = raw_run.get("duplicate_of")
        duplicate_of = duplicate_raw if isinstance(duplicate_raw, str) else ""
        last_activity_at = str(raw_run.get("last_activity_at", ""))
        run_row = {
            "run_id": run_id,
            "run_name": str(raw_run.get("run_name", run_id)),
            "selection_key": project_selection_key(project_id, run_id),
            "status": status,
            "health": run_health,
            "cause": cause,
            "root_run_id": root_run_id,
            "parent_run_id": parent_run_id,
            "replay_of": replay_of,
            "duplicate_of": duplicate_of,
            "tokens": _monitor_int(totals.get("tokens", raw_run.get("tokens", 0))),
            "elapsed_s": _monitor_float(raw_run.get("elapsed_s", 0)),
            "last_activity_at": last_activity_at,
            "task_counts": task_counts,
            "causes": causes,
            "circuit_open": bool(circuits),
            "circuits": circuits,
        }
        group = grouped.setdefault(
            project_id,
            {
                "project_id": project_id,
                "name": project_label,
                "label": project_label,
                "project": project,
                "health": "idle",
                "status": "idle",
                "counts": {
                    "runs": 0,
                    "live": 0,
                    "running": 0,
                    "pass": 0,
                    "passed": 0,
                    "fail": 0,
                    "failed": 0,
                    "died": 0,
                },
                "tasks": {
                    "total": 0,
                    "queued": 0,
                    "running": 0,
                    "pass": 0,
                    "fail": 0,
                    "done": 0,
                },
                "tokens": 0,
                "elapsed_s": 0.0,
                "last_activity_at": "",
                "causes": {},
                "circuit_open": False,
                "circuits": [],
                "root_run_ids": [],
                "run_ids": [],
                "roots": [],
                "runs": [],
            },
        )
        group["runs"].append(run_row)
        group["counts"]["runs"] += 1
        group["counts"][status] += 1
        if status == "pass":
            group["counts"]["passed"] += 1
        elif status == "fail":
            group["counts"]["failed"] += 1
        if status == "running":
            group["counts"]["live"] += 1
        for key, value in task_counts.items():
            group["tasks"][key] += value
        group["tokens"] += run_row["tokens"]
        group["elapsed_s"] = max(group["elapsed_s"], run_row["elapsed_s"])
        group["last_activity_at"] = max(group["last_activity_at"], last_activity_at)
        group["run_ids"].append(run_id)
        if circuits:
            group["circuit_open"] = True
            group["circuits"].extend(
                {"run_id": run_id, **circuit} for circuit in circuits
            )
        if root_run_id not in group["root_run_ids"]:
            group["root_run_ids"].append(root_run_id)
        for failure_class, count in causes.items():
            group["causes"][failure_class] = group["causes"].get(failure_class, 0) + count

    projects = list(grouped.values())
    for group in projects:
        group["runs"].sort(
            key=lambda item: (item["last_activity_at"], item["run_id"]), reverse=True
        )
        group["run_ids"].sort()
        group["root_run_ids"].sort()
        group["circuits"].sort(key=lambda item: (item["run_id"], item["engine"]))
        roots: list[dict[str, Any]] = []
        for root_run_id in group["root_run_ids"]:
            root_runs = [
                item for item in group["runs"] if item["root_run_id"] == root_run_id
            ]
            roots.append(
                {
                    "root_run_id": root_run_id,
                    "run_ids": sorted(item["run_id"] for item in root_runs),
                    "child_run_ids": sorted(
                        item["run_id"] for item in root_runs if item["parent_run_id"]
                    ),
                    "replay_run_ids": sorted(
                        item["run_id"] for item in root_runs if item["replay_of"]
                    ),
                }
            )
        group["roots"] = roots
        if (
            group["counts"]["died"]
            or group["counts"]["fail"]
            or group["tasks"]["fail"]
            or group["circuit_open"]
        ):
            group["health"] = "degraded"
            group["status"] = "attention"
        elif any(item["health"] == "stale" for item in group["runs"]):
            group["health"] = "stale"
            group["status"] = "attention"
        elif group["counts"]["running"]:
            group["health"] = "healthy"
            group["status"] = "running"
        elif group["counts"]["pass"]:
            group["health"] = "healthy"
            group["status"] = "passed"
        if group["causes"]:
            group["cause"] = min(
                group["causes"],
                key=lambda name: (-group["causes"][name], name),
            )
        else:
            group["cause"] = None
        group["elapsed_s"] = round(group["elapsed_s"], 1)
    projects.sort(key=lambda item: (item["label"].casefold(), item["project_id"]))
    return {
        "product": product_identity(),
        "generated_at": generated.isoformat(),
        "projects": projects,
    }
