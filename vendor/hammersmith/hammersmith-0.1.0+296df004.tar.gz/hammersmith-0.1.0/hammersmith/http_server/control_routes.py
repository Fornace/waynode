"""Authenticated read-only routes for the persistent control-plane server."""

from __future__ import annotations

from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Callable
import urllib.parse

from hammersmith.artifacts.library import artifact_library_path
from hammersmith.control_plane.bootstrap import BootstrapService
from hammersmith.control_plane.drafts import DraftNotFound
from hammersmith.control_plane.query import RunQueryService
from hammersmith.identity import product_identity
from hammersmith.state_io import read_json_object

from .post_handlers import ControlPlaneHandlers
from .responses import send_json_response
from .state import read_active_runs_file


def serve_control_get(
    handler: BaseHTTPRequestHandler,
    path: str,
    *,
    auth_middleware: Any,
    control: ControlPlaneHandlers,
    bootstrap: BootstrapService,
    query: RunQueryService,
    models_payload: Callable[[], dict[str, Any]],
    state_dir: Path,
) -> bool:
    if path == "/api/control/bootstrap":
        if auth_middleware.require_auth(handler):
            actor, role = auth_middleware.actor(handler)
            send_json_response(
                handler,
                bootstrap.build(
                    actor=actor,
                    role=role,
                    csrf_token=auth_middleware.csrf_token(handler),
                    model_evidence=models_payload(),
                ),
            )
        return True
    if path == "/api/drafts":
        if auth_middleware.require_auth(handler):
            actor, role = auth_middleware.actor(handler)
            drafts = [] if role == "viewer" else control.drafts.list(
                actor=actor, admin=role == "admin"
            )
            send_json_response(handler, {"drafts": drafts})
        return True
    if path.startswith("/api/drafts/"):
        if auth_middleware.require_auth(handler):
            actor, role = auth_middleware.actor(handler)
            try:
                draft = control.drafts.get(
                    urllib.parse.unquote(path[len("/api/drafts/"):]),
                    actor=actor,
                    admin=role == "admin",
                )
            except DraftNotFound:
                handler.send_error(HTTPStatus.NOT_FOUND)
            else:
                send_json_response(handler, draft)
        return True
    if path == "/api/runs":
        if auth_middleware.require_auth(handler):
            actor, role = auth_middleware.actor(handler)
            send_json_response(
                handler,
                {
                    "product": product_identity(),
                    "generated_at": datetime.now(timezone.utc).isoformat(),
                    "runs": query.list_runs(actor=actor, admin=role == "admin"),
                    "active": read_active_runs_file(),
                },
            )
        return True
    if path == "/api/projects":
        if auth_middleware.require_auth(handler):
            actor, role = auth_middleware.actor(handler)
            send_json_response(handler, query.projects(actor=actor, admin=role == "admin"))
        return True
    if path == "/api/models":
        if auth_middleware.require_auth(handler):
            send_json_response(handler, models_payload())
        return True
    if path == "/api/open-folder":
        send_json_response(
            handler,
            {"error": {"code": "post_required", "message": "post required"}},
            status=HTTPStatus.METHOD_NOT_ALLOWED,
        )
        return True
    if path == "/api/library":
        if auth_middleware.require_auth(handler):
            send_json_response(
                handler,
                read_json_object(artifact_library_path(state_dir), {"artifacts": {}}),
            )
        return True
    return False
