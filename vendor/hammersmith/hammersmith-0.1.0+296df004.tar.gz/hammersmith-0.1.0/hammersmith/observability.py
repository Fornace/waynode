from __future__ import annotations

import contextlib
import json
from datetime import datetime, timezone

from hammersmith.runtime import TaskRuntime, VerifyResult, WorkerResult
from hammersmith.constants import SHEPHERD_MODEL, VERIFY_METHOD
from hammersmith.failure_models import FailureAssessment
from hammersmith.model_log import model_log_text
from hammersmith.steering import resolve_steering_profile
from hammersmith.utils.io import append_text
from hammersmith.utils.models import (
    effective_reasoning_effort_from_command, resolved_task_model,
)


class RunnerObservabilityMixin:
    def _log_attempt(
        self,
        runtime: TaskRuntime,
        spec: str,
        retrying: bool,
        worker: WorkerResult,
        verify: VerifyResult,
        verdict: str,
        duration_ms: int,
        assessment: FailureAssessment | None = None,
    ) -> None:
        engine = self.config.engines.get(runtime.task.engine)
        resolved_model = resolved_task_model(
            runtime.task,
            engine,
            runtime.last_worker_command,
        )
        reported_model = model_log_text(worker.reported_model) or None
        mismatch = bool(reported_model and resolved_model and reported_model != resolved_model)
        stamped_model = reported_model or resolved_model
        expected_model = resolved_model if mismatch else None
        if mismatch:
            with contextlib.suppress(Exception):
                append_text(
                    runtime.log_path,
                    f"[hammersmith] identity: harness reported {reported_model} "
                    f"but manifest/config expected {resolved_model}\n",
                )
        reasoning_effort = effective_reasoning_effort_from_command(
            runtime.last_worker_command
        )
        notes_parts = [
            f"retry={'true' if retrying else 'false'}",
            f"worker_returncode={worker.returncode}",
            f"model={stamped_model}",
            f"task_type={runtime.task.task_type}",
        ]
        if worker.error:
            notes_parts.append(f"worker_error={worker.error}")
        if verify.missing_files:
            notes_parts.append(f"missing_expect_files={json.dumps(list(verify.missing_files))}")
        if verify.scope_violations:
            notes_parts.append(
                f"scope_violations={json.dumps(list(verify.scope_violations))}"
            )
        if verify.unexpected_paths:
            notes_parts.append(f"unexpected_paths={json.dumps(list(verify.unexpected_paths))}")
        if assessment is not None:
            notes_parts.extend(
                [
                    f"failure_category={assessment.category}",
                    f"failure_class={assessment.failure_class}",
                    f"failure_owner={assessment.failure_owner}",
                    f"model_eligible={'true' if assessment.model_eligible else 'false'}",
                    f"retry_decision={assessment.retry_decision}",
                ]
            )
        notes_parts.append("raw_check_output_first_2000_chars:")
        notes_parts.append(verify.raw_output_excerpt)
        with contextlib.suppress(Exception):
            self._write_steering_observation(
                runtime,
                resolved_model=stamped_model,
                retrying=retrying,
                worker=worker,
                verify=verify,
                verdict=verdict,
                duration_ms=duration_ms,
            )
        self.logger.log_attempt(
            {
                "run_id": self.run_id,
                "pattern": "ringer-py",
                "task_key": runtime.task.key,
                "spec": spec[:500],
                "worker_engine": runtime.task.engine,
                "shepherd_model": SHEPHERD_MODEL,
                "verify_method": VERIFY_METHOD,
                "verdict": verdict,
                "duration_ms": duration_ms,
                "worker_tokens": worker.tokens,
                "notes": "\n".join(notes_parts),
                "orchestrator": self.identity,
                "model": stamped_model,
                "reported_model": reported_model,
                "expected_model": expected_model,
                "reasoning_effort": reasoning_effort,
                "task_type": runtime.task.task_type,
                "retry": retrying,
                "failure_class": assessment.failure_class if assessment else None,
                "failure_category": assessment.category if assessment else None,
                "failure_owner": assessment.failure_owner if assessment else None,
                "model_eligible": assessment.model_eligible if assessment else True,
                "retry_decision": assessment.retry_decision if assessment else "none",
                "next_action": assessment.next_action if assessment else None,
                "failure_status": assessment.status if assessment else None,
                "missing_files": list(verify.missing_files),
                "unexpected_paths": list(verify.unexpected_paths),
                "observed_paths": list(verify.observed_paths),
                "failure_stage": verify.failure_stage,
            }
        )

    def _write_steering_observation(
        self,
        runtime: TaskRuntime,
        *,
        resolved_model: str,
        retrying: bool,
        worker: WorkerResult,
        verify: VerifyResult,
        verdict: str,
        duration_ms: int,
    ) -> None:
        steering_dir = self.config.steering.dir
        if steering_dir is None:
            return
        try:
            steering_state = runtime.steering
            if steering_state is None:
                profile = resolve_steering_profile(steering_dir, resolved_model)
                steering_state = {
                    "profile": profile.slug if profile else None,
                    "version": profile.profile_version if profile else None,
                    "rule_ids": [],
                }
                with self.lock:
                    runtime.steering = steering_state
            now = datetime.now(timezone.utc)
            row = {
                "ts": now.isoformat(),
                "source": "hammersmith",
                "run_id": self.run_id,
                "run_name": self.manifest.run_name,
                "task_key": runtime.task.key,
                "task_type": runtime.task.task_type,
                "engine": runtime.task.engine,
                "model": resolved_model,
                "profile": steering_state.get("profile"),
                "profile_version": steering_state.get("version"),
                "rules_injected": list(steering_state.get("rule_ids", [])),
                "attempt": runtime.attempts,
                "retry": retrying,
                "verdict": verdict,
                "duration_ms": duration_ms,
                "worker_tokens": worker.tokens,
                "check_excerpt": verify.raw_output_excerpt[:500],
            }
            path = (
                steering_dir
                / "observations"
                / "hammersmith"
                / f"{now.strftime('%Y-%m-%d')}.jsonl"
            )
            append_text(path, json.dumps(row, sort_keys=True) + "\n")
        except Exception as exc:
            with contextlib.suppress(Exception):
                append_text(
                    runtime.log_path,
                    f"[hammersmith] steering: observation write failed {exc}\n",
                )
