"""Read and enrich persisted run-state snapshots."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .identity import product_identity, project_identity, project_selection_key
from .state_io import interprocess_lock, read_json_object


def scan_run_states(state_dir: Path) -> list[dict[str, Any]]:
    """Best-effort scan of every run state file, for the multi-run index artifact."""
    runs_dir = state_dir / "runs"
    entries: list[dict[str, Any]] = []
    try:
        paths = list(runs_dir.glob("*.json"))
    except OSError:
        return entries
    for path in paths:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(data, dict):
            continue
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
        entries.append(
            {
                "run_id": data.get("run_id", path.stem),
                "run_name": data.get("run_name", "ringer"),
                "identity": data.get("identity", "unknown"),
                "state": data.get("state", "finished" if data.get("finished") else "live"),
                "pass": data.get("pass", 0),
                "fail": data.get("fail", 0),
                "elapsed_s": data.get("elapsed_s", 0),
                "started_at": data.get("started_at", ""),
                "artifact_path": data.get("artifact_path"),
                "report_path": data.get("report_path"),
                "report_ready": data.get("report_ready", False),
                "mtime": mtime,
            }
        )
    entries.sort(key=lambda item: item["mtime"], reverse=True)
    return entries


def scan_hud_run_states(
    state_dir: Path, *, limit: int | None = 12
) -> list[dict[str, Any]]:
    runs_dir = state_dir / "runs"
    runs: list[dict[str, Any]] = []
    with interprocess_lock(state_dir / ".state.lock"):
        try:
            paths = [path for path in runs_dir.glob("*.json") if path.is_file()]
        except OSError:
            return []

        def path_mtime(path: Path) -> float:
            try:
                return path.stat().st_mtime
            except OSError:
                return 0.0

        paths.sort(key=lambda item: (path_mtime(item), item.name), reverse=True)
        selected_paths = paths if limit is None else paths[:limit]
        for path in selected_paths:
            data = read_json_object(path, {})
            if not data:
                continue
            run_id = data.get("run_id")
            if not isinstance(run_id, str) or not run_id.strip():
                run_id = path.stem
            project_raw = data.get("project")
            project = project_raw if isinstance(project_raw, str) else ""
            project_id, project_label = project_identity(project)
            enriched = dict(data)
            enriched["run_id"] = run_id
            enriched.setdefault("product", product_identity())
            enriched.setdefault("project", project)
            enriched["project_id"] = project_id
            enriched["project_label"] = project_label
            enriched["selection_key"] = project_selection_key(project_id, run_id)
            mtime = path_mtime(path)
            enriched["last_activity_at"] = datetime.fromtimestamp(
                mtime, tz=timezone.utc
            ).isoformat()
            enriched["_snapshot_mtime"] = mtime
            runs.append(enriched)
    return runs
