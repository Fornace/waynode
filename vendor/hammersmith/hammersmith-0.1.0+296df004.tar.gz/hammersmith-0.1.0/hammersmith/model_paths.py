"""Default paths and read-model selection policy."""
from pathlib import Path

from .state_io import hammersmith_home

MODEL_SCOREBOARD_RUN_NAME = "model-scoreboard"
MODEL_SCOREBOARD_IDENTITY = "hammersmith-models"

def default_model_notes_path() -> Path:
    return Path(__file__).resolve().parents[1] / "docs" / "MODEL-NOTES.md"

def default_model_registry_path() -> Path:
    return Path(__file__).resolve().parents[1] / "registry" / "model-identity.toml"

def default_read_model_db_path() -> Path:
    return hammersmith_home() / "hammersmith.db"

def should_use_read_model_db(
    *,
    log_path: Path,
    default_log_path: Path,
    explicit_db: bool,
) -> bool:
    if explicit_db:
        return True
    return log_path.expanduser().resolve() == default_log_path.expanduser().resolve()
