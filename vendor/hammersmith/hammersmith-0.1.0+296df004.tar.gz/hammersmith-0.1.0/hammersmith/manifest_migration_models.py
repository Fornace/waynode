"""Models and conservative detection helpers for manifest migration."""
from __future__ import annotations

import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .manifest_checks import strip_shell_comments

MIGRATION_REVIEW_FIELDS = (
    "required_inputs",
    "expected_outputs",
    "forbidden_paths",
    "input_patches",
    "shared_check",
)
MIGRATION_SHELL_EXECUTABLES = frozenset(
    {
        "bash",
        "bun",
        "cargo",
        "deno",
        "git",
        "go",
        "make",
        "node",
        "npm",
        "npx",
        "pnpm",
        "python",
        "python3",
        "pytest",
        "sh",
        "uv",
        "yarn",
    }
)


@dataclass(frozen=True)
class ManifestMigrationIssue:
    location: str
    message: str
    required_action: str

    def as_dict(self) -> dict[str, str]:
        return {
            "location": self.location,
            "message": self.message,
            "required_action": self.required_action,
        }


@dataclass(frozen=True)
class ManifestMigrationResult:
    manifest: dict[str, Any]
    alias_changes: tuple[str, ...]
    manual_translations: tuple[ManifestMigrationIssue, ...]
    review: dict[str, str]

    @property
    def blocked(self) -> bool:
        return bool(self.manual_translations)


def migration_path_token(value: Any, *, allow_glob: bool = False) -> bool:
    """Conservatively identify a machine path, never free-form prose.

    Paths containing whitespace are deliberately treated as ambiguous even though
    some filesystems allow them. A migration operator must review those rather than
    letting this compatibility tool guess whether a sentence is a path.
    """
    if not isinstance(value, str):
        return False
    clean = value.strip()
    if not clean or clean != value or any(char.isspace() for char in clean):
        return False
    if "\x00" in clean or "://" in clean or clean.startswith("-"):
        return False
    if any(char in clean for char in "*?["):
        return allow_glob
    path = Path(clean)
    return (
        path.is_absolute()
        or clean.startswith(("./", "../", "~/"))
        or "/" in clean
        or "\\" in clean
        or bool(path.suffix)
    )


def migration_executable_check(value: Any) -> bool:
    """Require positive shell-command evidence instead of accepting prose.

    A custom check remains expressible as an explicit script path. This list is
    intentionally conservative: an unrecognized command is a manual migration,
    not an invitation to infer executable intent from natural language.
    """
    if not isinstance(value, str) or not value.strip():
        return False
    command = strip_shell_comments(value).replace("\n", " ; ").strip()
    if not command:
        return False
    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=";&|")
        lexer.whitespace_split = True
        lexer.commenters = ""
        tokens = list(lexer)
    except ValueError:
        return False
    command_position = True
    for token in tokens:
        if token in {";", "&&", "||", "|", "&"}:
            command_position = True
            continue
        if not command_position:
            continue
        if "=" in token:
            variable_name, _, _ = token.partition("=")
            if variable_name.isidentifier():
                continue
        if token in MIGRATION_SHELL_EXECUTABLES:
            return True
        if token.startswith(("./", "../", "/", "~/")) and migration_path_token(token):
            return True
        command_position = False
    return False


def _migration_issue(
    issues: list[ManifestMigrationIssue],
    location: str,
    message: str,
    required_action: str,
) -> None:
    issues.append(
        ManifestMigrationIssue(
            location=location,
            message=message,
            required_action=required_action,
        )
    )
