"""OpenRouter catalog normalization, change detection, and refresh."""

from __future__ import annotations

import json
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from .catalog_storage import append_catalog_events, atomic_write_json, catalog_refresh_lock
from .identity import environment_setting

STATE_DIR_NAME = ".hammersmith"
DEFAULT_CATALOG_SOURCE = "https://openrouter.ai/api/v1/models"
CATALOG_FETCH_TIMEOUT_S = 5


def hammersmith_home() -> Path:
    value = environment_setting("HOME")
    if value and value.strip():
        return Path(value).expanduser().resolve()
    return (Path.home() / STATE_DIR_NAME).resolve()


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def default_catalog_path() -> Path:
    return hammersmith_home() / "openrouter-catalog.json"


def catalog_changes_path(snapshot_path: Path) -> Path:
    text = str(snapshot_path)
    if text.endswith(".json"):
        return Path(text[:-5] + ".changes.jsonl")
    return snapshot_path.with_name(snapshot_path.name + ".changes.jsonl")


def catalog_decimal(value: Any) -> Decimal:
    if value is None:
        return Decimal("0")
    try:
        return Decimal(str(value).strip() or "0")
    except (InvalidOperation, ValueError):
        return Decimal("0")


def catalog_decimal_or_none(value: Any) -> Decimal | None:
    if value is None:
        return None
    try:
        text = str(value).strip()
        if not text:
            return None
        return Decimal(text)
    except (InvalidOperation, ValueError):
        return None


def catalog_per_m(value: Any) -> float:
    return float(catalog_decimal(value) * Decimal("1000000"))


def catalog_per_m_decimal(value: Decimal) -> float:
    return float(value * Decimal("1000000"))


def catalog_price_equal(left: Any, right: Any) -> bool:
    return catalog_decimal(left) == catalog_decimal(right)


def catalog_price_is_negative(value: Any) -> bool:
    return catalog_decimal(value) < 0


def normalize_catalog_model(raw: dict[str, Any], *, fetched_at: str) -> dict[str, Any]:
    pricing = raw.get("pricing")
    pricing_obj = pricing if isinstance(pricing, dict) else {}
    architecture = raw.get("architecture")
    architecture_obj = architecture if isinstance(architecture, dict) else {}
    model_id = str(raw.get("id", "")).strip()
    prompt_price = catalog_decimal_or_none(pricing_obj.get("prompt"))
    completion_price = catalog_decimal_or_none(pricing_obj.get("completion"))
    pricing_unknown = prompt_price is None or completion_price is None
    variable_pricing = pricing_unknown or prompt_price < 0 or completion_price < 0
    prompt_per_m = None if variable_pricing else catalog_per_m_decimal(prompt_price)
    completion_per_m = None if variable_pricing else catalog_per_m_decimal(completion_price)
    is_free = not variable_pricing and (
        model_id.endswith(":free")
        or (prompt_price == 0 and completion_price == 0)
    )
    if model_id.endswith(":free"):
        is_free = True
    context_length_raw = raw.get("context_length")
    try:
        context_length = int(context_length_raw)
    except (TypeError, ValueError):
        context_length = 0
    return {
        "id": model_id,
        "name": str(raw.get("name", "")).strip() or model_id,
        "context_length": context_length,
        "modality": str(architecture_obj.get("modality", "")).strip(),
        "pricing": dict(pricing_obj),
        "prompt_per_m": prompt_per_m,
        "completion_per_m": completion_per_m,
        "variable_pricing": variable_pricing,
        "pricing_unknown": pricing_unknown,
        "free": is_free,
        "fetched_at": fetched_at,
    }


def normalize_catalog_payload(payload: dict[str, Any], *, fetched_at: str) -> list[dict[str, Any]]:
    data = payload.get("data")
    if not isinstance(data, list):
        raise ValueError("catalog source must have a JSON object with a data array")
    models: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        model = normalize_catalog_model(item, fetched_at=fetched_at)
        if model["id"]:
            models.append(model)
    return sorted(models, key=catalog_sort_key)


def catalog_sort_key(model: dict[str, Any]) -> tuple[bool, float, str]:
    variable_pricing = bool(model.get("variable_pricing"))
    return (
        variable_pricing,
        float("inf")
        if variable_pricing
        else float(model.get("prompt_per_m") or 0) + float(model.get("completion_per_m") or 0),
        str(model.get("id") or ""),
    )


def fetch_catalog_payload(source: str, *, timeout: float = CATALOG_FETCH_TIMEOUT_S) -> dict[str, Any]:
    parsed = urllib.parse.urlparse(source)
    if parsed.scheme in {"http", "https"}:
        request = urllib.request.Request(source, headers={"User-Agent": "hammersmith"})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    else:
        payload = json.loads(Path(source).expanduser().read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("catalog source must be a JSON object")
    return payload


def load_catalog_snapshot(path: Path) -> list[dict[str, Any]]:
    try:
        data = json.loads(path.expanduser().read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    if isinstance(data, dict):
        models = data.get("models")
    else:
        models = data
    if not isinstance(models, list):
        return []
    return [item for item in models if isinstance(item, dict)]


def catalog_event_model_details(model: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": model.get("name", ""),
        "prompt_per_m": model.get("prompt_per_m", 0),
        "completion_per_m": model.get("completion_per_m", 0),
        "variable_pricing": bool(model.get("variable_pricing")),
        "pricing_unknown": bool(model.get("pricing_unknown")),
        "free": bool(model.get("free")),
        "context_length": model.get("context_length", 0),
        "modality": model.get("modality", ""),
    }


def diff_catalog_snapshots(
    old_models: list[dict[str, Any]],
    new_models: list[dict[str, Any]],
    *,
    ts: str,
) -> list[dict[str, Any]]:
    old_by_id = {str(model.get("id")): model for model in old_models if model.get("id")}
    new_by_id = {str(model.get("id")): model for model in new_models if model.get("id")}
    events: list[dict[str, Any]] = []
    for model_id in sorted(new_by_id.keys() - old_by_id.keys()):
        model = new_by_id[model_id]
        events.append({"ts": ts, "kind": "added", "id": model_id, **catalog_event_model_details(model)})
    for model_id in sorted(old_by_id.keys() - new_by_id.keys()):
        model = old_by_id[model_id]
        events.append({"ts": ts, "kind": "removed", "id": model_id, **catalog_event_model_details(model)})
    for model_id in sorted(old_by_id.keys() & new_by_id.keys()):
        old = old_by_id[model_id]
        new = new_by_id[model_id]
        old_prompt = old.get("prompt_per_m", 0)
        new_prompt = new.get("prompt_per_m", 0)
        old_completion = old.get("completion_per_m", 0)
        new_completion = new.get("completion_per_m", 0)
        old_free = bool(old.get("free"))
        new_free = bool(new.get("free"))
        old_variable = bool(old.get("variable_pricing"))
        new_variable = bool(new.get("variable_pricing"))
        if new_variable:
            if not old_variable:
                events.append({
                    "ts": ts, "kind": "pricing_variable", "id": model_id,
                    "name": new.get("name", old.get("name", "")),
                    "old_prompt_per_m": old_prompt, "new_prompt_per_m": new_prompt,
                    "old_completion_per_m": old_completion,
                    "new_completion_per_m": new_completion,
                    "old_free": old_free, "new_free": new_free,
                })
            continue
        if old_variable:
            events.append({
                "ts": ts, "kind": "pricing_fixed", "id": model_id,
                "name": new.get("name", old.get("name", "")),
                "old_prompt_per_m": old_prompt, "new_prompt_per_m": new_prompt,
                "old_completion_per_m": old_completion,
                "new_completion_per_m": new_completion,
                "old_free": old_free, "new_free": new_free,
            })
            if new_free:
                events.append({
                    "ts": ts, "kind": "went_free", "id": model_id,
                    "name": new.get("name", old.get("name", "")),
                    "old_prompt_per_m": old_prompt, "new_prompt_per_m": new_prompt,
                    "old_completion_per_m": old_completion,
                    "new_completion_per_m": new_completion,
                })
            continue
        price_changed = old_prompt != new_prompt or old_completion != new_completion
        if price_changed:
            events.append({
                "ts": ts, "kind": "price_change", "id": model_id,
                "name": new.get("name", old.get("name", "")),
                "old_prompt_per_m": old_prompt, "new_prompt_per_m": new_prompt,
                "old_completion_per_m": old_completion,
                "new_completion_per_m": new_completion,
                "old_free": old_free, "new_free": new_free,
            })
        if old_free != new_free:
            events.append({
                "ts": ts, "kind": "went_free" if new_free else "went_paid",
                "id": model_id, "name": new.get("name", old.get("name", "")),
                "old_prompt_per_m": old_prompt, "new_prompt_per_m": new_prompt,
                "old_completion_per_m": old_completion,
                "new_completion_per_m": new_completion,
            })
    return events


@dataclass(frozen=True)
class CatalogRefreshResult:
    path: Path
    changes_path: Path
    models: list[dict[str, Any]]
    events: list[dict[str, Any]]


def refresh_openrouter_catalog(
    snapshot_path: Path,
    *,
    source: str = DEFAULT_CATALOG_SOURCE,
    timeout: float = CATALOG_FETCH_TIMEOUT_S,
    atomic_write_json_fn: Any | None = None,
) -> CatalogRefreshResult:
    snapshot_path = snapshot_path.expanduser().resolve()
    changes_path = catalog_changes_path(snapshot_path)
    with catalog_refresh_lock(snapshot_path):
        ts = utc_now_iso()
        old_models = load_catalog_snapshot(snapshot_path)
        payload = fetch_catalog_payload(source, timeout=timeout)
        new_models = normalize_catalog_payload(payload, fetched_at=ts)
        events = diff_catalog_snapshots(old_models, new_models, ts=ts)
        snapshot = {"fetched_at": ts, "models": new_models}
        append_catalog_events(changes_path, events)
        # Append events before replacing the snapshot: a crash here can duplicate
        # events on the next refresh, but duplicated events are recoverable and
        # silently lost catalog changes are not.
        (atomic_write_json_fn or atomic_write_json)(snapshot_path, snapshot)
    return CatalogRefreshResult(
        path=snapshot_path,
        changes_path=changes_path,
        models=new_models,
        events=events,
    )
