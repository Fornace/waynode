"""Registry of live Hammersmith run processes."""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .identity import project_identity, project_selection_key
from .state_io import interprocess_lock, hammersmith_home


def active_runs_path() -> Path:
    return hammersmith_home() / "active-runs.json"


def active_runs_lock_path() -> Path:
    return hammersmith_home() / ".active-runs.lock"


def pid_is_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _read_active_runs_raw(path: Path) -> dict[str, dict[str, Any]]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return {}
    if not isinstance(data, dict):
        return {}
    runs: dict[str, dict[str, Any]] = {}
    for run_id, value in data.items():
        if isinstance(run_id, str) and isinstance(value, dict):
            runs[run_id] = value
    return runs


def _prune_active_runs(runs: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    pruned: dict[str, dict[str, Any]] = {}
    for run_id, entry in runs.items():
        pid = entry.get("pid")
        if isinstance(pid, bool):
            continue
        try:
            pid_int = int(pid)
        except (TypeError, ValueError):
            continue
        if not pid_is_alive(pid_int):
            continue
        clean_entry = {
            "pid": pid_int,
            "identity": str(entry.get("identity", "")),
            "run_name": str(entry.get("run_name", "")),
            "workdir": str(entry.get("workdir", "")),
            "started_at": str(entry.get("started_at", "")),
        }
        for field_name in (
            "project",
            "project_id",
            "project_label",
            "root_run_id",
            "parent_run_id",
            "replay_of",
            "selection_key",
        ):
            value = entry.get(field_name)
            if isinstance(value, str):
                clean_entry[field_name] = value
        pruned[run_id] = clean_entry
    return pruned


def _write_active_runs(runs: dict[str, dict[str, Any]]) -> None:
    path = active_runs_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(_prune_active_runs(runs), indent=2, sort_keys=True), encoding="utf-8")
    os.replace(tmp, path)


def read_active_runs() -> dict[str, dict[str, Any]]:
    path = active_runs_path()
    with interprocess_lock(active_runs_lock_path()):
        runs = _read_active_runs_raw(path)
        pruned = _prune_active_runs(runs)
        if pruned != runs:
            _write_active_runs(pruned)
        return pruned


def read_active_runs_snapshot() -> dict[str, dict[str, Any]]:
    """Return a pruned read view without rewriting the registry from a GET path."""
    path = active_runs_path()
    with interprocess_lock(active_runs_lock_path()):
        return _prune_active_runs(_read_active_runs_raw(path))


def register_active_run(
    run_id: str,
    identity: str,
    run_name: str,
    workdir: Path,
    *,
    pid: int | None = None,
    started_at: datetime | None = None,
    project: str = "",
    root_run_id: str = "",
    parent_run_id: str = "",
    replay_of: str = "",
) -> None:
    project_id, project_label = project_identity(project)
    with interprocess_lock(active_runs_lock_path()):
        runs = _prune_active_runs(_read_active_runs_raw(active_runs_path()))
        runs[run_id] = {
            "pid": int(pid if pid is not None else os.getpid()),
            "identity": identity,
            "run_name": run_name,
            "workdir": str(workdir),
            "started_at": (started_at or datetime.now(timezone.utc)).isoformat(),
            "project": project,
            "project_id": project_id,
            "project_label": project_label,
            "root_run_id": root_run_id or run_id,
            "parent_run_id": parent_run_id,
            "replay_of": replay_of,
            "selection_key": project_selection_key(project_id, run_id),
        }
        _write_active_runs(runs)


def unregister_active_run(run_id: str) -> None:
    with interprocess_lock(active_runs_lock_path()):
        runs = _prune_active_runs(_read_active_runs_raw(active_runs_path()))
        runs.pop(run_id, None)
        _write_active_runs(runs)


def read_active_runs_file() -> dict[str, Any]:
    return read_active_runs()
