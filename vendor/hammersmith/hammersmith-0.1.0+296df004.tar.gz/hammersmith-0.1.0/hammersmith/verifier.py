from __future__ import annotations

import asyncio
from pathlib import Path

from hammersmith.process import kill_process_group, terminate_process_group
from hammersmith.runtime import VerifyResult
from hammersmith.config_models import FailureSummaryConfig
from hammersmith.constants import CHECK_TIMEOUT_S
from hammersmith.failure_summary import LiteLLMFailureSummarizer, bounded_failure_excerpt
from hammersmith.manifest_lint import contract_path_covers
from hammersmith.manifest_models import TaskSpec


class Verifier:
    def __init__(
        self,
        failure_summary: FailureSummaryConfig | None = None,
        *,
        summarizer: LiteLLMFailureSummarizer | None = None,
    ) -> None:
        self.failure_summary = failure_summary or FailureSummaryConfig()
        self.summarizer = summarizer
        if self.failure_summary.enabled and self.summarizer is None:
            self.summarizer = LiteLLMFailureSummarizer(self.failure_summary)

    async def verify(self, task: TaskSpec, taskdir: Path) -> VerifyResult:
        check_returncode, check_timed_out, output = await self._run_check(task.check, taskdir)
        required_outputs = tuple(dict.fromkeys((*task.expect_files, *task.expected_outputs)))
        observed_paths = await self._observed_git_paths(taskdir)
        missing_files = tuple(
            rel
            for rel in required_outputs
            if not self._is_nonempty_file(self._expect_file_path(taskdir, rel))
        )
        scope_violations = await self._scope_violations(task, taskdir)
        unexpected_paths = tuple(
            violation.split(":", 1)[1] if ":" in violation else violation
            for violation in scope_violations
        )
        ok = (
            not missing_files
            and not scope_violations
            and not check_timed_out
            and check_returncode == 0
        )
        if missing_files:
            missing_message = f"[hammersmith] missing expected files: {', '.join(missing_files)}"
            output = f"{missing_message}\n{output}" if output.strip() else missing_message
        if scope_violations:
            scope_message = (
                "[hammersmith] contract scope violation: " + ", ".join(scope_violations)
            )
            output = f"{scope_message}\n{output}" if output.strip() else scope_message
        elif not check_timed_out and check_returncode != 0 and not output.strip():
            # A silent failing check wastes the retry (no failure context to
            # inject) and blinds the eval row. Say so, in both places.
            output = (
                f"[hammersmith] check failed silently (exit {check_returncode}, no output). "
                "Prefer checks that print WHY they fail; the retry prompt and the "
                "eval log both depend on it."
            )
        exact_failure_excerpt = bounded_failure_excerpt(
            output, self.failure_summary.max_output_chars
        )
        summary_source = "raw"
        summary_error: str | None = None
        excerpt = exact_failure_excerpt
        if len(output.strip()) > self.failure_summary.max_output_chars:
            summary_source = "deterministic"
        if (
            not ok
            and len(output.strip()) > self.failure_summary.max_output_chars
            and self.failure_summary.enabled
            and self.summarizer is not None
        ):
            try:
                candidate = await asyncio.wait_for(
                    asyncio.to_thread(
                        self.summarizer.summarize,
                        output,
                        check=task.check,
                        returncode=check_returncode,
                        timed_out=check_timed_out,
                    ),
                    timeout=self.failure_summary.timeout_s + 1.0,
                )
                candidate = candidate.strip()
                if candidate:
                    excerpt = candidate[: self.failure_summary.max_output_chars]
                    summary_source = f"model:{self.failure_summary.model}"
            except Exception as exc:
                summary_error = type(exc).__name__
        return VerifyResult(
            ok=ok,
            check_returncode=check_returncode,
            check_timed_out=check_timed_out,
            raw_output_excerpt=excerpt,
            missing_files=missing_files,
            scope_violations=scope_violations,
            unexpected_paths=unexpected_paths,
            observed_paths=observed_paths,
            failure_stage="task_check",
            exact_failure_excerpt=exact_failure_excerpt,
            summary_source=summary_source,
            summary_error=summary_error,
        )

    async def verify_shared_check(
        self,
        command: str,
        cwd: Path,
        *,
        timeout_s: int,
        stage: str,
    ) -> VerifyResult:
        returncode, timed_out, output = await self._run_check(
            command, cwd, timeout_s=timeout_s
        )
        if not output.strip() and returncode != 0:
            output = (
                f"[hammersmith] shared check failed silently (exit {returncode}, no output)"
            )
        exact = bounded_failure_excerpt(output, self.failure_summary.max_output_chars)
        return VerifyResult(
            ok=not timed_out and returncode == 0,
            check_returncode=returncode,
            check_timed_out=timed_out,
            raw_output_excerpt=exact,
            failure_stage=stage,
            exact_failure_excerpt=exact,
        )

    @staticmethod
    async def _scope_violations(task: TaskSpec, taskdir: Path) -> tuple[str, ...]:
        if not task.owned_paths and not task.forbidden_paths:
            return ()
        diff_proc = await asyncio.create_subprocess_exec(
            "git",
            "diff",
            "--name-only",
            "-z",
            "--relative",
            "HEAD",
            cwd=str(taskdir),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        diff_stdout, _ = await diff_proc.communicate()
        if diff_proc.returncode != 0:
            return ()
        untracked_proc = await asyncio.create_subprocess_exec(
            "git",
            "ls-files",
            "--others",
            "--exclude-standard",
            "-z",
            cwd=str(taskdir),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        untracked_stdout, _ = await untracked_proc.communicate()
        changed = {
            raw.decode("utf-8", errors="replace")
            for raw in (*diff_stdout.split(b"\0"), *untracked_stdout.split(b"\0"))
            if raw
        }
        violations: list[str] = []
        for path in sorted(changed):
            if any(contract_path_covers(forbidden, path) for forbidden in task.forbidden_paths):
                violations.append(f"forbidden:{path}")
            elif task.owned_paths and not any(
                contract_path_covers(owner, path) for owner in task.owned_paths
            ):
                violations.append(f"unowned:{path}")
        return tuple(violations)
    @staticmethod
    async def _observed_git_paths(taskdir: Path) -> tuple[str, ...]:
        if not (taskdir / ".git").exists():
            return ()
        try:
            diff_proc = await asyncio.create_subprocess_exec(
                "git", "diff", "HEAD", "--name-only", "-z", "--relative",
                cwd=str(taskdir),
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            diff_stdout, _ = await asyncio.wait_for(diff_proc.communicate(), timeout=10)
            untracked_proc = await asyncio.create_subprocess_exec(
                "git", "ls-files", "--others", "--exclude-standard", "-z",
                cwd=str(taskdir),
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            untracked_stdout, _ = await asyncio.wait_for(untracked_proc.communicate(), timeout=10)
        except (OSError, asyncio.TimeoutError):
            return ()
        if diff_proc.returncode != 0 or untracked_proc.returncode != 0:
            return ()
        paths = {
            raw.decode("utf-8", errors="replace")
            for raw in (*diff_stdout.split(b"\0"), *untracked_stdout.split(b"\0"))
            if raw
        }
        return tuple(sorted(paths))

    @staticmethod
    def _is_nonempty_file(path: Path) -> bool:
        try:
            return path.is_file() and path.stat().st_size > 0
        except OSError:
            return False

    @staticmethod
    def _expect_file_path(taskdir: Path, path: str) -> Path:
        candidate = Path(path).expanduser()
        # Keep runtime verification aligned with lint's treatment of "~" paths.
        return candidate if candidate.is_absolute() else taskdir / candidate

    @staticmethod
    async def _run_check(
        command: str,
        cwd: Path,
        *,
        timeout_s: int = CHECK_TIMEOUT_S,
    ) -> tuple[int | None, bool, str]:
        proc = await asyncio.create_subprocess_shell(
            command,
            cwd=str(cwd),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            start_new_session=True,
        )
        timed_out = False
        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
        except asyncio.TimeoutError:
            timed_out = True
            terminate_process_group(proc)
            try:
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            except asyncio.TimeoutError:
                kill_process_group(proc)
                stdout, _ = await proc.communicate()
        output = stdout.decode("utf-8", errors="replace") if stdout else ""
        if timed_out:
            output += f"\n[hammersmith] check timed out after {timeout_s}s\n"
        return proc.returncode, timed_out, output
