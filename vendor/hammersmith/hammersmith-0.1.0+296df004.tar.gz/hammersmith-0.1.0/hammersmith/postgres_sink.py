"""PostgreSQL persistence for evaluation attempts.

This module intentionally keeps the optional psycopg dependency behind the
connection boundary so importing the rest of Hammersmith does not require it.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


POSTGRES_COLUMNS = (
    "run_id",
    "pattern",
    "task_key",
    "spec",
    "worker_engine",
    "shepherd_model",
    "verify_method",
    "verdict",
    "duration_ms",
    "worker_tokens",
    "notes",
    "orchestrator",
)


def parse_env_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        value = value.strip()
        if (value.startswith('"') and value.endswith('"')) or (
            value.startswith("'") and value.endswith("'")
        ):
            value = value[1:-1]
        values[key.strip()] = value
    return values


def connect_postgres(env_file: Path) -> tuple[Any | None, str | None]:
    try:
        import psycopg  # type: ignore[import-not-found]
    except Exception as exc:
        return None, f"psycopg import failed: {exc}"

    creds = parse_env_file(env_file)
    required = [
        "SUPABASE_DB_HOST",
        "SUPABASE_DB_PORT",
        "SUPABASE_DB_USER",
        "SUPABASE_DB_PASSWORD",
        "SUPABASE_DB_NAME",
    ]
    missing = [key for key in required if not creds.get(key)]
    if missing:
        return None, f"missing Supabase env keys: {', '.join(missing)}"
    try:
        conn = psycopg.connect(
            host=creds["SUPABASE_DB_HOST"],
            port=int(creds["SUPABASE_DB_PORT"]),
            user=creds["SUPABASE_DB_USER"],
            password=creds["SUPABASE_DB_PASSWORD"],
            dbname=creds["SUPABASE_DB_NAME"],
            autocommit=True,
            connect_timeout=5,
        )
    except Exception as exc:
        return None, f"Supabase connect failed: {exc}"
    return conn, None


def insert_eval_attempt(conn: Any, row: dict[str, Any]) -> None:
    db_row = {key: row.get(key) for key in POSTGRES_COLUMNS}
    conn.execute(
        """
        INSERT INTO swarm_runs (
            run_id, pattern, task_key, spec, worker_engine, shepherd_model,
            verify_method, verdict, duration_ms, worker_tokens, notes, orchestrator
        )
        VALUES (
            %(run_id)s, %(pattern)s, %(task_key)s, %(spec)s, %(worker_engine)s,
            %(shepherd_model)s, %(verify_method)s, %(verdict)s, %(duration_ms)s,
            %(worker_tokens)s, %(notes)s, %(orchestrator)s
        )
        """,
        db_row,
    )


def close_postgres(conn: Any | None) -> None:
    if conn is None:
        return
    try:
        conn.close()
    except Exception:
        pass
