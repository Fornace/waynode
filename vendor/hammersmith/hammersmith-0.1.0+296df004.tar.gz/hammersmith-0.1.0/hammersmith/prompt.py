"""Worker execution-contract prompt compilation."""
from __future__ import annotations

from typing import Iterable

from .manifest_models import TaskSpec

def contract_list(values: Iterable[str]) -> str:
    items = list(values)
    if not items:
        return "- (none declared)"
    return "\n".join(f"- {item}" for item in items)


def compile_worker_prompt(task: TaskSpec, *, retry_context: str = "") -> str:
    """Compile the full execution contract handed to every worker attempt."""
    patch_lines = [
        f"{patch.path} (sha256={patch.sha256 or 'not pinned'}, apply={str(patch.apply).lower()})"
        for patch in task.input_patches
    ]
    if "orchestration" in task.task_type.casefold():
        orchestration_boundary = (
            "ORCHESTRATION OWNER BOUNDARY: This task is explicitly authorized to launch "
            "child Hammersmith runs only where its task specification permits them. Do not "
            "start Restate, Trigger.dev, background watchers, task-specific MCP servers, or "
            "any other observability/orchestration layer. Hammersmith owns persistence, "
            "timeouts, logs, hierarchy, and verification for this task and its declared children."
        )
    else:
        orchestration_boundary = (
            "ORCHESTRATOR BOUNDARY: This worker is already running inside Hammersmith. "
            "Do not start Restate, Trigger.dev, another Hammersmith run, background "
            "watchers, task-specific MCP servers, or any nested observability/orchestration "
            "layer. Run the declared task and check directly in the foreground; Hammersmith "
            "already provides persistence, timeout handling, logs, and verification."
        )
    sections = [
        "TASK",
        task.spec.strip(),
        "NON-NEGOTIABLE EXECUTION CONTRACT",
        f"Layout policy: {task.layout_policy.upper()}.",
        "Owned paths:\n" + contract_list(task.owned_paths),
        "Forbidden paths:\n" + contract_list(task.forbidden_paths),
        "Required inputs:\n" + contract_list(task.required_inputs),
        "Input patches (verified/materialized by Hammersmith before launch):\n"
        + contract_list(patch_lines),
        "Expected implementation outputs:\n" + contract_list(task.expected_outputs),
        "Expected deliverable files:\n" + contract_list(task.expect_files),
        "The filenames and owned paths are part of the API.",
        "A locally passing alternate layout is a failure.",
        "If a required input is missing or an input patch cannot be applied, stop with CONTRACT_BLOCKED.",
        "Do not modify forbidden or unowned paths.",
        orchestration_boundary,
        "PIPELINE EXIT DISCIPLINE: When a command whose exit status matters is piped "
        "through tail, tee, or another consumer, enable `set -o pipefail` first or "
        "explicitly preserve and check the producer's status. Never treat the final "
        "pipeline command's zero exit code as proof that tests or guards passed.",
    ]
    if task.layout_policy == "exact":
        model_hint = f"{task.engine} {task.model}".lower()
        if "fornace-max" in model_hint or "fornace/max" in model_hint:
            sections.append(
                "FORNACE MAX MODE: You are the implementation worker, not the architect. "
                "The requested file topology wins over your preferred design. Do not introduce "
                "helpers, combine modules, or rename tests unless explicitly permitted."
            )
        if "fornace-fast" in model_hint or "fornace/fast" in model_hint:
            sections.append(
                "FORNACE FAST MECHANICAL MODE: Copy exact paths and filenames literally. "
                "Do not invent synonyms, alternate documentation names, new validator "
                "directories, or equivalent layouts."
            )
    sections.extend(
        [
            "EXACT PASS CHECK",
            task.check.strip(),
            "WHAT PASSING PROVES",
            task.verified.strip() or "No verified meaning was declared.",
            "Run the exact check before declaring completion. Do not report completion unless it exits 0.",
        ]
    )
    if retry_context:
        sections.extend(
            [
                "RETRY INVARIANT",
                retry_context.strip(),
                "Make the smallest change needed to clear that invariant. Do not redesign the "
                "solution, rename required files, add unowned paths, or replace the required "
                "layout with an equivalent one.",
                "Re-run the exact pass check above before stopping.",
            ]
        )
    return "\n\n".join(section for section in sections if section)
