"""Structured logging for Hammersmith with trace IDs and metrics."""
from __future__ import annotations

import json
import logging
import sys
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Iterator

# Trace ID context variable for propagation across workers
_trace_id_var: ContextVar[str | None] = ContextVar('trace_id', default=None)


def get_trace_id() -> str | None:
    """Get current trace ID."""
    return _trace_id_var.get()


def set_trace_id(trace_id: str | None) -> None:
    """Set trace ID for current context."""
    _trace_id_var.set(trace_id)


def generate_trace_id() -> str:
    """Generate a new trace ID."""
    return str(uuid.uuid4())[:8]


@contextmanager
def trace_context(trace_id: str | None = None) -> Iterator[str]:
    """Context manager for trace ID propagation."""
    if trace_id is None:
        trace_id = generate_trace_id()
    token = _trace_id_var.set(trace_id)
    try:
        yield trace_id
    finally:
        _trace_id_var.reset(token)


@dataclass
class TaskMetrics:
    """Metrics for a single task execution."""
    task_key: str
    duration_ms: int
    tokens: int | None = None
    cost_usd: float | None = None
    model: str | None = None
    engine: str | None = None
    success: bool = True
    error: str | None = None
    timestamp: str | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = datetime.now(timezone.utc).isoformat()


class StructuredFormatter(logging.Formatter):
    """JSON formatter for structured logging."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            'timestamp': datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'trace_id': get_trace_id(),
        }

        # Add extra fields
        for key, value in record.__dict__.items():
            if key not in {
                'msg', 'args', 'levelname', 'levelno', 'pathname', 'filename',
                'module', 'exc_info', 'exc_text', 'stack_info', 'lineno',
                'funcName', 'created', 'msecs', 'relativeCreated', 'thread',
                'threadName', 'processName', 'process', 'message', 'name',
            }:
                log_entry[key] = value

        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)

        return json.dumps(log_entry, default=str)


class MetricsCollector:
    """Collect and report task metrics."""

    def __init__(self) -> None:
        self.metrics: list[TaskMetrics] = []
        self.logger = logging.getLogger('hammersmith.metrics')

    def record(self, metrics: TaskMetrics) -> None:
        """Record task metrics."""
        self.metrics.append(metrics)
        self.logger.info(
            'task_completed',
            extra={
                'task_key': metrics.task_key,
                'duration_ms': metrics.duration_ms,
                'tokens': metrics.tokens,
                'cost_usd': metrics.cost_usd,
                'success': metrics.success,
            }
        )

    def summary(self) -> dict[str, Any]:
        """Generate metrics summary."""
        if not self.metrics:
            return {'total_tasks': 0}

        total_tokens = sum(m.tokens or 0 for m in self.metrics)
        total_cost = sum(m.cost_usd or 0.0 for m in self.metrics)
        total_duration = sum(m.duration_ms for m in self.metrics)
        success_count = sum(1 for m in self.metrics if m.success)

        return {
            'total_tasks': len(self.metrics),
            'successful_tasks': success_count,
            'failed_tasks': len(self.metrics) - success_count,
            'total_tokens': total_tokens,
            'total_cost_usd': total_cost,
            'total_duration_ms': total_duration,
            'avg_duration_ms': total_duration / len(self.metrics),
        }


def setup_logging(
    log_format: str = 'text',
    log_level: str = 'info',
) -> logging.Logger:
    """Setup logging with specified format.

    Args:
        log_format: 'text' or 'json'
        log_level: 'debug', 'info', 'warn', 'error'

    Returns:
        Configured logger
    """
    logger = logging.getLogger('hammersmith')
    logger.setLevel(getattr(logging, log_level.upper()))

    # Clear existing handlers
    logger.handlers.clear()

    # Create handler
    handler = logging.StreamHandler(sys.stderr)

    if log_format == 'json':
        handler.setFormatter(StructuredFormatter())
    else:
        handler.setFormatter(logging.Formatter(
            '%(asctime)s [%(levelname)s] %(name)s: %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))

    logger.addHandler(handler)
    return logger


def add_log_arguments(parser: Any) -> None:
    """Add logging arguments to argparse parser."""
    parser.add_argument(
        '--log-format',
        choices=['text', 'json'],
        default='text',
        help='Log output format (default: text)'
    )
    parser.add_argument(
        '--log-level',
        choices=['debug', 'info', 'warn', 'error'],
        default='info',
        help='Log level (default: info)'
    )
