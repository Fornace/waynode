"""Model-evaluation log parsing and evidence aggregation."""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

RESERVED_FIXTURE_MODELS = frozenset(
    {"proven-model", "probation-model", "mock-model", "test-model"}
)
UNATTRIBUTED_MODEL_DISPLAY = "(unattributed legacy rows)"


def parse_log_date(value: Any) -> str:
    if not isinstance(value, str) or len(value) < 10:
        return ""
    candidate = value[:10]
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", candidate):
        return ""
    try:
        datetime.strptime(candidate, "%Y-%m-%d")
    except ValueError:
        return ""
    return candidate


def validate_since_date(value: str | None) -> str | None:
    if value is None:
        return None
    if not parse_log_date(value):
        raise ValueError("--since must be YYYY-MM-DD")
    return value


def model_log_row_is_retry(row: dict[str, Any]) -> bool:
    retry = row.get("retry")
    if isinstance(retry, bool):
        return retry
    if isinstance(retry, str) and retry.strip().lower() in {"true", "false"}:
        return retry.strip().lower() == "true"
    notes = row.get("notes", "")
    return isinstance(notes, str) and "retry=true" in notes


def model_log_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def model_log_row_model(row: dict[str, Any]) -> str:
    model = model_log_text(row.get("model"))
    if model:
        return model
    return model_log_text(row.get("worker_engine"))


def model_log_row_engine(row: dict[str, Any]) -> str:
    return model_log_text(row.get("worker_engine") if "worker_engine" in row else row.get("engine"))


def model_log_row_is_unattributed(row: dict[str, Any]) -> bool:
    return not model_log_text(row.get("model"))


def model_log_row_reasoning_effort(row: dict[str, Any]) -> str | None:
    effort = model_log_text(row.get("reasoning_effort"))
    return effort or None


def model_log_row_is_reserved_fixture(row: dict[str, Any]) -> bool:
    return model_log_text(row.get("model")) in RESERVED_FIXTURE_MODELS


def model_reasoning_effort_keys(rows: list[dict[str, Any]]) -> set[tuple[str, str, bool]]:
    keys: set[tuple[str, str, bool]] = set()
    for row in rows:
        if model_log_row_is_reserved_fixture(row):
            continue
        if not model_log_row_is_unattributed(row) and model_log_row_reasoning_effort(row) is not None:
            keys.add((model_log_row_engine(row), model_log_row_model(row), False))
    return keys


def model_log_row_task_type(row: dict[str, Any]) -> str:
    task_type = model_log_text(row.get("task_type"))
    return task_type or "(untyped)"


def model_log_row_is_model_eligible(row: dict[str, Any]) -> bool:
    value = row.get("model_eligible")
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.strip().casefold() in {"true", "false"}:
        return value.strip().casefold() == "true"
    # Historical rows predate failure intelligence and retain legacy scoring.
    return True


def model_log_failure_owner(row: dict[str, Any]) -> str:
    return model_log_text(row.get("failure_owner")) or "unknown"


def model_log_int(value: Any) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def median_int(values: list[int]) -> int | None:
    if not values:
        return None
    ordered = sorted(values)
    middle = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[middle]
    return (ordered[middle - 1] + ordered[middle]) // 2


def model_log_task_base_key(row: dict[str, Any]) -> tuple[str, str, str, str, str, bool] | None:
    run_id = model_log_text(row.get("run_id"))
    task_key = model_log_text(row.get("task_key"))
    if not run_id or not task_key:
        return None
    unattributed = model_log_row_is_unattributed(row)
    return (
        run_id,
        task_key,
        model_log_row_model(row),
        model_log_row_task_type(row),
        "" if unattributed else (model_log_row_reasoning_effort(row) or ""),
        unattributed,
    )


def group_model_log_tasks(rows: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    if any(model_log_text(row.get("record_type")) == "adjudication" for row in rows):
        rows = apply_adjudication_records(rows)
    grouped: list[list[dict[str, Any]]] = []
    active_by_key: dict[tuple[str, str, str, str, str, bool], int] = {}
    for row in rows:
        key = model_log_task_base_key(row)
        if key is not None and model_log_row_is_retry(row) and key in active_by_key:
            grouped[active_by_key[key]].append(row)
            continue
        grouped.append([row])
        if key is not None:
            active_by_key[key] = len(grouped) - 1
    return grouped


def read_model_log_rows(
    path: Path,
    *,
    since: str | None = None,
    engine: str | None = None,
) -> tuple[list[dict[str, Any]], int]:
    rows: list[dict[str, Any]] = []
    skipped = 0
    try:
        fh = path.open("r", encoding="utf-8")
    except FileNotFoundError:
        return rows, skipped
    with fh:
        for line in fh:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                skipped += 1
                continue
            if not isinstance(row, dict):
                skipped += 1
                continue
            if engine is not None and model_log_text(row.get("worker_engine")) != engine:
                continue
            rows.append(row)
    rows = apply_adjudication_records(rows)
    if since is not None:
        selected_row_ids: set[int] = set()
        for task_rows in group_model_log_tasks(rows):
            ordered = sorted(
                task_rows,
                key=lambda row: (
                    model_log_text(row.get("logged_at")),
                    1 if model_log_row_is_retry(row) else 0,
                ),
            )
            final_date = parse_log_date(ordered[-1].get("logged_at"))
            if final_date and final_date >= since:
                selected_row_ids.update(id(row) for row in task_rows)
        rows = [row for row in rows if id(row) in selected_row_ids]
    return rows, skipped


ADJUDICATION_OUTCOMES = frozenset(
    {"parent-accepted", "parent-rejected", "invalid-task", "infrastructure"}
)


def apply_adjudication_records(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Overlay append-only parent decisions on attempt rows without mutating history."""
    decisions: dict[tuple[str, str], dict[str, Any]] = {}
    attempts: list[dict[str, Any]] = []
    for row in rows:
        if model_log_text(row.get("record_type")) == "adjudication":
            key = (model_log_text(row.get("run_id")), model_log_text(row.get("task_key")))
            if all(key):
                decisions[key] = row
            continue
        attempts.append(dict(row))
    for row in attempts:
        decision = decisions.get((model_log_text(row.get("run_id")), model_log_text(row.get("task_key"))))
        if decision is None:
            continue
        outcome = model_log_text(decision.get("outcome"))
        row["parent_outcome"] = outcome
        row["adjudication"] = {
            "outcome": outcome,
            "reason": model_log_text(decision.get("reason")),
            "logged_at": model_log_text(decision.get("logged_at")),
            "adjudicator": model_log_text(decision.get("adjudicator")),
        }
        if outcome == "invalid-task":
            row["model_eligible"] = False
            row["failure_owner"] = "contract"
        elif outcome == "infrastructure":
            row["model_eligible"] = False
            row["failure_owner"] = "provider"
    return attempts


def aggregate_model_log_rows(
    rows: list[dict[str, Any]],
    *,
    task_type: str | None = None,
    model: str | None = None,
) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str, str, str, bool], dict[str, Any]] = {}
    effort_keys = model_reasoning_effort_keys(rows)
    for task_rows in group_model_log_tasks(rows):
        ordered = sorted(
            task_rows,
            key=lambda row: (
                model_log_text(row.get("logged_at")),
                1 if model_log_row_is_retry(row) else 0,
            ),
        )
        first = ordered[0]
        final = ordered[-1]
        if model_log_row_is_reserved_fixture(final):
            continue
        group_engine = model_log_row_engine(final)
        group_model = model_log_row_model(final)
        group_task_type = model_log_row_task_type(final)
        unattributed = model_log_row_is_unattributed(final)
        reasoning_effort = None if unattributed else model_log_row_reasoning_effort(final)
        if model is not None and group_model != model:
            continue
        if task_type is not None and group_task_type != task_type:
            continue
        key = (group_engine, group_model, group_task_type, reasoning_effort or "", unattributed)
        group = groups.setdefault(key, {
            "engine": group_engine, "model": group_model, "task_type": group_task_type,
            "reasoning_effort": reasoning_effort,
            "show_reasoning_effort": (group_engine, group_model, unattributed) in effort_keys,
            "unattributed": unattributed, "tasks": 0, "attempts": 0,
            "passed": 0, "failed": 0, "pass_rate": 0.0,
            "first_try_pass_rate": 0.0, "median_duration_ms": None,
            "median_tokens": None, "last_seen": "", "_first_try_passed": 0,
            "_adjusted_tasks": 0, "_adjusted_passed": 0,
            "_adjusted_first_try_passed": 0, "excluded_infrastructure": 0,
            "excluded_contract": 0, "parent_accepted": 0,
            "parent_rejected_after_pass": 0, "_duration_ms": [], "_tokens": [],
        })
        group["tasks"] += 1
        group["attempts"] += len(ordered)
        passed = model_log_text(final.get("verdict")).upper() == "PASS"
        first_passed = model_log_text(first.get("verdict")).upper() == "PASS"
        group["passed" if passed else "failed"] += 1
        group["_first_try_passed"] += 1 if first_passed else 0
        eligible = model_log_row_is_model_eligible(final)
        parent_outcome = model_log_text(final.get("parent_outcome"))
        if eligible:
            group["_adjusted_tasks"] += 1
            group["_adjusted_passed"] += 1 if passed else 0
            group["_adjusted_first_try_passed"] += 1 if first_passed else 0
        elif model_log_failure_owner(final) in {"provider", "host"} or parent_outcome == "infrastructure":
            group["excluded_infrastructure"] += 1
        else:
            group["excluded_contract"] += 1
        group["parent_accepted"] += 1 if parent_outcome == "parent-accepted" else 0
        group["parent_rejected_after_pass"] += 1 if passed and parent_outcome == "parent-rejected" else 0
        duration_ms = model_log_int(final.get("duration_ms"))
        if duration_ms is not None:
            group["_duration_ms"].append(duration_ms)
        for row in ordered:
            tokens = model_log_int(row.get("worker_tokens"))
            if tokens is not None:
                group["_tokens"].append(tokens)
        logged_at = model_log_text(final.get("logged_at"))
        if logged_at > group["last_seen"]:
            group["last_seen"] = logged_at

    finalized: list[dict[str, Any]] = []
    for group in groups.values():
        tasks_count = group["tasks"]
        pass_rate = group["passed"] / tasks_count if tasks_count else 0.0
        first_try_pass_rate = group["_first_try_passed"] / tasks_count if tasks_count else 0.0
        adjusted_tasks = int(group["_adjusted_tasks"])
        finalized.append({
            "engine": group["engine"], "model": group["model"],
            "task_type": group["task_type"], "reasoning_effort": group["reasoning_effort"],
            "show_reasoning_effort": group["show_reasoning_effort"],
            "unattributed": group["unattributed"], "tasks": group["tasks"],
            "attempts": group["attempts"], "passed": group["passed"],
            "failed": group["failed"], "pass_rate": pass_rate,
            "first_try_pass_rate": first_try_pass_rate, "raw_pass_rate": pass_rate,
            "adjusted_tasks": adjusted_tasks,
            "adjusted_passed": group["_adjusted_passed"],
            "adjusted_failed": adjusted_tasks - group["_adjusted_passed"],
            "adjusted_pass_rate": group["_adjusted_passed"] / adjusted_tasks if adjusted_tasks else 0.0,
            "adjusted_first_try_pass_rate": (
                group["_adjusted_first_try_passed"] / adjusted_tasks if adjusted_tasks else 0.0
            ),
            "excluded_infrastructure": group["excluded_infrastructure"],
            "excluded_contract": group["excluded_contract"],
            "parent_accepted": group["parent_accepted"],
            "parent_rejected_after_pass": group["parent_rejected_after_pass"],
            "median_duration_ms": median_int(group["_duration_ms"]),
            "median_tokens": median_int(group["_tokens"]), "last_seen": group["last_seen"],
        })
    return sorted(
        finalized,
        key=lambda item: (
            1 if item["unattributed"] else 0, item["task_type"],
            -item["pass_rate"], -item["first_try_pass_rate"], item["engine"],
            item["model"], item["reasoning_effort"] or "",
        ),
    )
