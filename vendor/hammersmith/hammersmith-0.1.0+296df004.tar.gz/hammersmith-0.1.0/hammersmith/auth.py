"""Authentication and user management for Hammersmith dashboard."""
from __future__ import annotations

import hashlib
import hmac
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class User:
    """Represents a Hammersmith user."""
    username: str
    password_hash: str
    role: str  # "admin", "user", "viewer"
    created_at: float
    api_key: str | None = None

    def verify_password(self, password: str) -> bool:
        """Verify a password against the stored hash."""
        return verify_password(password, self.password_hash)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for storage."""
        return {
            "username": self.username,
            "password_hash": self.password_hash,
            "role": self.role,
            "created_at": self.created_at,
            "api_key": self.api_key,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> User:
        """Create from dictionary."""
        return cls(
            username=data["username"],
            password_hash=data["password_hash"],
            role=data.get("role", "user"),
            created_at=data.get("created_at", time.time()),
            api_key=data.get("api_key"),
        )


def hash_password(password: str) -> str:
    """Hash a password using PBKDF2-SHA256 with a per-user salt."""
    salt = secrets.token_hex(16)
    iterations = 600_000
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("ascii"), iterations
    ).hex()
    return f"pbkdf2_sha256${iterations}${salt}${digest}"


def verify_password(password: str, stored_hash: str) -> bool:
    """Verify a password hash, including old fixed-salt hashes."""
    if stored_hash.startswith("pbkdf2_sha256$"):
        _scheme, iterations, salt, digest = stored_hash.split("$", 3)
        expected = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), salt.encode("ascii"), int(iterations)
        ).hex()
        return hmac.compare_digest(expected, digest)
    legacy = hashlib.sha256(f"hammersmith-salt-v1{password}".encode()).hexdigest()
    return hmac.compare_digest(legacy, stored_hash)


def generate_api_key() -> str:
    """Generate a secure API key."""
    return secrets.token_urlsafe(32)


def default_users_file() -> Path:
    """Return the default persisted user store path."""
    import os

    home = os.environ.get("HAMMERSMITH_HOME")
    if home:
        return Path(home) / "users.json"
    return Path.home() / ".hammersmith" / "users.json"


class AuthManager:
    """Manages users and authentication."""

    def __init__(self, users_file: Path | None = None):
        self.users_file = users_file or default_users_file()
        self.users: dict[str, User] = {}
        self.sessions: dict[str, tuple[str, float]] = {}  # token -> (username, expiry)
        self._load_users()

    def _load_users(self) -> None:
        """Load users from disk."""
        if not self.users_file.exists():
            return

        import json
        try:
            data = json.loads(self.users_file.read_text())
            for user_data in data.get("users", []):
                user = User.from_dict(user_data)
                self.users[user.username] = user
        except Exception:
            pass  # Corrupted file, start fresh

    def _save_users(self) -> None:
        """Save users to disk."""
        import json
        self.users_file.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "users": [user.to_dict() for user in self.users.values()]
        }
        self.users_file.write_text(json.dumps(data, indent=2))

    def create_user(
        self,
        username: str,
        password: str,
        role: str = "user",
    ) -> User:
        """Create a new user."""
        if username in self.users:
            raise ValueError(f"User '{username}' already exists")

        user = User(
            username=username,
            password_hash=hash_password(password),
            role=role,
            created_at=time.time(),
        )
        self.users[username] = user
        self._save_users()
        return user

    def authenticate(self, username: str, password: str) -> str | None:
        """Authenticate a user and return a session token."""
        user = self.users.get(username)
        if not user or not user.verify_password(password):
            return None

        # Create session token
        token = secrets.token_urlsafe(32)
        expiry = time.time() + (24 * 60 * 60)  # 24 hours
        self.sessions[token] = (username, expiry)
        return token

    def validate_session(self, token: str) -> User | None:
        """Validate a session token and return the user."""
        session = self.sessions.get(token)
        if not session:
            return None

        username, expiry = session
        if time.time() > expiry:
            del self.sessions[token]
            return None

        return self.users.get(username)

    def logout(self, token: str) -> None:
        """Invalidate a session token."""
        self.sessions.pop(token, None)

    def get_user(self, username: str) -> User | None:
        """Get a user by username."""
        return self.users.get(username)

    def list_users(self) -> list[User]:
        """List all users."""
        return list(self.users.values())

    def delete_user(self, username: str) -> bool:
        """Delete a user."""
        if username not in self.users:
            return False
        del self.users[username]
        self._save_users()
        return True

    def change_password(self, username: str, new_password: str) -> bool:
        """Change a user's password."""
        user = self.users.get(username)
        if not user:
            return False
        user.password_hash = hash_password(new_password)
        self._save_users()
        return True

    def has_admin(self) -> bool:
        """Return True when at least one admin user exists."""
        return any(user.role == "admin" for user in self.users.values())

    def ensure_admin_exists(self) -> User | None:
        """Return the first admin user when one exists."""
        admins = [u for u in self.users.values() if u.role == "admin"]
        return admins[0] if admins else None
