from __future__ import annotations
import contextlib
import os
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from .config import ArtifactConfig, EngineConfig
from .control_plane.adjudications import latest_adjudications
from .failure import FailureAssessment
from .identity import product_identity, project_identity, project_selection_key
from .process import ProcessTree
from .runtime import TaskRuntime
from .state_io import atomic_write_json, interprocess_lock
from .artifacts.library import artifact_live_path, artifact_version_path
from .artifacts.renderer import ArtifactRenderer
from .control_plane.evidence import evidence_root_records
from .model_routing import routing_suggestion
from .prompt import compile_worker_prompt
from .state_writer_support import StateWriterSupport
from .utils.activity import shorten, tail_lines, worker_activity
from .utils.models import effective_model_from_command

class StateWriter(StateWriterSupport):
    def __init__(
        self,
        run_id: str,
        run_name: str,
        identity: str,
        state_dir: Path,
        engines: dict[str, EngineConfig],
        started_at: datetime,
        runtimes: list[TaskRuntime],
        lock: threading.RLock,
        max_parallel: int = 1,
        artifact: ArtifactConfig | None = None,
        path: Path | None = None,
        engine_health: dict[str, dict[str, Any]] | None = None,
        project: str = "",
        root_run_id: str = "",
        parent_run_id: str = "",
        replay_of: str = "",
        duplicate_of: str = "",
        shared_check_state: dict[str, Any] | None = None,
    ) -> None:
        self.run_id = run_id
        self.run_name = run_name
        self.identity = identity
        self.engines = engines
        self.started_at = started_at
        self.runtimes = runtimes
        self.lock = lock
        self.max_parallel = max_parallel
        self.state_dir = state_dir
        root_candidates = [runtime.taskdir.parent for runtime in runtimes]
        root_candidates.extend(runtime.log_path.parent.parent for runtime in runtimes)
        self.workdir = (
            Path(os.path.commonpath([str(path) for path in root_candidates])).resolve()
            if root_candidates
            else state_dir.resolve()
        )
        self.evidence_roots = evidence_root_records((("workdir", self.workdir),))
        self.path = path or (state_dir / "runs" / f"{run_id}.json")
        self.pid = os.getpid()
        self.engine_health = engine_health if engine_health is not None else {}
        self.project = project
        self.project_id, self.project_label = project_identity(project)
        self.root_run_id = root_run_id or run_id
        self.parent_run_id = parent_run_id
        self.replay_of = replay_of
        self.duplicate_of = duplicate_of
        self.shared_check_state = (
            shared_check_state if shared_check_state is not None else {"status": "not_configured"}
        )
        self.port: int | None = None
        self.finished = False
        self.summary: dict[str, int] | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.artifact = artifact or ArtifactConfig(
            enabled=False,
            out_template=str(state_dir / "artifacts" / "{run_id}.html"),
            report_template=str(state_dir / "artifacts" / "{run_id}-report.html"),
            index_out=state_dir / "artifacts" / "index.html",
        )
        self.artifact_path = self.artifact.artifact_path(self.run_id, self.run_name)
        self.live_path = artifact_live_path(self.state_dir, self.run_name, project_id=self.project_id)
        self.version_path = artifact_version_path(self.state_dir, self.run_name, self.run_id, project_id=self.project_id)
        self.report_path = self.artifact.report_path(self.run_id, self.run_name)
        self.artifact_renderer = ArtifactRenderer(self.artifact_path)
        self.report_written = False
        self.version_recorded = False
        self._last_library_state: str | None = None
        self._last_library_write_monotonic = 0.0

    def start(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with contextlib.suppress(FileNotFoundError):
            self.path.unlink()
        if self.artifact.enabled:
            self._reconcile_library_safe()
        self.flush()
        self._thread = threading.Thread(target=self._loop, name="ringer-state-writer", daemon=True)
        self._thread.start()

    def set_port(self, port: int | None) -> None:
        self.port = port
        self.flush()

    def finish(self) -> None:
        self.finished = True
        self.summary = self.build_summary()
        state = self.flush()
        self._write_final_report_safe(state)

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)
        self.flush()

    def flush(self) -> dict[str, Any]:
        state = self.snapshot()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with interprocess_lock(self.state_dir / ".state.lock"):
            atomic_write_json(self.path, state)
        if self.artifact.enabled:
            self._write_status_artifact_safe(state)
            self._write_index_safe()
            self._write_library_live_safe(state)
        return state

    def snapshot(self) -> dict[str, Any]:
        now = time.monotonic()
        children, commands = ProcessTree.read()
        adjudications = latest_adjudications(self.state_dir, self.run_id)
        with self.lock:
            tasks = []
            for runtime in self.runtimes:
                log_tail = tail_lines(runtime.log_path, line_count=3)
                log_tail_full = tail_lines(runtime.log_path, line_count=40)
                engine = self.engines.get(runtime.task.engine)
                process_name = engine.process_name if engine else runtime.task.engine
                task_state = {
                    "key": runtime.task.key,
                    "status": runtime.status,
                    "verdict": runtime.final_verdict,
                    "engine": runtime.task.engine,
                    "model": (
                        runtime.task.model
                        or (engine.model_default if engine else "")
                        or effective_model_from_command(runtime.last_worker_command)
                    ),
                    "routing_suggestion": routing_suggestion(runtime.task, engine),
                    "spec": runtime.task.spec,
                    "compiled_spec": compile_worker_prompt(runtime.task),
                    "spec_short": runtime.spec_short,
                    "verified": runtime.task.verified,
                    "check": runtime.task.check,
                    "owned_paths": list(runtime.task.owned_paths),
                    "forbidden_paths": list(runtime.task.forbidden_paths),
                    "required_inputs": list(runtime.task.required_inputs),
                    "expect_files": list(runtime.task.expect_files),
                    "contract": {
                        "layout_policy": runtime.task.layout_policy,
                        "owned_paths": list(runtime.task.owned_paths),
                        "forbidden_paths": list(runtime.task.forbidden_paths),
                        "required_inputs": list(runtime.task.required_inputs),
                        "expected_outputs": list(runtime.task.expected_outputs),
                        "max_attempts": runtime.task.max_attempts,
                        "input_patches": [dict(item) for item in runtime.input_patch_status],
                    },
                    "expected_outputs": list(runtime.task.expected_outputs),
                    "input_patch_status": [dict(item) for item in runtime.input_patch_status],
                    "contract_preflight": runtime.contract_preflight,
                    "shared_check_status": runtime.shared_check_status,
                    "exports_preserved": runtime.exports_preserved,
                    "integration_ready": runtime.integration_ready,
                    "failure_fingerprint": runtime.last_failure_fingerprint,
                    "repeated_failure_count": runtime.repeated_failure_count,
                    "escalation_path": (
                        str(runtime.escalation_path) if runtime.escalation_path else None
                    ),
                    "check_returncode": runtime.last_check_returncode,
                    "check_timed_out": runtime.last_check_timed_out,
                    "check_output_tail": shorten(runtime.last_check_output, 4000),
                    "check_summary_source": runtime.check_summary_source,
                    "check_summary_error": runtime.check_summary_error,
                    "failure_class": runtime.failure_class,
                    "failure_category": (
                        FailureAssessment(
                            runtime.failure_class,
                            runtime.failure_owner or "unknown",
                            bool(runtime.model_eligible),
                            runtime.retry_decision or "stop",
                            runtime.next_action or "",
                            runtime.failure_status or "",
                            runtime.failure_reason or "",
                        ).category
                        if runtime.failure_class
                        else None
                    ),
                    "failure_owner": runtime.failure_owner,
                    "model_eligible": runtime.model_eligible,
                    "retry_decision": runtime.retry_decision,
                    "next_action": runtime.next_action,
                    "failure_status": runtime.failure_status,
                    "failure_reason": runtime.failure_reason,
                    "missing_files": list(runtime.missing_files),
                    "unexpected_paths": list(runtime.unexpected_paths),
                    "observed_paths": list(runtime.observed_paths),
                    "adjudication": adjudications.get(runtime.task.key),
                    "timeout_s": runtime.task.timeout_s,
                    "taskdir": str(runtime.taskdir),
                    "log_path": str(runtime.log_path),
                    "report_paths": {
                        name: str(path) for name, path in runtime.report_paths.items()
                    },
                    "deliverables": [dict(item) for item in runtime.deliverables],
                    "deliverable_notes": list(runtime.deliverable_notes),
                    "activity": worker_activity(runtime.log_path, log_tail),
                    "elapsed_s": round(runtime.elapsed_s(now), 1),
                    "tokens": runtime.tokens,
                    "attempts": runtime.attempts,
                    "children": ProcessTree.count_named_descendants(
                        runtime.worker_pid, children, commands, process_name
                    ),
                    "log_tail": log_tail,
                    "log_tail_full": log_tail_full,
                }
                if (
                    isinstance(task_state["adjudication"], dict)
                    and task_state["adjudication"].get("outcome")
                    in {"invalid-task", "infrastructure"}
                ):
                    task_state["model_eligible"] = False
                if runtime.steering is not None:
                    task_state["steering"] = dict(runtime.steering)
                tasks.append(task_state)
            pass_count = sum(1 for item in tasks if item["status"] == "pass")
            fail_count = sum(1 for item in tasks if item["status"] == "fail")
            running_count = sum(
                1 for item in tasks if item["status"] in {"running", "verifying", "retrying"}
            )
            totals = {
                "running": running_count,
                "done": pass_count + fail_count,
                "pass": pass_count,
                "fail": fail_count,
                "tokens": sum(int(item["tokens"] or 0) for item in tasks),
            }
            return {
                "run_id": self.run_id,
                "shared_check": dict(self.shared_check_state),
                "run_name": self.run_name,
                "workdir": str(self.workdir),
                "evidence_roots": list(self.evidence_roots),
                "product": product_identity(),
                "project": self.project,
                "project_id": self.project_id,
                "project_label": self.project_label,
                "selection_key": project_selection_key(self.project_id, self.run_id),
                "root_run_id": self.root_run_id,
                "parent_run_id": self.parent_run_id,
                "replay_of": self.replay_of,
                "duplicate_of": self.duplicate_of,
                "identity": self.identity,
                "state": "finished" if self.finished else "live",
                "pid": self.pid,
                "port": self.port,
                "dashboard_port": self.port,
                "max_parallel": self.max_parallel,
                "finished": self.finished,
                "summary": self.summary if self.finished else None,
                "started_at": self.started_at.isoformat(),
                "elapsed_s": max((float(item["elapsed_s"]) for item in tasks), default=0.0),
                "tasks": tasks,
                "engine_health": {
                    name: dict(health) for name, health in self.engine_health.items()
                },
                "totals": totals,
                "pass": totals["pass"],
                "fail": totals["fail"],
                "tokens": totals["tokens"],
                "artifact_path": str(self.artifact_path) if self.artifact.enabled else None,
                "live_path": str(self.live_path) if self.artifact.enabled else None,
                "report_path": str(self.report_path) if self.artifact.enabled else None,
                "report_ready": self.report_written,
            }

    def build_summary(self) -> dict[str, int]:
        with self.lock:
            return {
                "pass": sum(1 for runtime in self.runtimes if runtime.status == "pass"),
                "fail": sum(1 for runtime in self.runtimes if runtime.status == "fail"),
                "tokens": sum(int(runtime.tokens or 0) for runtime in self.runtimes),
            }

    def _loop(self) -> None:
        while not self._stop.wait(1.0):
            try:
                self.flush()
            except Exception as exc:
                print(f"state writer error: {exc}", file=sys.stderr)
