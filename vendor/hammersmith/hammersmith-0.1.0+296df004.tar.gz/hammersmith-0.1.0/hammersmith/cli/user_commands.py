"""User management CLI commands."""
from __future__ import annotations

import getpass
import json
import sys
from datetime import datetime
from typing import Any

from hammersmith.auth import AuthManager


def run_user_command(args: Any) -> int:
    """Run a Hammersmith user management subcommand."""
    auth_manager = AuthManager()
    if args.user_command == "create":
        return create_user(auth_manager, args)
    if args.user_command == "list":
        return list_users(auth_manager, args)
    if args.user_command == "delete":
        return delete_user(auth_manager, args)
    if args.user_command == "reset-password":
        return reset_password(auth_manager, args)
    print(f"Unknown user command: {args.user_command}", file=sys.stderr)
    return 1


def get_password(username: str, label: str = "Password") -> str | None:
    """Prompt for and confirm a password."""
    password = getpass.getpass(f"{label} for {username}: ")
    confirm = getpass.getpass("Confirm password: ")
    if password != confirm:
        print("Error: Passwords do not match", file=sys.stderr)
        return None
    return password


def create_user(auth_manager: AuthManager, args: Any) -> int:
    """Create a user."""
    username = args.username
    password = args.password or get_password(username)
    if password is None:
        return 1
    try:
        auth_manager.create_user(username, password, role=args.role)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    print(f"Created user: {username} (role: {args.role})")
    return 0


def list_users(auth_manager: AuthManager, args: Any) -> int:
    """List users."""
    users = auth_manager.list_users()
    if not users:
        print("No users found")
        return 0
    if getattr(args, "json", False):
        print(json.dumps([user.to_dict() for user in users], indent=2))
        return 0
    print(f"{'Username':<20} {'Role':<10} {'Created'}")
    print("-" * 50)
    for user in users:
        created = datetime.fromtimestamp(user.created_at).strftime("%Y-%m-%d %H:%M")
        print(f"{user.username:<20} {user.role:<10} {created}")
    return 0


def delete_user(auth_manager: AuthManager, args: Any) -> int:
    """Delete a user."""
    username = args.username
    if not getattr(args, "force", False):
        confirm = input(f"Delete user '{username}'? [y/N]: ")
        if confirm.lower() != "y":
            print("Cancelled")
            return 0
    if auth_manager.delete_user(username):
        print(f"Deleted user: {username}")
        return 0
    print(f"Error: User '{username}' not found", file=sys.stderr)
    return 1


def reset_password(auth_manager: AuthManager, args: Any) -> int:
    """Reset a user's password."""
    username = args.username
    password = args.password or get_password(username, "New password")
    if password is None:
        return 1
    if auth_manager.change_password(username, password):
        print(f"Password reset for: {username}")
        return 0
    print(f"Error: User '{username}' not found", file=sys.stderr)
    return 1
