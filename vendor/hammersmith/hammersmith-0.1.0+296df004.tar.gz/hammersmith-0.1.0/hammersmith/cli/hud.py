"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import contextlib
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from hammersmith.browser import open_in_browser
from hammersmith.config import AppConfig
from hammersmith.identity import PRODUCT_NAME
from hammersmith.http_server.servers import PersistentHudServer

def hud_is_alive(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/runs", timeout=0.4) as response:
            return response.status == 200
    except Exception:
        return False

def ensure_hud_running(config: AppConfig, *, open_browser: bool) -> None:
    """Make sure the persistent Hammersmith page is up before a run starts.

    The human should never have to remember a second command to watch the
    fight: if no hud answers on the configured port, spawn one detached.
    """
    port = config.hud_port
    url = f"http://127.0.0.1:{port}"
    already_alive = hud_is_alive(port)
    if not already_alive:
        log_path = config.state_dir / "hud.log"
        with contextlib.suppress(Exception):
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with log_path.open("ab") as log_file:
                subprocess.Popen(
                    [sys.executable, "-m", "hammersmith", "hud", "--no-open", "--port", str(port)],
                    stdout=log_file,
                    stderr=log_file,
                    stdin=subprocess.DEVNULL,
                    start_new_session=True,
                )
        for _ in range(20):
            if hud_is_alive(port):
                break
            time.sleep(0.15)
    if open_browser and not already_alive and hud_is_alive(port):
        open_in_browser(url)
    print(f"{PRODUCT_NAME}: {url}", flush=True)

def run_persistent_hud(config: AppConfig, *, port: int | None, open_viewer: bool) -> int:
    chosen_port = port if port is not None else config.hud_port
    if hud_is_alive(chosen_port):
        url = f"http://127.0.0.1:{chosen_port}"
        print(f"{PRODUCT_NAME} is already running: {url}")
        if open_viewer:
            open_in_browser(url)
        return 0
    server = PersistentHudServer(
        config.state_dir,
        preferred_port=chosen_port,
        open_viewer=open_viewer,
    )
    server.model_log_path = config.eval.jsonl_path
    server.default_model_log_path = config.eval.jsonl_path
    server.start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        print(f"\n{PRODUCT_NAME} stopped.")
        return 0
    finally:
        server.stop()
