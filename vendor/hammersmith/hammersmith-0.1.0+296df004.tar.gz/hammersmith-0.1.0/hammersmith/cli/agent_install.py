"""Backward-compatible shim for the agent skill installer.

The canonical installer lives in :mod:`hammersmith.agent.installer`. This
module re-exports the entry points so existing call sites
(``hammersmith install-agent`` / ``hammersmith uninstall-agent``) keep working.
"""

from __future__ import annotations

from ..agent.installer import (
    TARGETS,
    install_agent,
    install_for_target,
    layout_for,
    uninstall_agent,
    uninstall_for_target,
)

__all__ = [
    "TARGETS",
    "install_agent",
    "install_for_target",
    "layout_for",
    "uninstall_agent",
    "uninstall_for_target",
]
