"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import time
from pathlib import Path

from hammersmith.prompt import compile_worker_prompt
from hammersmith.steering import resolve_steering_profile
from hammersmith.utils.models import (
    build_run_id, build_worker_command, resolved_task_model, shell_command_for_display,
)

ENGINE_INSTALL_HINTS = {
    "codex": "install it with `npm install -g @openai/codex` (or `brew install --cask codex`), then run `codex login`",
    "opencode": "install it with `curl -fsSL https://opencode.ai/install | bash`, then run `opencode auth login`",
}

def print_steering_notes(manifest: Manifest, config: AppConfig) -> None:
    """Surface driver-audience guidance once per resolved model. Never raise."""
    try:
        if config.steering.dir is None:
            return
        seen_models: set[str] = set()
        for task in manifest.tasks:
            try:
                engine = config.engines.get(task.engine)
                command: list[str] = []
                if engine is not None:
                    command = build_worker_command(
                        engine,
                        taskdir=(manifest.workdir / task.key).resolve(),
                        spec=task.spec,
                        full_access=task.full_access,
                        engine_args=task.engine_args,
                        model=task.model,
                    )
                model = resolved_task_model(task, engine, command)
                if not model or model in seen_models:
                    continue
                seen_models.add(model)
                profile = resolve_steering_profile(config.steering.dir, model)
                if profile is None:
                    continue
                rules = tuple(
                    rule
                    for rule in profile.rules
                    if rule.audience == "driver"
                    and rule.status in {"confirmed", "candidate", "stale-pending-reverify"}
                )
                if not rules:
                    continue
                print(
                    f"Steering notes for {model} (v{profile.profile_version}) "
                    "(apply when writing specs/feedback):"
                )
                for rule in rules:
                    print(f"- ({rule.status}) {rule.inject}")
            except Exception:
                continue
    except Exception:
        return

def preflight_engine_bins(manifest: Manifest, config: AppConfig) -> None:
    """Fail before spawning anything if a worker binary is missing.

    Without this, a fresh install dies mid-run with a bare
    "worker spawn failed: [Errno 2]" in the task log, the least helpful
    possible first experience.
    """
    for name in sorted({task.engine for task in manifest.tasks}):
        engine = config.engines.get(name)
        if engine is None:
            continue  # validate_manifest_engines already rejected this
        bin_path = engine.bin
        if os.sep in bin_path:
            found = Path(bin_path).expanduser()
            missing = not (found.is_file() and os.access(found, os.X_OK))
        else:
            missing = shutil.which(bin_path) is None
        if missing:
            hint = ENGINE_INSTALL_HINTS.get(name, f"install it or fix engines.{name}.bin in config.toml")
            raise ValueError(
                f"engine '{name}' binary not found ({bin_path}): {hint}"
            )

def validate_manifest_engines(manifest: Manifest, config: AppConfig) -> None:
    missing = sorted({task.engine for task in manifest.tasks if task.engine not in config.engines})
    if missing:
        raise ValueError(f"unknown worker engine(s): {', '.join(missing)}")
    for task in manifest.tasks:
        engine = config.engines[task.engine]
        requires_model = any("{model}" in item for item in engine.args_template)
        accepts_model = requires_model or "{model_args}" in engine.args_template
        if requires_model and not (task.model or engine.model_default):
            raise ValueError(
                f"task {task.key}: engine {engine.name} needs a model; set the task's "
                f"\"model\" field or engines.{engine.name}.model_default in config.toml"
            )
        if task.model and not accepts_model:
            raise ValueError(
                f"task {task.key}: \"model\" is set but engine {engine.name} has no "
                "{model} placeholder in its args_template, so it would be silently ignored"
            )

def dry_run(
    manifest: Manifest,
    config: AppConfig,
    identity: str,
    dashboard_enabled: bool,
    force_browser: bool,
) -> None:
    print("DRY RUN: no codex workers will be spawned.")
    print(f"Run: {manifest.run_name}")
    print(f"Identity: {identity}")
    print(f"Config: {config.path if config.path else '(safe defaults)'}")
    print(f"Workdir: {manifest.workdir}")
    print(f"Max parallel: {manifest.max_parallel}")
    print(f"Worktrees: {manifest.worktrees} repo={manifest.repo}")
    print(f"State dir: {config.state_dir}")
    print(f"Eval backend: {config.eval.backend}")
    print(f"Dashboard: {'on' if dashboard_enabled else 'off'}")
    if dashboard_enabled:
        mode = "browser"
        if not force_browser and config.hud_app_path is not None:
            mode = f"HUD app {config.hud_app_path} when available, browser fallback"
        print(f"Dashboard opener: {mode}")
        print(f"Dashboard port base: {config.dashboard_port_base}")
    print(f"Artifacts: {'on' if config.artifact.enabled else 'off'}")
    if config.artifact.enabled:
        run_id_preview = build_run_id(manifest.run_name)
        print(f"  live status page: {config.artifact.artifact_path(run_id_preview, manifest.run_name)}")
        print(f"  final report:     {config.artifact.report_path(run_id_preview, manifest.run_name)}")
        print(f"  runs index:       {config.artifact.index_out}")
    print("Tasks:")
    for task in manifest.tasks:
        taskdir = (manifest.workdir / task.key).resolve()
        engine = config.engines.get(task.engine)
        full_access_allowed = task.full_access and config.allow_full_access
        cmd = (
            build_worker_command(
                engine,
                taskdir=taskdir,
                spec=compile_worker_prompt(task),
                full_access=task.full_access,
                engine_args=task.engine_args,
                model=task.model,
            )
            if engine is not None
            else []
        )
        print(f"  - {task.key}")
        print(f"    engine: {task.engine}")
        print(f"    dir: {taskdir}")
        print(f"    timeout_s: {task.timeout_s}")
        if task.full_access:
            print(f"    full_access: true allowed={full_access_allowed}")
        else:
            print("    full_access: false")
        print(f"    expect_files: {list(task.expect_files)}")
        print(f"    check: {task.check}")
        if engine is None:
            print("    command: ERROR unknown engine")
        elif task.full_access and not config.allow_full_access:
            print("    command: ERROR full_access requires allow_full_access=true in config")
        else:
            print(f"    command: {shell_command_for_display(cmd)} < /dev/null")

def print_lint_findings(findings: list[str]) -> None:
    for finding in findings:
        print(f"lint: {finding}")

def print_lint_detailed(findings: list[LintFinding]) -> None:
    for finding in findings:
        print(f"lint: {finding.severity.upper()}: {finding.message}")

def print_summary(run_id: str, runtimes: list[TaskRuntime]) -> None:
    print("\nSummary")
    print(f"run_id: {run_id}")
    header = f"{'task':<24} {'status':<8} {'verdict':<8} {'attempts':>8} {'tokens':>10} {'elapsed_s':>10}"
    print(header)
    print("-" * len(header))
    now = time.monotonic()
    for runtime in runtimes:
        tokens = "" if runtime.tokens is None else str(runtime.tokens)
        print(
            f"{runtime.task.key:<24} {runtime.status:<8} "
            f"{(runtime.final_verdict or ''):<8} {runtime.attempts:>8} "
            f"{tokens:>10} {runtime.elapsed_s(now):>10.1f}"
        )

def create_demo_manifest() -> Path:
    root = Path(tempfile.mkdtemp(prefix="ringer-demo-"))
    workdir = root / "work"
    manifest = {
        "run_name": "ringer-demo",
        "workdir": str(workdir),
        "max_parallel": 3,
        "worktrees": False,
        "repo": None,
        "tasks": [
            {
                "key": "alpha",
                "spec": "Create alpha.txt in the current working directory containing exactly: alpha ready. Do not write any other files.",
                "check": "test \"$(cat alpha.txt 2>/dev/null)\" = \"alpha ready\" || { echo 'FAIL: alpha.txt missing or content is not alpha ready'; exit 1; }",
                "verified": "alpha.txt exists and contains exactly the expected text",
                "expect_files": ["alpha.txt"],
            },
            {
                "key": "bravo",
                "spec": "Create bravo.txt in the current working directory containing exactly: bravo ready. Do not write any other files.",
                "check": "test \"$(cat bravo.txt 2>/dev/null)\" = \"bravo ready\" || { echo 'FAIL: bravo.txt missing or content is not bravo ready'; exit 1; }",
                "verified": "bravo.txt exists and contains exactly the expected text",
                "expect_files": ["bravo.txt"],
            },
            {
                "key": "charlie",
                "spec": "Create charlie.txt in the current working directory containing exactly: charlie ready. Do not write any other files.",
                "check": "test \"$(cat charlie.txt 2>/dev/null)\" = \"charlie ready\" || { echo 'FAIL: charlie.txt missing or content is not charlie ready'; exit 1; }",
                "verified": "charlie.txt exists and contains exactly the expected text",
                "expect_files": ["charlie.txt"],
            },
        ],
    }
    path = root / "ringer.json"
    path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return path
