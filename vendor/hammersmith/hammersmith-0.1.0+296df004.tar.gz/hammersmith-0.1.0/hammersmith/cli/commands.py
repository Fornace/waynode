"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import asyncio
import contextlib
import sys
from dataclasses import replace as dataclass_replace
from pathlib import Path

from hammersmith.adjudication import run_adjudicate_command
from hammersmith.catalog_cli import run_catalog_command, start_catalog_auto_refresh
from hammersmith.config import AppConfig
from hammersmith.config_loading import create_default_config, auto_detect_engines, print_setup_instructions
from hammersmith.manifest_lint import lint_manifest_detailed
from hammersmith.manifest_migration_cli import run_manifest_migration_command
from hammersmith.manifest_models import Manifest
from hammersmith.control_plane.launch import execute_manifest
from hammersmith.models_cli import run_models_command
from hammersmith.read_model_cli import run_db_command
from hammersmith.runner import HammersmithRunner
from hammersmith.utils.models import resolve_identity

from .hud import ensure_hud_running

from .agent_install import install_agent, uninstall_agent
from .hud import run_persistent_hud
from .parser import build_parser
from .user_commands import run_user_command
from .planning import (
    create_demo_manifest,
    dry_run,
    preflight_engine_bins,
    print_lint_detailed,
    print_steering_notes,
    validate_manifest_engines,
)


async def run_manifest(
    manifest: Manifest,
    config: AppConfig,
    identity: str,
    dashboard_enabled: bool,
    force_browser: bool,
) -> int:
    return await execute_manifest(
        manifest,
        config,
        identity,
        dashboard_enabled=dashboard_enabled,
        force_browser=force_browser,
    )

def main(argv: list[str] | None = None) -> int:
    # Keep progress lines live when stdout is a pipe (tee, orchestrators).
    with contextlib.suppress(Exception):
        sys.stdout.reconfigure(line_buffering=True)
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "init":
            output_path = getattr(args, "output", None)
            force = getattr(args, "force", False)
            from hammersmith.config_loading import default_config_path
            target = output_path or default_config_path()
            if target.exists() and not force:
                print(f"Config already exists: {target}", file=sys.stderr)
                print("Use --force to overwrite.", file=sys.stderr)
                return 1
            config_path = create_default_config(target)
            detected = auto_detect_engines()
            print(f"Created config: {config_path}")
            if detected:
                found = ", ".join(sorted(detected.keys()))
                print(f"Detected engines: {found}")
            else:
                print("No worker CLIs detected — install one to get started.")
                print("  npm install -g @earendil-works/pi-coding-agent")
            print("\nReady! Run: hammersmith demo")
            return 0

        if args.command == "tutorial":
            tutorial_path = Path(__file__).parent.parent.parent / "docs" / "TUTORIAL.md"
            if getattr(args, "open", False):
                import webbrowser
                webbrowser.open(f"file://{tutorial_path}")
                print(f"Opened tutorial: {tutorial_path}")
            else:
                print(tutorial_path.read_text())
            return 0

        if args.command == "user":
            return run_user_command(args)

        if args.command == "install-agent":
            return install_agent(project=args.project, targets=getattr(args, "target", None))
        if args.command == "uninstall-agent":
            return uninstall_agent(project=args.project, targets=getattr(args, "target", None))

        if args.command == "lint":
            try:
                manifest = Manifest.from_path(args.manifest)
            except Exception as exc:
                print(f"lint: ERROR: {exc}")
                return 1
            detailed_findings = lint_manifest_detailed(manifest)
            findings = [finding.message for finding in detailed_findings]
            if findings:
                print_lint_detailed(detailed_findings)
                return 1
            print(f"lint: clean ({len(manifest.tasks)} tasks)")
            return 0

        if args.command == "migrate-manifest":
            return run_manifest_migration_command(args)

        if args.command == "catalog":
            return run_catalog_command(args)

        config = AppConfig.load(args.config)
        if args.command == "db":
            return run_db_command(config, args)
        if args.command == "models":
            return run_models_command(config, args)
        if args.command == "adjudicate":
            return run_adjudicate_command(config, args)
        if args.command == "hud":
            return run_persistent_hud(
                config,
                port=args.port,
                open_viewer=not args.no_open,
            )

        if args.command == "demo":
            manifest_path = create_demo_manifest()
            print(f"Demo manifest: {manifest_path}")
        else:
            manifest_path = args.manifest
        manifest = Manifest.from_path(manifest_path).with_max_parallel(args.max_parallel)
        with contextlib.suppress(Exception):
            print_steering_notes(manifest, config)
        detailed_findings = lint_manifest_detailed(
            manifest, include_model_log_nudges=True
        )
        print_lint_detailed(detailed_findings)
        structural_errors = [
            finding.message for finding in detailed_findings if finding.severity == "error"
        ]
        if structural_errors:
            raise ValueError(
                f"manifest has {len(structural_errors)} structural contract error(s); run aborted"
            )
        if getattr(args, "strict", False) and detailed_findings:
            raise ValueError(
                f"strict manifest lint found {len(detailed_findings)} finding(s); run aborted"
            )
        validate_manifest_engines(manifest, config)
        identity_start_paths = [manifest.workdir]
        if manifest.source_path is not None:
            identity_start_paths.append(manifest.source_path.parent)
        identity = resolve_identity(args.identity, config, identity_start_paths)
        dashboard_enabled = not args.no_dashboard
        if getattr(args, "no_artifact", False) and config.artifact.enabled:
            config = dataclass_replace(config, artifact=dataclass_replace(config.artifact, enabled=False))
        if args.dry_run:
            dry_run(
                manifest,
                config=config,
                identity=identity,
                dashboard_enabled=dashboard_enabled,
                force_browser=args.browser,
            )
            return 0
        preflight_engine_bins(manifest, config)
        if args.command == "run":
            start_catalog_auto_refresh()
        if dashboard_enabled and not args.browser:
            ensure_hud_running(config, open_browser=True)
        return asyncio.run(
            run_manifest(
                manifest,
                config=config,
                identity=identity,
                dashboard_enabled=dashboard_enabled,
                force_browser=args.browser,
            )
        )
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"hammersmith: error: {exc}", file=sys.stderr)
        return 2
