"""CLI UI utilities for Hammersmith - colors, progress, spinners."""
from __future__ import annotations

import sys
import threading
import time
from typing import TextIO


# ANSI color codes
COLORS = {
    'reset': '\033[0m',
    'bold': '\033[1m',
    'dim': '\033[2m',
    'red': '\033[31m',
    'green': '\033[32m',
    'yellow': '\033[33m',
    'blue': '\033[34m',
    'magenta': '\033[35m',
    'cyan': '\033[36m',
    'white': '\033[37m',
}


def supports_color() -> bool:
    """Check if terminal supports color."""
    return hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()


def colored(text: str, color: str) -> str:
    """Apply color to text if terminal supports it."""
    if not supports_color():
        return text
    color_code = COLORS.get(color, '')
    reset = COLORS['reset']
    return f"{color_code}{text}{reset}"


def info(message: str, file: TextIO | None = None) -> None:
    """Print info message in blue."""
    file = file or sys.stderr
    print(colored('ℹ', 'blue'), message, file=file)


def success(message: str, file: TextIO | None = None) -> None:
    """Print success message in green."""
    file = file or sys.stderr
    print(colored('✓', 'green'), message, file=file)


def warning(message: str, file: TextIO | None = None) -> None:
    """Print warning message in yellow."""
    file = file or sys.stderr
    print(colored('⚠', 'yellow'), message, file=file)


def error(message: str, file: TextIO | None = None) -> None:
    """Print error message in red."""
    file = file or sys.stderr
    print(colored('✗', 'red'), message, file=file)


def bold(text: str) -> str:
    """Make text bold."""
    return colored(text, 'bold')


def dim(text: str) -> str:
    """Make text dim."""
    return colored(text, 'dim')


class ProgressBar:
    """Simple progress bar for CLI."""

    def __init__(
        self,
        total: int,
        desc: str = '',
        file: TextIO | None = None,
    ) -> None:
        self.total = total
        self.current = 0
        self.desc = desc
        self.file = file or sys.stderr
        self.width = 40

    def update(self, n: int = 1) -> None:
        """Update progress by n steps."""
        self.current = min(self.current + n, self.total)
        self._render()

    def _render(self) -> None:
        """Render progress bar."""
        if not supports_color():
            return

        percent = self.current / self.total if self.total > 0 else 0
        filled = int(self.width * percent)
        bar = '█' * filled + '░' * (self.width - filled)

        line = f'\r{self.desc} {colored(bar, "cyan")} {percent:.0%} ({self.current}/{self.total})'
        self.file.write(line)
        self.file.flush()

        if self.current >= self.total:
            self.file.write('\n')
            self.file.flush()


class Spinner:
    """Spinner animation for long-running operations."""

    FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']

    def __init__(self, message: str = '', file: TextIO | None = None) -> None:
        self.message = message
        self.file = file or sys.stderr
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def __enter__(self) -> 'Spinner':
        self.start()
        return self

    def __exit__(self, *args: object) -> None:
        self.stop()

    def start(self) -> None:
        """Start spinner animation."""
        if not supports_color():
            self.file.write(f'{self.message}\n')
            self.file.flush()
            return

        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop spinner animation."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=0.1)
        self.file.write('\r' + ' ' * (len(self.message) + 10) + '\r')
        self.file.flush()

    def _spin(self) -> None:
        """Spinner animation loop."""
        idx = 0
        while not self._stop_event.is_set():
            frame = self.FRAMES[idx % len(self.FRAMES)]
            self.file.write(f'\r{colored(frame, "cyan")} {self.message}')
            self.file.flush()
            idx += 1
            time.sleep(0.1)


def format_duration(seconds: float) -> str:
    """Format duration in human-readable form."""
    if seconds < 60:
        return f'{seconds:.1f}s'
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f'{minutes}m {secs}s'
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f'{hours}h {minutes}m'


def format_tokens(tokens: int | None) -> str:
    """Format token count."""
    if tokens is None:
        return 'N/A'
    if tokens < 1000:
        return str(tokens)
    elif tokens < 1_000_000:
        return f'{tokens / 1000:.1f}K'
    else:
        return f'{tokens / 1_000_000:.1f}M'


def format_cost(cost_usd: float | None) -> str:
    """Format cost in USD."""
    if cost_usd is None:
        return 'N/A'
    if cost_usd < 0.01:
        return f'${cost_usd:.4f}'
    elif cost_usd < 1.0:
        return f'${cost_usd:.3f}'
    else:
        return f'${cost_usd:.2f}'
