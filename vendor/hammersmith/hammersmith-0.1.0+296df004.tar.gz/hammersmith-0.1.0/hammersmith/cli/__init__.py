"""Command-line parsing, dispatch, installation, and HUD control."""


def main(argv: list[str] | None = None) -> int:
    from .commands import main as dispatch

    return dispatch(argv)


__all__ = ["main"]
