"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import argparse
from pathlib import Path

from hammersmith.catalog import DEFAULT_CATALOG_SOURCE
from hammersmith.config_models import DEFAULT_HUD_PORT
from hammersmith.identity import ORCHESTRATOR_NAME, PRODUCT_NAME
from hammersmith.model_identity import default_model_registry_path
from hammersmith.model_log import ADJUDICATION_OUTCOMES
from hammersmith.model_paths import default_model_notes_path

from hammersmith.agent.installer import TARGETS as AGENT_TARGETS

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hammersmith",
        description=(
            f"{PRODUCT_NAME} ({ORCHESTRATOR_NAME}): deterministic parallel AI-agent orchestrator. "
            "Runs manifest tasks in parallel, "
            "verifies artifacts with executed checks, applies failure-aware configurable retries, "
            "stops invalid contracts and infrastructure failures, logs eval rows, and serves a "
            "live dashboard."
        ),
    )
    parser.add_argument("--config", type=Path, help="path to config.toml (default: XDG config path)")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="run a Hammersmith manifest")
    run_parser.add_argument("manifest", type=Path, help="path to manifest.json")
    run_parser.add_argument("--config", type=Path, default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    run_parser.add_argument("--max-parallel", type=int, help="override manifest max_parallel")
    run_parser.add_argument("--identity", help="orchestrator identity for HUD state and eval rows")
    run_parser.add_argument("--no-dashboard", action="store_true", help="disable live dashboard")
    run_parser.add_argument("--browser", action="store_true", help=f"open the per-run dashboard instead of {PRODUCT_NAME}")
    run_parser.epilog = (
        "Set HAMMERSMITH_NO_CATALOG_REFRESH=1 to skip the non-blocking OpenRouter "
        "catalog auto-refresh."
    )
    run_parser.add_argument(
        "--no-artifact",
        action="store_true",
        help="disable zero-LLM HTML status/report artifacts (see [artifact] in config.toml)",
    )
    run_parser.add_argument("--dry-run", action="store_true", help="print the plan without spawning codex")
    run_parser.add_argument(
        "--strict",
        action="store_true",
        help="block the run on lint warnings as well as structural contract errors",
    )

    lint_parser = subparsers.add_parser("lint", help="lint a Hammersmith manifest")
    lint_parser.add_argument("manifest", type=Path, help="path to manifest.json")

    migrate_parser = subparsers.add_parser(
        "migrate-manifest",
        help="preview or write a fail-closed legacy manifest translation",
    )
    migrate_parser.add_argument("manifest", type=Path, help="legacy manifest to inspect")
    migrate_parser.add_argument(
        "--output",
        type=Path,
        help="write the translated manifest here; the source is never overwritten",
    )
    migrate_parser.add_argument(
        "--force",
        action="store_true",
        help="replace an existing output file (never replaces the source)",
    )
    migrate_parser.add_argument(
        "--json",
        action="store_true",
        help="emit the migration report and proposed manifest as JSON",
    )

    hud_parser = subparsers.add_parser("hud", help=f"start the persistent {PRODUCT_NAME} page in your browser")
    hud_parser.add_argument("--config", type=Path, default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    hud_parser.add_argument("--port", type=int, help=f"port to bind on 127.0.0.1 (default: {DEFAULT_HUD_PORT})")
    hud_parser.add_argument("--no-open", action="store_true", help="start the server without opening a browser")

    db_parser = subparsers.add_parser("db", help="manage the derived SQLite read model")
    db_parser.add_argument("--config", type=Path, default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    db_subparsers = db_parser.add_subparsers(dest="db_command", required=True)
    for name in ("rebuild", "sync"):
        sub = db_subparsers.add_parser(name, help=f"{name} the derived SQLite read model")
        sub.add_argument("--db", type=Path, help="path to SQLite read model (default: ~/.hammersmith/hammersmith.db)")
        sub.add_argument("--log", type=Path, help="path to local eval JSONL log")
        sub.add_argument("--catalog-file", type=Path, help="path to local OpenRouter catalog snapshot")
        sub.add_argument("--registry", type=Path, help="path to model identity registry")

    models_parser = subparsers.add_parser("models", help="show the local per-model performance scoreboard")
    models_parser.add_argument("--config", type=Path, default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    models_parser.add_argument("--log", type=Path, help="path to local eval JSONL log")
    models_parser.add_argument("--db", type=Path, help="path to SQLite read model (default: ~/.hammersmith/hammersmith.db)")
    models_parser.add_argument("--task-type", help="only include one task_type bucket")
    models_parser.add_argument("--model", help="only include one resolved model bucket")
    models_parser.add_argument("--engine", help="only include rows from one worker engine")
    models_parser.add_argument("--since", help="only include rows logged on or after YYYY-MM-DD")
    models_parser.add_argument("--explore", action="store_true", help="show proven/probation tiers plus cheap untested catalog candidates")
    models_parser.add_argument("--catalog-file", type=Path, help="path to local OpenRouter catalog snapshot")
    models_parser.add_argument("--notes-file", type=Path, default=default_model_notes_path(), help="path to MODEL-NOTES.md judgment layer")
    models_parser.add_argument("--registry", type=Path, default=default_model_registry_path(), help=argparse.SUPPRESS)
    models_parser.add_argument("--html", nargs="?", const="", help="render a self-contained HTML scoreboard; optional output path")
    models_parser.add_argument("--open", action="store_true", help="render the HTML scoreboard to the artifact library and open it")
    models_parser.add_argument("--json", action="store_true", help="print the scoreboard as JSON")

    adjudicate_parser = subparsers.add_parser(
        "adjudicate",
        help="append a parent decision for a completed task without rewriting attempt evidence",
    )
    adjudicate_parser.add_argument("--config", type=Path, default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    adjudicate_parser.add_argument("run_id")
    adjudicate_parser.add_argument("task_key")
    adjudicate_parser.add_argument("--outcome", required=True, choices=sorted(ADJUDICATION_OUTCOMES))
    adjudicate_parser.add_argument("--reason", required=True)
    adjudicate_parser.add_argument("--adjudicator", default="operator")

    catalog_parser = subparsers.add_parser("catalog", help="show or refresh the local OpenRouter model catalog")
    catalog_parser.add_argument("--refresh", action="store_true", help="fetch source and rewrite the local snapshot")
    catalog_parser.add_argument("--source", help=f"OpenRouter models URL or fixture file (default: {DEFAULT_CATALOG_SOURCE})")
    catalog_parser.add_argument("--file", type=Path, help="catalog snapshot path (default: ~/.hammersmith/openrouter-catalog.json)")
    catalog_parser.add_argument("--free", action="store_true", help="show free models only")
    catalog_parser.add_argument("--changes", action="store_true", help="show recent catalog changes newest first")
    catalog_parser.add_argument("--json", action="store_true", help="print the model list as JSON and nothing else")

    demo_parser = subparsers.add_parser("demo", help="generate and run a 3-task toy manifest in /tmp")
    demo_parser.add_argument("--config", type=Path, default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    demo_parser.add_argument("--max-parallel", type=int, help="override demo max_parallel")
    demo_parser.add_argument("--identity", help="orchestrator identity for HUD state and eval rows")
    demo_parser.add_argument("--no-dashboard", action="store_true", help="disable live dashboard")
    demo_parser.add_argument("--browser", action="store_true", help=f"open the per-run dashboard instead of {PRODUCT_NAME}")
    demo_parser.add_argument(
        "--no-artifact",
        action="store_true",
        help="disable zero-LLM HTML status/report artifacts (see [artifact] in config.toml)",
    )
    demo_parser.add_argument("--dry-run", action="store_true", help="print the demo plan without spawning codex")

    init_parser = subparsers.add_parser(
        "init",
        help="create a minimal config file with sensible defaults (zero-config quickstart)",
    )
    init_parser.add_argument(
        "--output",
        type=Path,
        help="where to write the config (default: ~/.config/hammersmith/config.toml)",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="overwrite an existing config file",
    )

    tutorial_parser = subparsers.add_parser(
        "tutorial",
        help="show an interactive tutorial on how to use Hammersmith",
    )
    tutorial_parser.add_argument(
        "--open",
        action="store_true",
        help="open the tutorial in your browser",
    )

    install_parser = subparsers.add_parser(
        "install-agent",
        help="install the Hammersmith orchestrator skill (+ nudge hooks) for agent harnesses",
    )
    install_parser.add_argument(
        "--project",
        action="store_true",
        help="install Claude Code at ./.claude instead of ~/.claude (Pi/Codex are always user-scope)",
    )
    install_parser.add_argument(
        "--target",
        action="append",
        choices=list(AGENT_TARGETS),
        metavar="NAME",
        help="install only for this harness (repeatable: claude, pi, codex, opencode). Default: auto-detect all",
    )

    uninstall_parser = subparsers.add_parser(
        "uninstall-agent",
        help="remove the Hammersmith orchestrator skill and hooks",
    )
    uninstall_parser.add_argument(
        "--project",
        action="store_true",
        help="remove from ./.claude instead of ~/.claude",
    )
    uninstall_parser.add_argument(
        "--target",
        action="append",
        choices=list(AGENT_TARGETS),
        metavar="NAME",
        help="remove only for this harness (repeatable: claude, pi, codex, opencode). Default: sweep all",
    )

    # User management commands
    user_parser = subparsers.add_parser("user", help="manage Hammersmith users")
    user_subparsers = user_parser.add_subparsers(dest="user_command", required=True)

    user_create_parser = user_subparsers.add_parser("create", help="create a new user")
    user_create_parser.add_argument("username", help="username for the new user")
    user_create_parser.add_argument("--password", help="password (will prompt if not provided)")
    user_create_parser.add_argument("--role", choices=["admin", "user", "viewer"], default="user", help="user role (default: user)")

    user_list_parser = user_subparsers.add_parser("list", help="list all users")
    user_list_parser.add_argument("--json", action="store_true", help="output as JSON")

    user_delete_parser = user_subparsers.add_parser("delete", help="delete a user")
    user_delete_parser.add_argument("username", help="username to delete")
    user_delete_parser.add_argument("--force", action="store_true", help="skip confirmation")

    user_reset_parser = user_subparsers.add_parser("reset-password", help="reset a user's password")
    user_reset_parser.add_argument("username", help="username")
    user_reset_parser.add_argument("--password", help="new password (will prompt if not provided)")

    return parser
