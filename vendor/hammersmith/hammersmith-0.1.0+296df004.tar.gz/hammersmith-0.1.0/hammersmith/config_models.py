"""Data models and constants used by Hammersmith configuration."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

TOOL_NAME = "ringer"
STATE_DIR_NAME = ".hammersmith"
CONFIG_DIR_NAME = TOOL_NAME
CONFIG_FILE_NAME = "config.toml"
DEFAULT_ENGINE_NAME = "pi"
DEFAULT_DASHBOARD_PORT_BASE = 8787
DEFAULT_HUD_PORT = 8700
DEFAULT_TOKEN_REGEX = r"tokens\s+used\s*:?\s*([0-9][0-9,]*)"
DEFAULT_CODEX_MODEL_REPORT_REGEX = r"(?m)^model:[ \t]*([^ \t\r\n]+)[ \t]*\r?$"


@dataclass(frozen=True)
class EngineConfig:
    name: str
    bin: str
    args_template: tuple[str, ...]
    full_access_args: tuple[str, ...]
    sandbox_args: tuple[str, ...]
    token_regex: str | None = DEFAULT_TOKEN_REGEX
    model_report_regex: str | None = None
    # Supplies {model} when a task does not set one, keeping harness engines
    # model-agnostic instead of hard-coding a model into the command line.
    model_default: str = ""

    @property
    def process_name(self) -> str:
        return Path(self.bin).name or self.name


@dataclass(frozen=True)
class PostgresEvalConfig:
    env_file: Path


@dataclass(frozen=True)
class EvalConfig:
    backend: str
    jsonl_path: Path
    postgres: PostgresEvalConfig | None = None


@dataclass(frozen=True)
class ArtifactConfig:
    """Tier 0 HTML artifact locations and path templates."""

    enabled: bool
    out_template: str
    report_template: str
    index_out: Path

    def artifact_path(self, run_id: str, run_name: str) -> Path:
        return Path(format_artifact_template(self.out_template, run_id, run_name))

    def report_path(self, run_id: str, run_name: str) -> Path:
        return Path(format_artifact_template(self.report_template, run_id, run_name))


@dataclass(frozen=True)
class FailureSummaryConfig:
    """Optional OpenAI-compatible failure summarization; never affects verdicts."""

    enabled: bool = False
    model: str = "fornace-fast"
    base_url: str = ""
    base_url_env: str = "FORNACE_LLM_BASE_URL"
    api_key_env: str = "FORNACE_LLM_API_KEY"
    env_file: Path | None = None
    ca_file: Path | None = None
    ca_file_env: str = "SSL_CERT_FILE"
    timeout_s: float = 8.0
    max_input_chars: int = 24_000
    max_output_chars: int = 2_000
    max_tokens: int = 1_024


def format_artifact_template(template: str, run_id: str, run_name: str) -> str:
    text = template.replace("{run_id}", run_id).replace("{run_name}", run_name)
    return str(Path(text).expanduser())
