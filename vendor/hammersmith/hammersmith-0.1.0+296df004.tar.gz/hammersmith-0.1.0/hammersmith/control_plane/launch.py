"""Shared runner launch boundary for CLI and HTTP owners."""

from __future__ import annotations

import asyncio
import threading
from importlib import import_module
from typing import Any

from hammersmith.active_runs import register_active_run, unregister_active_run
from hammersmith.config import AppConfig
from hammersmith.manifest_models import Manifest

from .events import EventJournal


async def execute_manifest(
    manifest: Manifest,
    config: AppConfig,
    identity: str,
    *,
    dashboard_enabled: bool,
    force_browser: bool,
) -> int:
    runner_class = getattr(import_module("hammersmith.runner"), "HammersmithRunner")
    runner = runner_class(
        manifest,
        config=config,
        identity=identity,
        dashboard_enabled=dashboard_enabled,
        force_browser=force_browser,
    )
    register_active_run(
        runner.run_id,
        identity,
        manifest.run_name,
        manifest.workdir,
        started_at=runner.started_at,
        project=manifest.project,
        root_run_id=runner.root_run_id,
        parent_run_id=manifest.parent_run_id,
        replay_of=manifest.replay_of,
    )
    try:
        return await runner.run()
    finally:
        unregister_active_run(runner.run_id)


class ThreadedRunHandle:
    def __init__(
        self,
        runner: Any,
        journal: EventJournal,
    ) -> None:
        self.runner = runner
        self.run_id = runner.run_id
        self.journal = journal
        self._loop: asyncio.AbstractEventLoop | None = None
        self._task: asyncio.Task[int] | None = None
        self._ready = threading.Event()
        self._thread: threading.Thread | None = None
        self._cancel_requested = False

    async def _run(self) -> int:
        register_active_run(
            self.runner.run_id,
            self.runner.identity,
            self.runner.manifest.run_name,
            self.runner.manifest.workdir,
            started_at=self.runner.started_at,
            project=self.runner.manifest.project,
            root_run_id=self.runner.root_run_id,
            parent_run_id=self.runner.manifest.parent_run_id,
            replay_of=self.runner.manifest.replay_of,
        )
        try:
            return await self.runner.run()
        finally:
            unregister_active_run(self.runner.run_id)

    def _thread_main(self) -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        self._loop = loop
        self._task = loop.create_task(self._run())
        self._ready.set()
        try:
            loop.run_until_complete(self._task)
        except asyncio.CancelledError:
            pass
        finally:
            if self._cancel_requested:
                self.journal.append(
                    {"action": "cancel", "run_id": self.run_id, "status": "host_cancelled"}
                )
            loop.close()

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._thread_main,
            name=f"hammersmith-control-{self.run_id}",
            daemon=True,
        )
        self._thread.start()

    def request_cancel(self) -> bool:
        if not self._ready.wait(timeout=2):
            return False
        if self._cancel_requested:
            return True
        if self._loop is None or self._task is None or self._task.done():
            return False
        self._cancel_requested = True
        self._loop.call_soon_threadsafe(self._task.cancel)
        return True


class ThreadedLauncher:
    def __init__(self, journal: EventJournal) -> None:
        self.journal = journal

    def prepare(self, manifest: Manifest, config: AppConfig, identity: str) -> ThreadedRunHandle:
        runner_class = getattr(import_module("hammersmith.runner"), "HammersmithRunner")
        runner = runner_class(
            manifest,
            config=config,
            identity=identity,
            dashboard_enabled=False,
            force_browser=False,
        )
        return ThreadedRunHandle(runner, self.journal)
