"""One run projection used by run and project HTTP views."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from hammersmith.http_server.state import build_projects_snapshot, scan_hud_run_states

from .adjudications import AdjudicationStore
from .events import EventJournal


class RunQueryService:
    def __init__(self, state_dir: Path) -> None:
        self.state_dir = state_dir
        self.adjudications = AdjudicationStore(state_dir)
        self.events = EventJournal(state_dir)
        self._control: Callable[[dict[str, Any], str, bool], dict[str, bool]] | None = None

    def bind_control_projection(
        self, projection: Callable[[dict[str, Any], str, bool], dict[str, bool]]
    ) -> None:
        self._control = projection

    def list_runs(
        self,
        *,
        limit: int | None = 12,
        actor: str = "",
        admin: bool = False,
    ) -> list[dict[str, Any]]:
        runs = scan_hud_run_states(self.state_dir, limit=limit)
        adjudications = self.adjudications.latest()
        for run in runs:
            run.pop("_snapshot_mtime", None)
            run_id = str(run.get("run_id", ""))
            control_status = self.events.latest_status(run_id)
            if control_status:
                run["execution_state"] = run.get("state")
                run["state"] = control_status
                run["control_status"] = control_status
            for task in run.get("tasks", []) if isinstance(run.get("tasks"), list) else []:
                if not isinstance(task, dict):
                    continue
                event = adjudications.get((run_id, str(task.get("key", ""))))
                if event is not None:
                    task["adjudication"] = event
                    if event.get("outcome") in {"invalid-task", "infrastructure"}:
                        task["model_eligible"] = False
            if self._control is not None:
                run["control"] = self._control(run, actor, admin)
        return runs

    def get_run(
        self, run_id: str, *, actor: str = "", admin: bool = False
    ) -> dict[str, Any] | None:
        for run in self.list_runs(limit=None, actor=actor, admin=admin):
            if run.get("run_id") == run_id:
                return run
        return None

    def projects(self, *, actor: str = "", admin: bool = False) -> dict[str, Any]:
        payload = build_projects_snapshot(self.state_dir)
        projected = {
            str(run.get("run_id")): run
            for run in self.list_runs(limit=None, actor=actor, admin=admin)
        }
        for project in payload.get("projects", []):
            if not isinstance(project, dict):
                continue
            for row in project.get("runs", []):
                if not isinstance(row, dict):
                    continue
                run = projected.get(str(row.get("run_id")))
                if run is None:
                    continue
                if run.get("control_status"):
                    row["execution_status"] = row.get("status")
                    row["status"] = run["control_status"]
                row["control"] = dict(run.get("control", {}))
        return payload
