"""Idempotent validated-plan launch and owner-handle cancellation services."""

from __future__ import annotations

import hashlib
import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

from hammersmith.config import AppConfig
from hammersmith.cli.planning import preflight_engine_bins, validate_manifest_engines
from hammersmith.manifest_lint import lint_manifest_detailed
from hammersmith.state_io import atomic_write_text, interprocess_lock

from .canonical import canonical_digest, canonical_json_bytes
from .errors import RunConflict
from .events import EventJournal
from .query import RunQueryService
from .validation import ValidatedPlanStore


class RunHandle(Protocol):
    run_id: str

    def start(self) -> None: ...
    def request_cancel(self) -> bool: ...


class Launcher(Protocol):
    def prepare(self, manifest: Any, config: AppConfig, identity: str) -> RunHandle: ...


class RunService:
    def __init__(
        self,
        config: AppConfig,
        plans: ValidatedPlanStore,
        *,
        launcher: Launcher | None = None,
        query: RunQueryService | None = None,
    ) -> None:
        self.config = config
        self.plans = plans
        self.journal = EventJournal(config.state_dir)
        if launcher is None:
            from .launch import ThreadedLauncher

            launcher = ThreadedLauncher(self.journal)
        self.launcher = launcher
        self.query = query or RunQueryService(config.state_dir)
        self.actions_root = config.state_dir / "control-plane" / "actions"
        self.manifests_root = config.state_dir / "control-plane" / "manifests"
        self.lock_path = config.state_dir / "control-plane" / ".actions.lock"
        self._handles: dict[str, RunHandle] = {}
        self._handles_lock = threading.RLock()
        self.query.bind_control_projection(self.control_for_run)

    @staticmethod
    def _validate_idempotency_key(value: str) -> str:
        if not isinstance(value, str) or not value.strip() or len(value) > 200:
            raise ValueError("Idempotency-Key must be a non-empty string of at most 200 characters")
        return value.strip()

    @staticmethod
    def _action_id(actor: str, action: str, key: str) -> str:
        return hashlib.sha256(f"{actor}\0{action}\0{key}".encode("utf-8")).hexdigest()

    def _action_path(self, action_id: str) -> Path:
        return self.actions_root / f"{action_id}.json"

    @staticmethod
    def _read(path: Path) -> dict[str, Any] | None:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (FileNotFoundError, OSError, json.JSONDecodeError, UnicodeDecodeError):
            return None
        return value if isinstance(value, dict) else None

    def _existing(self, action_id: str, request_digest: str) -> dict[str, Any] | None:
        existing = self._read(self._action_path(action_id))
        if existing is None:
            return None
        if existing.get("request_digest") != request_digest:
            raise RunConflict("idempotency key was used for another request")
        return existing

    def launch(
        self,
        *,
        plan_id: str,
        digest: str,
        confirmation: bool,
        idempotency_key: str,
        actor: str,
        admin: bool = False,
    ) -> dict[str, Any]:
        if confirmation is not True:
            raise RunConflict("explicit launch confirmation is required")
        key = self._validate_idempotency_key(idempotency_key)
        request = {"plan_id": plan_id, "digest": digest, "confirmation": True}
        request_digest = canonical_digest(request)
        action_id = self._action_id(actor, "launch", key)
        with interprocess_lock(self.lock_path):
            existing = self._existing(action_id, request_digest)
            if existing is not None:
                return existing
            plan = self.plans.resolve(
                plan_id, digest=digest, actor=actor, config=self.config, admin=admin
            )
            try:
                validate_manifest_engines(plan.manifest, self.config)
                preflight_engine_bins(plan.manifest, self.config)
            except ValueError as exc:
                raise RunConflict("engine preflight changed after validation") from exc
            structural = [
                finding.message
                for finding in lint_manifest_detailed(plan.manifest)
                if finding.severity == "error"
            ]
            if structural:
                raise RunConflict("manifest preflight changed after validation")
            for task in plan.manifest.tasks:
                base = (
                    plan.manifest.repo
                    if plan.manifest.worktrees and plan.manifest.repo is not None
                    else plan.manifest.workdir / task.key
                )
                for raw in task.required_inputs:
                    candidate = Path(raw).expanduser()
                    candidate = candidate if candidate.is_absolute() else base / candidate
                    if not candidate.exists():
                        raise RunConflict("required input changed after validation")
            handle = self.launcher.prepare(plan.manifest, self.config, actor)
            manifest_path = self.manifests_root / f"{handle.run_id}.json"
            if manifest_path.parent.resolve() != self.manifests_root.resolve():
                raise RunConflict("launcher returned an invalid run identifier")
            atomic_write_text(
                manifest_path, canonical_json_bytes(plan.canonical).decode("utf-8") + "\n"
            )
            receipt = {
                "action": "launch",
                "action_id": action_id,
                "request_digest": request_digest,
                "run_id": handle.run_id,
                "owner": actor,
                "manifest_digest": plan.digest,
                "status": "prepared",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            atomic_write_text(
                self._action_path(action_id), canonical_json_bytes(receipt).decode("utf-8") + "\n"
            )
            self.journal.append(receipt)
            try:
                handle.start()
            except Exception:
                receipt = {
                    **receipt,
                    "status": "start_failed",
                    "completed_at": datetime.now(timezone.utc).isoformat(),
                    "failure": "handle_start_failed",
                }
                atomic_write_text(
                    self._action_path(action_id),
                    canonical_json_bytes(receipt).decode("utf-8") + "\n",
                )
                self.journal.append(receipt)
                return receipt
            with self._handles_lock:
                self._handles[handle.run_id] = handle
            receipt = {
                **receipt,
                "status": "started",
                "completed_at": datetime.now(timezone.utc).isoformat(),
            }
            atomic_write_text(
                self._action_path(action_id), canonical_json_bytes(receipt).decode("utf-8") + "\n"
            )
            self.journal.append(receipt)
            return receipt

    def owner_for_run(self, run_id: str) -> str | None:
        try:
            paths = self.actions_root.glob("*.json")
        except OSError:
            return None
        for path in paths:
            try:
                if path.resolve().parent != self.actions_root.resolve():
                    continue
            except OSError:
                continue
            row = self._read(path)
            if row and row.get("action") == "launch" and row.get("run_id") == run_id:
                owner = row.get("owner")
                return owner if isinstance(owner, str) else None
        return None

    def _approved_manifest_available(self, run_id: str) -> bool:
        allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
        if not run_id or len(run_id) > 200 or any(char not in allowed for char in run_id):
            return False
        try:
            path = (self.manifests_root / f"{run_id}.json").resolve()
            return path.parent == self.manifests_root.resolve() and path.is_file()
        except OSError:
            return False

    @staticmethod
    def _terminal(run: dict[str, Any]) -> bool:
        state = str(run.get("state", "")).casefold()
        return bool(run.get("finished")) or state in {
            "finished", "pass", "fail", "failed", "error", "host_cancelled", "died",
            "start_failed",
        }

    def control_for_run(
        self, run: dict[str, Any], actor: str, admin: bool = False
    ) -> dict[str, bool]:
        run_id = str(run.get("run_id", ""))
        owner = self.owner_for_run(run_id)
        allowed = bool(actor) and owner is not None and (admin or owner == actor)
        terminal = self._terminal(run)
        tasks = run.get("tasks", []) if isinstance(run.get("tasks"), list) else []
        task_states = {
            str(task.get("status", "")).casefold()
            for task in tasks
            if isinstance(task, dict)
        }
        adjudicatable = bool(
            task_states
            & {"pass", "fail", "failed", "error", "timeout", "died", "host_cancelled"}
        )
        failed = bool(
            task_states & {"fail", "failed", "error", "timeout", "died", "host_cancelled"}
            or any(isinstance(task, dict) and task.get("failure_class") for task in tasks)
        )
        with self._handles_lock:
            has_handle = run_id in self._handles
        approved = self._approved_manifest_available(run_id)
        return {
            "can_cancel": allowed and has_handle and not terminal,
            "can_adjudicate": allowed and adjudicatable,
            "can_replay": allowed and approved and terminal,
            "can_repair": allowed and approved and terminal and failed,
            "can_export": bool(actor),
        }

    def replay_draft(
        self,
        run_id: str,
        *,
        drafts: Any,
        kind: str,
        confirmation: bool,
        idempotency_key: str,
        actor: str,
        admin: bool = False,
    ) -> dict[str, Any]:
        from .recovery import RecoveryService

        return RecoveryService(self, drafts).create(
            run_id,
            kind=kind,
            confirmation=confirmation,
            idempotency_key=idempotency_key,
            actor=actor,
            admin=admin,
        )

    def cancel(
        self,
        run_id: str,
        *,
        confirmation: bool,
        idempotency_key: str,
        actor: str,
        admin: bool = False,
    ) -> dict[str, Any]:
        if confirmation is not True:
            raise RunConflict("explicit cancellation confirmation is required")
        key = self._validate_idempotency_key(idempotency_key)
        request = {"run_id": run_id, "confirmation": True}
        request_digest = canonical_digest(request)
        action_id = self._action_id(actor, "cancel", key)
        with interprocess_lock(self.lock_path):
            existing = self._existing(action_id, request_digest)
            if existing is not None:
                return existing
            owner = self.owner_for_run(run_id)
            if owner is None:
                raise RunConflict("cancellation is unavailable for an unowned run")
            if not admin and owner != actor:
                raise RunConflict("cancellation is unavailable for this actor")
            run = self.query.get_run(run_id)
            if run is not None and str(run.get("state", "")).casefold() in {
                "finished", "pass", "fail", "host_cancelled", "died"
            }:
                raise RunConflict("run is already terminal")
            with self._handles_lock:
                handle = self._handles.get(run_id)
            if handle is None or not handle.request_cancel():
                raise RunConflict("cancellation owner handle is unavailable")
            receipt = {
                "action": "cancel",
                "action_id": action_id,
                "request_digest": request_digest,
                "run_id": run_id,
                "owner": owner,
                "requested_by": actor,
                "status": "cancelling",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            atomic_write_text(
                self._action_path(action_id), canonical_json_bytes(receipt).decode("utf-8") + "\n"
            )
            self.journal.append(receipt)
            return receipt
