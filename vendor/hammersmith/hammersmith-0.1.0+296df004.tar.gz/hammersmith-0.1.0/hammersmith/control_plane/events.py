"""Append-only action events and projections for control-plane mutations."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from hammersmith.state_io import interprocess_lock


class EventJournal:
    def __init__(self, state_dir: Path) -> None:
        self.path = state_dir / "control-plane-events.jsonl"
        self.lock_path = state_dir / ".control-plane-events.lock"

    def append(self, event: dict[str, Any]) -> dict[str, Any]:
        row = dict(event)
        row.setdefault("logged_at", datetime.now(timezone.utc).isoformat())
        line = json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
        with interprocess_lock(self.lock_path):
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(line)
                handle.flush()
        return row

    def read(self, *, run_id: str | None = None) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        with interprocess_lock(self.lock_path):
            try:
                lines = self.path.read_text(encoding="utf-8").splitlines()
            except (FileNotFoundError, OSError, UnicodeDecodeError):
                lines = []
        for line in lines:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(row, dict):
                continue
            if run_id is None or row.get("run_id") == run_id:
                rows.append(row)
        return rows

    def latest_status(self, run_id: str) -> str | None:
        status = None
        for row in self.read(run_id=run_id):
            value = row.get("status")
            if value in {"cancelling", "host_cancelled", "start_failed"}:
                status = value
        return status
