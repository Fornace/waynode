"""Shared control-plane exception types.

Kept dependency-free so :mod:`runs` and :mod:`recovery` can both import it
without forming a static import cycle (guarded by
``tests/test_runtime_modules.py``).
"""
from __future__ import annotations


class RunConflict(RuntimeError):
    """A run mutation conflicts with current server state, owner, or actor."""
