"""AI-assisted manifest authoring backed by an OpenAI-compatible gateway.

The control plane calls an external LLM gateway (for example the fornace.net
``fornace-reasoning`` model) to turn a natural-language goal into a canonical
Hammersmith manifest object. The generated manifest is always run through
:class:`~hammersmith.manifest_models.Manifest` before it is returned, so the
output is authoritatively valid (or a structured error is raised). This service
never writes, launches, or mutates anything — it only produces an inert draft
for the caller to review, validate, and launch through the existing flow.
"""
from __future__ import annotations

import json
import ssl
from dataclasses import dataclass
from typing import Any

from hammersmith.manifest_models import Manifest


SYSTEM_PROMPT = (
    "You generate Hammersmith task manifests. Output ONLY a JSON object with "
    "this exact shape — no prose, no markdown fences, nothing else:\n"
    '{"run_name": string, "project": string, "workdir": string, "tasks": ['
    '{"key": string, "spec": string (detailed), "check": string (an executable '
    "shell command that verifies the task's outputs), \"engine\": \"pi\", "
    '"expect_files": [string], "verified": string (what the check proves), '
    '"task_type": string (code, code-fix, docs, research, probe, ...)}]}\n'
    "Rules:\n"
    "- workdir is an absolute path under /tmp/hammersmith-ai-runs/<slug>.\n"
    "- Every task's check MUST be an executable shell command that fails when "
    "the work is wrong or incomplete.\n"
    "- Split the goal into 2-4 independent parallel tasks when possible.\n"
    "- Be concrete and detailed in each spec so a worker can implement it "
    "without further questions."
)


class AIAssistError(RuntimeError):
    """Raised when AI authoring fails for a mapped, client-visible reason."""

    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(code)
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class GatewayConfig:
    base_url: str
    api_key: str
    model: str
    timeout_s: float = 90.0
    temperature: float = 0.3

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> "GatewayConfig | None":
        import os

        e = env if env is not None else os.environ
        base = e.get("HAMMERSMITH_AI_GATEWAY_URL") or e.get("FORNACE_LLM_BASE_URL")
        key = e.get("HAMMERSMITH_AI_GATEWAY_KEY") or e.get("FORNACE_LLM_API_KEY")
        model = e.get("HAMMERSMITH_AI_GATEWAY_MODEL") or "fornace-reasoning"
        if not (base and key):
            return None
        return cls(base_url=base.rstrip("/"), api_key=key, model=model)


def _ssl_context() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    try:
        import certifi

        ctx.load_verify_locations(cafile=certifi.where())
    except Exception:
        pass
    return ctx


class AIAssistService:
    def __init__(self, gateway: GatewayConfig) -> None:
        self.gateway = gateway

    def author(self, goal: str, *, constraints: dict[str, Any] | None = None) -> dict[str, Any]:
        goal = (goal or "").strip()
        if not goal:
            raise AIAssistError("goal_required")
        if len(goal) > 4000:
            raise AIAssistError("goal_too_long")
        user_prompt = self._build_user_prompt(goal, constraints)
        raw = self._complete(user_prompt)
        manifest = self._parse_manifest(raw)
        self._validate(manifest)
        return {
            "manifest": manifest,
            "model": self.gateway.model,
            "goal": goal,
            "constraints": constraints or {},
        }

    def _build_user_prompt(self, goal: str, constraints: dict[str, Any] | None) -> str:
        parts = [f"Goal: {goal}"]
        if constraints:
            allowed = {"project", "engine", "max_tasks", "workdir_root", "task_type"}
            extras = {k: v for k, v in constraints.items() if k in allowed and v}
            if extras:
                parts.append("Constraints: " + json.dumps(extras))
        return "\n".join(parts)

    def _complete(self, user_prompt: str) -> str:
        import urllib.error
        import urllib.request

        body = json.dumps(
            {
                "model": self.gateway.model,
                "temperature": self.gateway.temperature,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
            }
        ).encode("utf-8")
        request = urllib.request.Request(
            f"{self.gateway.base_url}/v1/chat/completions",
            data=body,
            headers={
                "Authorization": f"Bearer {self.gateway.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(
                request, timeout=self.gateway.timeout_s, context=_ssl_context()
            ) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise AIAssistError("gateway_http_error", f"HTTP {exc.code}") from exc
        except urllib.error.URLError as exc:
            raise AIAssistError("gateway_unreachable", str(exc.reason)) from exc
        except (TimeoutError, OSError) as exc:
            raise AIAssistError("gateway_timeout", str(exc)) from exc
        choices = payload.get("choices") if isinstance(payload, dict) else None
        if not isinstance(choices, list) or not choices:
            raise AIAssistError("gateway_empty_response")
        message = choices[0].get("message", {}) if isinstance(choices[0], dict) else {}
        content = message.get("content") if isinstance(message, dict) else None
        if not isinstance(content, str) or not content.strip():
            raise AIAssistError("gateway_empty_response")
        return content

    def _parse_manifest(self, content: str) -> dict[str, Any]:
        text = content.strip()
        if text.startswith("```"):
            text = text.strip("`")
            if text.lower().startswith("json"):
                text = text[4:]
            text = text.strip()
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            raise AIAssistError("manifest_not_json", str(exc)) from exc
        if not isinstance(value, dict):
            raise AIAssistError("manifest_not_object")
        return value

    def _validate(self, manifest: dict[str, Any]) -> None:
        try:
            Manifest.from_obj(manifest)
        except Exception as exc:
            raise AIAssistError("manifest_invalid", str(exc)) from exc
