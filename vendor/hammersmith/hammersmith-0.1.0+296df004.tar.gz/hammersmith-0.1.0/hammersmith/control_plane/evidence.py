"""Trusted, portable evidence capabilities derived from persisted run metadata."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Iterable


SENSITIVE_MARKERS = (
    ".env", "auth", "cookie", "credential", "password", "private_key",
    "secret", "token", "api_key",
)
HOST_PATH_PREFIXES = ("/Users/", "/home/", "/private/", "/tmp/", "/var/", "/opt/")


def safe_component(value: str, *, max_length: int = 200) -> str | None:
    allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
    if not value or len(value) > max_length or any(char not in allowed for char in value):
        return None
    return value


def sensitive_name(path: Path | PurePosixPath) -> bool:
    return any(
        marker in part.casefold()
        for part in path.parts
        for marker in SENSITIVE_MARKERS
    )


def _json_object(path: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    return value if isinstance(value, dict) else None


def _within(path: Path, root: Path) -> bool:
    return path != root and root in path.parents


def _root(raw: Any) -> Path | None:
    if not isinstance(raw, str) or not raw or not Path(raw).is_absolute():
        return None
    try:
        resolved = Path(raw).expanduser().resolve()
    except (OSError, RuntimeError, ValueError):
        return None
    if resolved == resolved.parent or not resolved.is_dir():
        return None
    return resolved


@dataclass(frozen=True)
class EvidenceRoot:
    label: str
    path: Path


class RunEvidence:
    """A capability assembled only from server-persisted state and approved manifests."""

    def __init__(self, state_dir: Path, run_id: str) -> None:
        safe = safe_component(run_id)
        if safe is None:
            raise FileNotFoundError("run not found")
        self.state_dir = state_dir.expanduser().resolve()
        self.run_id = safe
        runs_root = (self.state_dir / "runs").resolve()
        state_path = (runs_root / f"{safe}.json").resolve()
        if state_path.parent != runs_root:
            raise FileNotFoundError("run not found")
        self.state = _json_object(state_path)
        if self.state is None:
            raise FileNotFoundError("run not found")
        manifests_root = (self.state_dir / "control-plane" / "manifests").resolve()
        manifest_path = (manifests_root / f"{safe}.json").resolve()
        self.manifest = (
            _json_object(manifest_path) if manifest_path.parent == manifests_root else None
        )
        self.roots = self._roots()

    def _roots(self) -> tuple[EvidenceRoot, ...]:
        rows: list[EvidenceRoot] = []
        seen: set[Path] = set()

        def add(label: str, raw: Any) -> None:
            root = _root(raw)
            if root is None or root in seen:
                return
            rows.append(EvidenceRoot(label, root))
            seen.add(root)

        add("state", str(self.state_dir))
        add("artifacts", str(self.state_dir / "artifacts"))
        for source in (self.manifest or {}, self.state):
            add("workdir", source.get("workdir"))
            add("repo", source.get("repo"))
        evidence_roots = self.state.get("evidence_roots")
        if isinstance(evidence_roots, list):
            for index, item in enumerate(evidence_roots):
                if isinstance(item, dict):
                    label = safe_component(str(item.get("label", "")), max_length=40)
                    add(label or f"run-root-{index + 1}", item.get("path"))
        return tuple(rows)

    def resolve(self, raw_path: str, *, require_file: bool = True) -> Path | None:
        if not isinstance(raw_path, str) or not raw_path:
            return None
        try:
            candidate = Path(raw_path).expanduser().resolve()
        except (OSError, RuntimeError, ValueError):
            return None
        if not any(_within(candidate, root.path) for root in self.roots):
            return None
        if require_file and not candidate.is_file():
            return None
        return candidate

    def sensitive_path(self, path: Path) -> bool:
        for root in self.roots:
            if _within(path, root.path):
                return sensitive_name(PurePosixPath(path.relative_to(root.path).as_posix()))
        return True

    def task(self, task_key: str) -> dict[str, Any] | None:
        for task in self.state.get("tasks", []) if isinstance(self.state.get("tasks"), list) else []:
            if isinstance(task, dict) and task.get("key") == task_key:
                return task
        return None

    def task_file(self, task_key: str, field: str, fallback: str = "") -> Path | None:
        task = self.task(task_key)
        if task is None:
            return None
        raw = task.get(field)
        if isinstance(raw, str) and raw:
            resolved = self.resolve(raw)
            if resolved is not None:
                return resolved
        taskdir = task.get("taskdir")
        if fallback and isinstance(taskdir, str) and taskdir:
            return self.resolve(str(Path(taskdir) / fallback))
        return None

    def deliverable_name(self, task_key: str, path: Path) -> str | None:
        candidates: list[tuple[Path, str]] = []
        task = self.task(task_key) or {}
        taskdir = _root(task.get("taskdir"))
        if taskdir is not None:
            candidates.append((taskdir, ""))
        artifact_task = self.state_dir / "artifacts" / "deliverables" / self.run_id / task_key
        if artifact_task.is_dir():
            candidates.append((artifact_task.resolve(), ""))
        for root in self.roots:
            candidates.append((root.path, f"{root.label}/"))
        for root, prefix in candidates:
            if not _within(path, root):
                continue
            relative = PurePosixPath(path.relative_to(root).as_posix())
            if sensitive_name(relative) or any(part in {"", ".", ".."} for part in relative.parts):
                return None
            return f"deliverables/{task_key}/{prefix}{relative.as_posix()}"
        return None

    def portable(self, value: Any, *, key: str = "") -> Any:
        if key and any(marker in key.casefold() for marker in SENSITIVE_MARKERS):
            return "[REDACTED]"
        if isinstance(value, dict):
            return {str(name): self.portable(item, key=str(name)) for name, item in value.items()}
        if isinstance(value, list):
            return [self.portable(item) for item in value]
        if isinstance(value, tuple):
            return [self.portable(item) for item in value]
        if isinstance(value, str):
            if ("/" in value or "\\" in value) and any(
                marker in value.casefold() for marker in SENSITIVE_MARKERS
            ):
                return "[REDACTED_PATH]"
            return self.portable_text(value)
        return value

    def portable_text(self, value: str) -> str:
        result = value
        for root in sorted(self.roots, key=lambda item: len(str(item.path)), reverse=True):
            result = result.replace(str(root.path), f"${root.label.upper()}")
        for prefix in HOST_PATH_PREFIXES:
            start = 0
            while True:
                index = result.find(prefix, start)
                if index < 0:
                    break
                end = index
                while end < len(result) and result[end] not in "\r\n\t '\"<>[]{}()":
                    end += 1
                result = result[:index] + "[HOST_PATH_REMOVED]" + result[end:]
                start = index + len("[HOST_PATH_REMOVED]")
        return result

    def redact_text(self, value: str) -> str:
        lines: list[str] = []
        for line in value.splitlines(keepends=True):
            folded = line.casefold()
            if any(marker in folded for marker in SENSITIVE_MARKERS) and any(
                separator in line for separator in ("=", ":")
            ):
                ending = "\n" if line.endswith(("\n", "\r")) else ""
                lines.append("[REDACTED]" + ending)
            else:
                lines.append(self.portable_text(line))
        return "".join(lines)


def evidence_root_records(paths: Iterable[tuple[str, Path]]) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    for label, path in paths:
        try:
            resolved = path.expanduser().resolve()
        except (OSError, RuntimeError, ValueError):
            continue
        if resolved != resolved.parent:
            records.append({"label": label, "path": str(resolved)})
    return records
