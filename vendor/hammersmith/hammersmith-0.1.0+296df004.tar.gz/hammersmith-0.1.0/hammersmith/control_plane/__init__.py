"""Reusable application services for Hammersmith's local control plane.

Imports are lazy because the shared launcher depends on the runner, whose dashboard
adapter imports the HTTP package during normal CLI startup.
"""

from importlib import import_module
from typing import Any

__all__ = [
    "BootstrapService",
    "DraftConflict",
    "DraftNotFound",
    "DraftStore",
    "ExportService",
    "PlanConflict",
    "RunConflict",
    "RunQueryService",
    "RunService",
    "ValidatedPlanStore",
    "ValidationService",
]

_MODULES = {
    "BootstrapService": ".bootstrap",
    "DraftConflict": ".drafts",
    "DraftNotFound": ".drafts",
    "DraftStore": ".drafts",
    "ExportService": ".exports",
    "PlanConflict": ".validation",
    "RunConflict": ".runs",
    "RunQueryService": ".query",
    "RunService": ".runs",
    "ValidatedPlanStore": ".validation",
    "ValidationService": ".validation",
}


def __getattr__(name: str) -> Any:
    module_name = _MODULES.get(name)
    if module_name is None:
        raise AttributeError(name)
    return getattr(import_module(module_name, __name__), name)
