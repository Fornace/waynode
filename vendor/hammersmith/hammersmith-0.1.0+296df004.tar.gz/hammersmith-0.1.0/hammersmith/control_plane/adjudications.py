"""Append-only adjudication application service."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from hammersmith.model_log import ADJUDICATION_OUTCOMES
from hammersmith.state_io import interprocess_lock

from .canonical import canonical_digest


TERMINAL_TASK_STATES = {"pass", "fail", "failed", "error", "timeout", "died", "host_cancelled"}


class AdjudicationConflict(RuntimeError):
    pass


class AdjudicationStore:
    def __init__(self, state_dir: Path, *, eval_path: Path | None = None) -> None:
        self.state_dir = state_dir
        self.path = state_dir / "adjudications.jsonl"
        self.eval_path = eval_path
        self.lock_path = state_dir / ".adjudications.lock"

    @staticmethod
    def _action_id(actor: str, idempotency_key: str) -> str:
        return hashlib.sha256(f"{actor}\0{idempotency_key}".encode("utf-8")).hexdigest()

    def _rows(self) -> list[dict[str, Any]]:
        try:
            lines = self.path.read_text(encoding="utf-8").splitlines()
        except (FileNotFoundError, OSError, UnicodeDecodeError):
            return []
        rows: list[dict[str, Any]] = []
        for line in lines:
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                rows.append(value)
        return rows

    def _task_finished(self, run_id: str, task_key: str) -> bool:
        allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
        if not run_id or len(run_id) > 200 or any(character not in allowed for character in run_id):
            return False
        runs_root = (self.state_dir / "runs").resolve()
        path = (runs_root / f"{run_id}.json").resolve()
        if path.parent != runs_root:
            return False
        try:
            state = json.loads(path.read_text(encoding="utf-8"))
        except (FileNotFoundError, OSError, json.JSONDecodeError, UnicodeDecodeError):
            return False
        for task in state.get("tasks", []) if isinstance(state, dict) else []:
            if isinstance(task, dict) and task.get("key") == task_key:
                return str(task.get("status", "")).casefold() in TERMINAL_TASK_STATES
        return False

    def append(
        self,
        *,
        run_id: str,
        task_key: str,
        outcome: str,
        reason: str,
        actor: str,
        idempotency_key: str,
        require_finished: bool = True,
    ) -> dict[str, Any]:
        if not isinstance(outcome, str) or outcome not in ADJUDICATION_OUTCOMES:
            raise ValueError("unsupported adjudication outcome")
        if not isinstance(reason, str) or not reason.strip():
            raise ValueError("reason is required")
        if (
            not isinstance(idempotency_key, str)
            or not idempotency_key.strip()
            or len(idempotency_key) > 200
        ):
            raise ValueError("Idempotency-Key is required")
        if require_finished and not self._task_finished(run_id, task_key):
            raise AdjudicationConflict("task is not finished")
        action_id = self._action_id(actor, idempotency_key)
        request_digest = canonical_digest(
            {"run_id": run_id, "task_key": task_key, "outcome": outcome, "reason": reason}
        )
        with interprocess_lock(self.lock_path):
            rows = self._rows()
            for row in rows:
                if row.get("action_id") != action_id:
                    continue
                if row.get("request_digest") != request_digest:
                    raise AdjudicationConflict("idempotency key was used for another action")
                return row
            event = {
                "record_type": "adjudication",
                "action_id": action_id,
                "request_digest": request_digest,
                "run_id": run_id,
                "task_key": task_key,
                "outcome": outcome,
                "reason": reason.strip(),
                "adjudicator": actor,
                "logged_at": datetime.now(timezone.utc).isoformat(),
            }
            line = json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n"
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(line)
                handle.flush()
            if self.eval_path is not None:
                self.eval_path.parent.mkdir(parents=True, exist_ok=True)
                with self.eval_path.open("a", encoding="utf-8") as handle:
                    handle.write(line)
                    handle.flush()
            return event

    def latest(self, run_id: str | None = None) -> dict[tuple[str, str], dict[str, Any]]:
        result: dict[tuple[str, str], dict[str, Any]] = {}
        with interprocess_lock(self.lock_path):
            rows = self._rows()
        for row in rows:
            if run_id is not None and row.get("run_id") != run_id:
                continue
            key = (str(row.get("run_id", "")), str(row.get("task_key", "")))
            result[key] = {
                field: row.get(field)
                for field in ("outcome", "reason", "adjudicator", "logged_at", "action_id")
            }
        return result


def latest_adjudications(state_dir: Path, run_id: str) -> dict[str, dict[str, Any]]:
    return {
        task_key: value
        for (_run_id, task_key), value in AdjudicationStore(state_dir).latest(run_id).items()
    }
