"""Canonical manifest serialization and browser-facing schema metadata."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from hammersmith.manifest_models import Manifest


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def canonical_digest(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def manifest_to_obj(manifest: Manifest) -> dict[str, Any]:
    tasks: list[dict[str, Any]] = []
    for task in manifest.tasks:
        tasks.append(
            {
                "key": task.key,
                "spec": task.spec,
                "check": task.check,
                "engine": task.engine,
                "expect_files": list(task.expect_files),
                "timeout_s": task.timeout_s,
                "full_access": task.full_access,
                "engine_args": list(task.engine_args),
                "verified": task.verified,
                "model": task.model,
                "task_type": task.task_type,
                "owned_paths": list(task.owned_paths),
                "forbidden_paths": list(task.forbidden_paths),
                "required_inputs": list(task.required_inputs),
                "expected_outputs": list(task.expected_outputs),
                "input_patches": [
                    {"path": item.path, "sha256": item.sha256, "apply": item.apply}
                    for item in task.input_patches
                ],
                "max_attempts": task.max_attempts,
                "layout_policy": task.layout_policy,
            }
        )
    return {
        "run_name": manifest.run_name,
        "workdir": str(manifest.workdir),
        "max_parallel": manifest.max_parallel,
        "worktrees": manifest.worktrees,
        "repo": str(manifest.repo) if manifest.repo is not None else None,
        "tasks": tasks,
        "project": manifest.project,
        "root_run_id": manifest.root_run_id,
        "parent_run_id": manifest.parent_run_id,
        "replay_of": manifest.replay_of,
        "duplicate_of": manifest.duplicate_of,
        "shared_check": manifest.shared_check,
        "shared_check_timeout_s": manifest.shared_check_timeout_s,
    }


def _array(item_type: str = "string") -> dict[str, Any]:
    return {"type": "array", "items": {"type": item_type}, "default": []}


def manifest_schema() -> dict[str, Any]:
    task_properties: dict[str, Any] = {
        "key": {"type": "string", "minLength": 1},
        "spec": {"type": "string", "minLength": 1},
        "check": {"type": "string", "minLength": 1},
        "engine": {"type": "string", "minLength": 1, "default": "pi"},
        "expect_files": _array(),
        "timeout_s": {"type": "integer", "minimum": 1, "default": 900},
        "full_access": {"type": "boolean", "default": False},
        "engine_args": _array(),
        "verified": {"type": "string", "default": ""},
        "model": {"type": "string", "default": ""},
        "task_type": {"type": "string", "default": ""},
        "owned_paths": _array(),
        "forbidden_paths": _array(),
        "required_inputs": _array(),
        "expected_outputs": _array(),
        "input_patches": {
            "type": "array",
            "default": [],
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["path"],
                "properties": {
                    "path": {"type": "string", "minLength": 1},
                    "sha256": {"type": "string", "default": ""},
                    "apply": {"type": "boolean", "default": True},
                },
            },
        },
        "max_attempts": {"type": "integer", "minimum": 1, "default": 2},
        "layout_policy": {
            "type": "string", "enum": ["flexible", "exact"], "default": "flexible"
        },
    }
    properties: dict[str, Any] = {
        "run_name": {"type": "string", "minLength": 1},
        "workdir": {"type": "string", "minLength": 1},
        "max_parallel": {"type": "integer", "minimum": 1, "default": 1},
        "worktrees": {"type": "boolean", "default": False},
        "repo": {"type": ["string", "null"], "default": None},
        "tasks": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["key", "spec", "check"],
                "properties": task_properties,
            },
        },
        "project": {"type": "string", "default": ""},
        "root_run_id": {"type": "string", "default": ""},
        "parent_run_id": {"type": "string", "default": ""},
        "replay_of": {"type": "string", "default": ""},
        "duplicate_of": {"type": "string", "default": ""},
        "shared_check": {"type": "string", "default": ""},
        "shared_check_timeout_s": {"type": "integer", "minimum": 1, "default": 120},
    }
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "https://fornace.local/schemas/hammersmith-manifest-v1.json",
        "title": "Hammersmith manifest",
        "type": "object",
        "additionalProperties": False,
        "required": ["run_name", "workdir", "tasks"],
        "properties": properties,
    }


def manifest_ui_metadata() -> dict[str, Any]:
    advanced = [
        "root_run_id", "parent_run_id", "replay_of", "duplicate_of",
        "shared_check", "shared_check_timeout_s",
    ]
    return {
        "version": 1,
        "modes": ["guided", "patterns", "json"],
        "field_order": [
            "run_name", "project", "workdir", "max_parallel", "worktrees", "repo",
            "tasks", *advanced,
        ],
        "advanced_fields": advanced,
        "risk_fields": {
            "/tasks/*/check": "executes-shell-after-explicit-launch",
            "/tasks/*/full_access": "privileged-worker-access",
            "/tasks/*/engine_args": "worker-cli-arguments",
            "/shared_check": "executes-shell-after-explicit-launch",
        },
        "conditions": {
            "/repo": {"visible_when": {"/worktrees": True}},
            "/tasks/*/expected_outputs": {"requires": "/tasks/*/owned_paths"},
        },
        "docs": {"manifest": "docs/MANIFEST-REFERENCE.md"},
    }
