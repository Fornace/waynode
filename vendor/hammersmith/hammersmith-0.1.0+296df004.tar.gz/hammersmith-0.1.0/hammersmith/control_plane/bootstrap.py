"""Sanitized bootstrap payload for browser control-plane clients."""

from __future__ import annotations

import os
import json
import shutil
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any

from hammersmith.config import AppConfig
from hammersmith.constants import _REPO_ROOT
from hammersmith.identity import product_identity

from .canonical import manifest_schema, manifest_ui_metadata


_TEMPLATES = (
    ("review-swarm", "Read-only review coverage", "Broad review before deciding what to fix", "proven"),
    ("fix-swarm", "Independent isolated fixes", "Confirmed fixes split by owned surface", "proven"),
    ("focus-group", "Isolated persona feedback", "Product or messaging feedback without persona bleed", "proven"),
    ("bakeoff", "Model and prompt comparison", "Evidence for choosing a model or configuration", "proven"),
    ("research-with-proof", "Research plus executable proof", "Claims must be verifiable", "proven"),
    ("launch-kit", "Multi-round launch package", "Rough direction through final assembly", "proven"),
    ("asset-swarm", "Verified media production", "Many visual or media assets", "proven"),
    ("adversarial-review", "Multi-model artifact review", "Model diversity before synthesis", "proven"),
    ("repo-feature", "Sandboxed repository delivery", "A known feature needs implementation", "proven"),
    ("migration-swarm", "Partitioned mechanical migration", "Repetitive edits can be split safely", "blueprint"),
    ("doc-swarm", "Documentation with executed examples", "Module documentation must prove APIs", "blueprint"),
    ("test-hardening", "Production-code-free test strengthening", "Tests need stronger coverage", "blueprint"),
    ("competitive-teardown", "Grounded competitor analysis", "Traceable source material is required", "blueprint"),
    ("data-pipeline", "Verified staged data workflow", "Each fetch/transform/validate stage needs proof", "blueprint"),
    ("probe", "One-task smoke or diagnosis", "A harness or claim needs a visible check", "proven"),
    ("structured-repair", "Exact-layout bounded repair", "Ownership and output filenames are API", "proven"),
)


def _template_placeholders(value: Any) -> list[str]:
    names: list[str] = []

    def visit(item: Any) -> None:
        if isinstance(item, dict):
            for key, child in item.items():
                visit(key)
                visit(child)
            return
        if isinstance(item, list):
            for child in item:
                visit(child)
            return
        if not isinstance(item, str):
            return
        cursor = 0
        while True:
            start = item.find("{{", cursor)
            if start < 0:
                return
            end = item.find("}}", start + 2)
            if end < 0:
                return
            name = item[start + 2:end].strip()
            if name and name not in names:
                names.append(name)
            cursor = end + 2

    visit(value)
    return names


def _template_descriptors() -> list[dict[str, Any]]:
    descriptors: list[dict[str, Any]] = []
    for template_id, title, when_to_use, status in _TEMPLATES:
        path = _REPO_ROOT / "templates" / template_id / "manifest.json"
        manifest = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(manifest, dict):
            raise ValueError(f"template {template_id} manifest must be an object")
        descriptors.append(
            {
                "id": template_id,
                "title": title,
                "when_to_use": when_to_use,
                "status": status,
                "required_inputs": _template_placeholders(manifest),
                "manifest_template": manifest,
            }
        )
    return descriptors


def _package_version() -> str:
    try:
        return version("hammersmith")
    except PackageNotFoundError:
        return "0.1.0"


class BootstrapService:
    def __init__(self, config: AppConfig) -> None:
        self.config = config

    def _engines(self, model_evidence: dict[str, Any] | None) -> list[dict[str, Any]]:
        rollup = model_evidence.get("rollup", []) if isinstance(model_evidence, dict) else []
        safe_rollup = []
        for row in rollup if isinstance(rollup, list) else []:
            if not isinstance(row, dict):
                continue
            safe_rollup.append(
                {
                    key: row.get(key)
                    for key in (
                        "model", "trained_model", "task_type", "tasks", "pass_rate",
                        "first_try_pass_rate", "adjusted_pass_rate",
                    )
                    if key in row
                }
            )
        engines: list[dict[str, Any]] = []
        for name, engine in sorted(self.config.engines.items()):
            executable = Path(engine.bin).expanduser()
            available = (
                executable.is_file() and os.access(executable, os.X_OK)
                if os.sep in engine.bin
                else shutil.which(engine.bin) is not None
            )
            engines.append(
                {
                    "name": name,
                    "available": available,
                    "inherited_model_default": engine.model_default or None,
                    "accepts_task_model": any(
                        marker in item
                        for item in engine.args_template
                        for marker in ("{model}", "{model_args}")
                    ),
                    "local_evidence": [
                        row for row in safe_rollup
                        if not engine.model_default or row.get("model") == engine.model_default
                    ],
                }
            )
        return engines

    def build(
        self,
        *,
        actor: str,
        role: str,
        csrf_token: str | None,
        model_evidence: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        can_mutate = role in {"user", "admin"} and csrf_token is not None
        actions = {
            "read": True,
            "manage_own_drafts": can_mutate,
            "validate_manifests": can_mutate,
            "launch_own_runs": can_mutate,
            "cancel_own_runs": can_mutate,
            "adjudicate_own_runs": can_mutate,
            "export_runs": role in {"viewer", "user", "admin"},
            "ai_author_manifests": can_mutate,
            "manage_all": role == "admin" and can_mutate,
            "configure": role == "admin" and can_mutate,
        }
        engines = self._engines(model_evidence)
        models: list[dict[str, Any]] = []
        seen_models: set[str] = set()
        for engine in engines:
            inherited = engine.get("inherited_model_default")
            if isinstance(inherited, str) and inherited and inherited not in seen_models:
                models.append({"id": inherited, "source": "inherited-default", "engine": engine["name"]})
                seen_models.add(inherited)
            for row in engine.get("local_evidence", []):
                model = row.get("model") if isinstance(row, dict) else None
                if isinstance(model, str) and model and model not in seen_models:
                    models.append({"id": model, "source": "local-evidence", "evidence": row})
                    seen_models.add(model)
        return {
            "product": {**product_identity(), "version": _package_version()},
            "actor": {"username": actor, "role": role},
            "csrf_token": csrf_token,
            "manifest": {"schema": manifest_schema(), "ui": manifest_ui_metadata()},
            "templates": _template_descriptors(),
            "engines": engines,
            "models": models,
            "defaults": {"engine": "pi", "max_parallel": 1, "layout_policy": "flexible"},
            "capabilities": {"features": ["guided", "patterns", "json"], "actions": actions},
        }
