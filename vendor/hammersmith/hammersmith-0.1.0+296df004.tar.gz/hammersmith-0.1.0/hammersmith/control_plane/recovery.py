"""Inert, idempotent replay and repair draft construction."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from hammersmith.manifest_models import Manifest
from hammersmith.state_io import atomic_write_text, interprocess_lock

from .canonical import canonical_digest, canonical_json_bytes, manifest_to_obj
from .drafts import DraftStore
from .errors import RunConflict
from .evidence import RunEvidence


FAILED_TASK_STATES = {"fail", "failed", "error", "timeout", "died", "host_cancelled"}
TERMINAL_RUN_STATES = {"finished", "pass", "fail", "failed", "error", "died", "host_cancelled"}


class RecoveryService:
    def __init__(self, runs: "RunService", drafts: DraftStore) -> None:
        self.runs = runs
        self.drafts = drafts

    @staticmethod
    def _terminal(state: dict[str, Any]) -> bool:
        return bool(state.get("finished")) or str(state.get("state", "")).casefold() in TERMINAL_RUN_STATES

    @staticmethod
    def _failed_tasks(state: dict[str, Any]) -> dict[str, dict[str, Any]]:
        result: dict[str, dict[str, Any]] = {}
        tasks = state.get("tasks", []) if isinstance(state.get("tasks"), list) else []
        for task in tasks:
            if not isinstance(task, dict):
                continue
            status = str(task.get("status", "")).casefold()
            if status in FAILED_TASK_STATES or task.get("failure_class"):
                result[str(task.get("key", ""))] = task
        return result

    @staticmethod
    def _source_tasks(state: dict[str, Any]) -> dict[str, dict[str, Any]]:
        tasks = state.get("tasks", []) if isinstance(state.get("tasks"), list) else []
        return {
            str(task.get("key", "")): task
            for task in tasks
            if isinstance(task, dict) and task.get("key")
        }

    @staticmethod
    def _context(
        *,
        source_run_id: str,
        root_run_id: str,
        task: dict[str, Any],
        source_task: dict[str, Any],
        failure: dict[str, Any] | None,
        evidence: RunEvidence,
    ) -> str:
        lines = [
            "RECOVERY LINEAGE (inert draft; review and validate before launch)",
            f"Source run: {source_run_id}",
            f"Root run: {root_run_id}",
            f"Source task: {task.get('key', '')}",
            f"Source attempts: {source_task.get('attempts', 0)}",
        ]
        if failure is not None:
            proof = {
                key: failure.get(key)
                for key in (
                    "status", "verdict", "attempts", "failure_class", "failure_owner",
                    "failure_reason", "check_returncode", "check_timed_out",
                    "check_output_tail", "missing_files", "unexpected_paths",
                    "observed_paths", "input_patch_status", "contract_preflight",
                    "adjudication",
                )
                if failure.get(key) not in (None, "", [], {})
            }
            portable = evidence.portable(proof)
            encoded = canonical_json_bytes(portable).decode("utf-8")
            lines.extend(("Failure evidence (persisted source record):", encoded[:12000]))
        lines.append("Original proof command remains in this task's check field.")
        return "\n".join(lines)

    def create(
        self,
        run_id: str,
        *,
        kind: str,
        confirmation: bool,
        idempotency_key: str,
        actor: str,
        admin: bool = False,
    ) -> dict[str, Any]:
        if kind not in {"replay", "repair"}:
            raise ValueError("kind must be replay or repair")
        if confirmation is not True:
            raise RunConflict("explicit recovery confirmation is required")
        key = self.runs._validate_idempotency_key(idempotency_key)
        request = {"run_id": run_id, "kind": kind, "confirmation": True}
        request_digest = canonical_digest(request)
        action_id = self.runs._action_id(actor, "replay-draft", key)
        with interprocess_lock(self.runs.lock_path):
            existing = self.runs._existing(action_id, request_digest)
            if existing is not None:
                response = existing.get("response")
                if isinstance(response, dict):
                    return response
                raise RunConflict("recovery receipt is unavailable")
            owner = self.runs.owner_for_run(run_id)
            if owner is None or (not admin and owner != actor):
                raise RunConflict("recovery is unavailable for this actor")
            try:
                evidence = RunEvidence(self.runs.config.state_dir, run_id)
            except FileNotFoundError as exc:
                raise RunConflict("recovery source record is unavailable") from exc
            if evidence.manifest is None or not self._terminal(evidence.state):
                raise RunConflict("recovery source record is unavailable")
            failures = self._failed_tasks(evidence.state)
            source_tasks = self._source_tasks(evidence.state)
            if kind == "repair" and not failures:
                raise RunConflict("repair is unavailable without persisted failure evidence")
            source = Manifest.from_obj(evidence.manifest)
            manifest = manifest_to_obj(source)
            root_run_id = (
                str(evidence.state.get("root_run_id", "")).strip()
                or str(manifest.get("root_run_id", "")).strip()
                or run_id
            )
            manifest["run_name"] = f"{source.run_name}-{kind}"
            manifest["root_run_id"] = root_run_id
            manifest["parent_run_id"] = run_id
            manifest["replay_of"] = run_id
            manifest["duplicate_of"] = ""
            for task in manifest["tasks"]:
                task_key = str(task.get("key", ""))
                failure = failures.get(task_key) if kind == "repair" else None
                context = self._context(
                    source_run_id=run_id,
                    root_run_id=root_run_id,
                    task=task,
                    source_task=source_tasks.get(task_key, {}),
                    failure=failure,
                    evidence=evidence,
                )
                task["spec"] = f"{context}\n\n{task['spec']}"
            normalized = manifest_to_obj(Manifest.from_obj(manifest))
            draft = self.drafts.create(normalized, owner=actor)
            receipt = {
                "action": "replay-draft",
                "action_id": action_id,
                "request_digest": request_digest,
                "run_id": run_id,
                "owner": owner,
                "requested_by": actor,
                "kind": kind,
                "status": "created",
                "response": draft,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            atomic_write_text(
                self.runs._action_path(action_id),
                canonical_json_bytes(receipt).decode("utf-8") + "\n",
            )
            self.runs.journal.append(
                {
                    "action": "replay-draft",
                    "run_id": run_id,
                    "draft_id": draft["id"],
                    "kind": kind,
                    "status": "draft_created",
                    "requested_by": actor,
                }
            )
            return draft
