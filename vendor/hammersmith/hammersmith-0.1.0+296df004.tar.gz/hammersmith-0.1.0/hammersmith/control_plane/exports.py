"""Deterministic, bounded, portable run-evidence ZIP exports."""

from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path
from typing import Any

from .adjudications import AdjudicationStore
from .canonical import canonical_json_bytes
from .evidence import RunEvidence


MAX_EXPORT_FILE_BYTES = 2 * 1024 * 1024
MAX_EXPORT_TOTAL_BYTES = 16 * 1024 * 1024


class ExportService:
    def __init__(
        self,
        state_dir: Path,
        *,
        max_file_bytes: int = MAX_EXPORT_FILE_BYTES,
        max_total_bytes: int = MAX_EXPORT_TOTAL_BYTES,
    ) -> None:
        if max_file_bytes < 1 or max_total_bytes < max_file_bytes:
            raise ValueError("invalid export byte limits")
        self.state_dir = state_dir.resolve()
        self.adjudications = AdjudicationStore(state_dir)
        self.max_file_bytes = max_file_bytes
        self.max_total_bytes = max_total_bytes

    @staticmethod
    def _write(archive: zipfile.ZipFile, name: str, body: bytes) -> None:
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = 0o100600 << 16
        archive.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

    def _json(self, evidence: RunEvidence, value: Any) -> bytes:
        return canonical_json_bytes(evidence.portable(value)) + b"\n"

    def _read_file(self, evidence: RunEvidence, path: Path) -> bytes | None:
        if evidence.sensitive_path(path):
            return None
        try:
            with path.open("rb") as handle:
                body = handle.read(self.max_file_bytes + 1)
        except OSError:
            return None
        if len(body) > self.max_file_bytes:
            return body
        if path.suffix.casefold() == ".json":
            try:
                value = json.loads(body.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                value = None
            if value is not None:
                return self._json(evidence, value)
        try:
            return evidence.redact_text(body.decode("utf-8")).encode("utf-8")
        except UnicodeDecodeError:
            return body

    def _add(
        self,
        files: dict[str, bytes],
        omitted: list[dict[str, str]],
        name: str,
        body: bytes | None,
    ) -> None:
        if body is None:
            omitted.append({"path": name, "reason": "sensitive_unavailable_or_oversized"})
            return
        if len(body) > self.max_file_bytes:
            omitted.append({"path": name, "reason": "per_file_byte_limit"})
            return
        if name in files:
            omitted.append({"path": name, "reason": "archive_name_collision"})
            return
        used = sum(len(item) for item in files.values())
        if used + len(body) > self.max_total_bytes:
            omitted.append({"path": name, "reason": "total_byte_limit"})
            return
        files[name] = body

    def build(self, run_id: str) -> tuple[str, bytes]:
        evidence = RunEvidence(self.state_dir, run_id)
        state = evidence.state
        files: dict[str, bytes] = {}
        omitted: list[dict[str, str]] = []
        self._add(files, omitted, "state.json", self._json(evidence, state))
        if evidence.manifest is not None:
            self._add(
                files,
                omitted,
                "manifest.json",
                self._json(evidence, evidence.manifest),
            )
        tasks = state.get("tasks", []) if isinstance(state.get("tasks"), list) else []
        for task in tasks:
            if not isinstance(task, dict):
                continue
            key = str(task.get("key", ""))
            if not key or any(char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for char in key):
                continue
            check = {
                field: task.get(field)
                for field in (
                    "key", "status", "verdict", "check", "check_returncode",
                    "check_timed_out", "check_output_tail", "failure_class",
                    "failure_owner", "model_eligible", "attempts", "expected_outputs",
                    "observed_paths", "missing_files", "unexpected_paths",
                    "input_patch_status", "contract_preflight", "shared_check_status",
                )
            }
            self._add(files, omitted, f"checks/{key}.json", self._json(evidence, check))
            log = evidence.task_file(key, "log_path", "worker.log")
            if log is not None:
                self._add(files, omitted, f"logs/{key}.log", self._read_file(evidence, log))
            deliverables = task.get("deliverables", [])
            for item in deliverables if isinstance(deliverables, list) else []:
                if not isinstance(item, dict) or not isinstance(item.get("path"), str):
                    continue
                path = evidence.resolve(item["path"])
                if path is None:
                    omitted.append({"path": f"deliverables/{key}", "reason": "path_outside_trusted_roots"})
                    continue
                name = evidence.deliverable_name(key, path)
                if name is None:
                    omitted.append({"path": f"deliverables/{key}", "reason": "unsafe_or_sensitive_name"})
                    continue
                self._add(files, omitted, name, self._read_file(evidence, path))
        adjudications = [
            {"run_id": key[0], "task_key": key[1], **value}
            for key, value in sorted(self.adjudications.latest(run_id).items())
        ]
        self._add(
            files,
            omitted,
            "adjudications.json",
            self._json(evidence, adjudications),
        )
        if omitted:
            omissions = self._json(
                evidence,
                sorted(omitted, key=lambda item: (item["path"], item["reason"])),
            )
            if sum(len(item) for item in files.values()) + len(omissions) <= self.max_total_bytes:
                files["omissions.json"] = omissions
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            for name in sorted(files):
                self._write(archive, name, files[name])
        body = buffer.getvalue()
        if len(body) > self.max_total_bytes:
            raise ValueError("evidence archive exceeds total byte limit")
        return f"hammersmith-{run_id}-evidence.zip", body
