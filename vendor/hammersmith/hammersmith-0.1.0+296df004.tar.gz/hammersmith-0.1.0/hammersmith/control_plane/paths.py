"""Resolved-path capabilities shared by HTTP and control-plane services."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable


class PathCapability:
    def __init__(self, roots: Iterable[Path]) -> None:
        self.roots = tuple(root.expanduser().resolve() for root in roots)

    @staticmethod
    def _within(path: Path, root: Path) -> bool:
        return path != root and root in path.parents

    def resolve_relative(
        self, root: Path, relative: str, *, require_file: bool = False
    ) -> Path | None:
        resolved_root = root.expanduser().resolve()
        if resolved_root not in self.roots:
            return None
        candidate = (resolved_root / relative).resolve()
        if not self._within(candidate, resolved_root):
            return None
        if require_file and not candidate.is_file():
            return None
        return candidate

    def resolve_recorded(self, raw_path: str, *, require_file: bool = False) -> Path | None:
        try:
            candidate = Path(raw_path).expanduser().resolve()
        except (OSError, RuntimeError, ValueError):
            return None
        if not any(self._within(candidate, root) for root in self.roots):
            return None
        if require_file and not candidate.is_file():
            return None
        return candidate

    def contains(self, path: Path) -> bool:
        try:
            candidate = path.expanduser().resolve()
        except (OSError, RuntimeError, ValueError):
            return False
        return any(self._within(candidate, root) for root in self.roots)
