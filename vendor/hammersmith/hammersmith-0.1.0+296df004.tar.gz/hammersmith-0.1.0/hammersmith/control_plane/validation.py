"""Side-effect-free manifest validation and expiring digest-bound plans."""

from __future__ import annotations

import os
import secrets
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from hammersmith.cli.planning import validate_manifest_engines
from hammersmith.config import AppConfig
from hammersmith.manifest_lint import lint_manifest_detailed
from hammersmith.manifest_models import MANIFEST_FIELDS, TASK_SPEC_FIELDS, Manifest
from hammersmith.prompt import compile_worker_prompt
from hammersmith.utils.models import build_worker_command

from .canonical import canonical_digest, manifest_to_obj


class PlanConflict(RuntimeError):
    pass


@dataclass(frozen=True)
class ValidatedPlan:
    plan_id: str
    manifest: Manifest
    canonical: dict[str, Any]
    digest: str
    actor: str
    created_at: float
    expires_at: float
    config_fingerprint: str
    root_fingerprint: str
    task_plan: tuple[dict[str, Any], ...]


def _pointer_token(value: str) -> str:
    return value.replace("~", "~0").replace("/", "~1")


def _parse_finding(obj: Any, message: str) -> dict[str, str]:
    pointer = ""
    code = "manifest.invalid"
    if isinstance(obj, dict):
        unknown = sorted(set(obj) - MANIFEST_FIELDS)
        if unknown:
            pointer = "/" + _pointer_token(unknown[0])
            code = "manifest.unknown_field"
        tasks = obj.get("tasks")
        if not pointer and isinstance(tasks, list):
            for index, task in enumerate(tasks):
                if not isinstance(task, dict):
                    pointer = f"/tasks/{index}"
                    break
                task_unknown = sorted(set(task) - TASK_SPEC_FIELDS)
                if task_unknown:
                    pointer = f"/tasks/{index}/{_pointer_token(task_unknown[0])}"
                    code = "task.unknown_field"
                    break
                patches = task.get("input_patches")
                if isinstance(patches, list):
                    for patch_index, patch in enumerate(patches):
                        if isinstance(patch, dict):
                            extra = sorted(set(patch) - {"path", "sha256", "apply"})
                            if extra:
                                pointer = f"/tasks/{index}/input_patches/{patch_index}/{_pointer_token(extra[0])}"
                                code = "input_patch.unknown_field"
                                break
                if pointer:
                    break
    if not pointer:
        field_names = sorted(MANIFEST_FIELDS | TASK_SPEC_FIELDS, key=len, reverse=True)
        for field_name in field_names:
            if field_name in message:
                if isinstance(obj, dict) and isinstance(obj.get("tasks"), list):
                    for index, task in enumerate(obj["tasks"]):
                        if isinstance(task, dict) and str(task.get("key", "")) in message:
                            pointer = f"/tasks/{index}/{field_name}"
                            break
                pointer = pointer or f"/{field_name}"
                break
    return {
        "code": code,
        "severity": "error",
        "json_pointer": pointer,
        "message": message,
        "action": "Correct this field and validate again.",
    }


def _lint_pointer(manifest: Manifest, message: str) -> str:
    for index, task in enumerate(manifest.tasks):
        if message.startswith(f"{task.key}:"):
            for field in (
                "owned_paths", "forbidden_paths", "expected_outputs", "input_patches",
                "check", "spec", "expect_files", "verified", "task_type",
            ):
                if field.replace("_", " ") in message or field in message:
                    return f"/tasks/{index}/{field}"
            return f"/tasks/{index}"
    if message.startswith("manifest:"):
        return "/shared_check" if "shared_check" in message else ""
    return ""


def config_fingerprint(config: AppConfig) -> str:
    data = {
        "allow_full_access": config.allow_full_access,
        "engines": {
            name: {
                "bin": engine.bin,
                "args": list(engine.args_template),
                "sandbox": list(engine.sandbox_args),
                "full": list(engine.full_access_args),
                "model_default": engine.model_default,
            }
            for name, engine in sorted(config.engines.items())
        },
    }
    return canonical_digest(data)


def root_fingerprint(manifest: Manifest) -> str:
    root = manifest.repo if manifest.worktrees and manifest.repo is not None else manifest.workdir
    resolved = root.resolve()
    probe = resolved
    while not probe.exists() and probe != probe.parent:
        probe = probe.parent
    try:
        stat = probe.stat()
        evidence = [str(resolved), str(probe), stat.st_dev, stat.st_ino]
    except OSError:
        evidence = [str(resolved), "unavailable"]
    return canonical_digest(evidence)


class ValidatedPlanStore:
    def __init__(self, *, ttl_s: int = 300, clock: Callable[[], float] = time.time) -> None:
        self.ttl_s = ttl_s
        self.clock = clock
        self._plans: dict[str, ValidatedPlan] = {}
        self._lock = threading.RLock()

    def put(
        self,
        manifest: Manifest,
        canonical: dict[str, Any],
        actor: str,
        config: AppConfig,
        task_plan: list[dict[str, Any]],
    ) -> ValidatedPlan:
        now = self.clock()
        plan = ValidatedPlan(
            plan_id=secrets.token_urlsafe(24),
            manifest=manifest,
            canonical=canonical,
            digest=canonical_digest(canonical),
            actor=actor,
            created_at=now,
            expires_at=now + self.ttl_s,
            config_fingerprint=config_fingerprint(config),
            root_fingerprint=root_fingerprint(manifest),
            task_plan=tuple(task_plan),
        )
        with self._lock:
            self._plans[plan.plan_id] = plan
        return plan

    def resolve(
        self, plan_id: str, *, digest: str, actor: str, config: AppConfig, admin: bool = False
    ) -> ValidatedPlan:
        with self._lock:
            plan = self._plans.get(plan_id)
        if plan is None:
            raise PlanConflict("validated plan is unavailable")
        if self.clock() >= plan.expires_at:
            raise PlanConflict("validated plan has expired")
        if not admin and plan.actor != actor:
            raise PlanConflict("validated plan is unavailable")
        if not secrets.compare_digest(plan.digest, digest):
            raise PlanConflict("manifest digest does not match the validated plan")
        if plan.config_fingerprint != config_fingerprint(config):
            raise PlanConflict("configuration changed after validation")
        if plan.root_fingerprint != root_fingerprint(plan.manifest):
            raise PlanConflict("project root changed after validation")
        return plan


class ValidationService:
    def __init__(self, config: AppConfig, plans: ValidatedPlanStore | None = None) -> None:
        self.config = config
        self.plans = plans or ValidatedPlanStore()

    def _engine_evidence(self, manifest: Manifest) -> list[dict[str, Any]]:
        evidence: list[dict[str, Any]] = []
        for name in sorted({task.engine for task in manifest.tasks}):
            engine = self.config.engines.get(name)
            if engine is None:
                evidence.append({"engine": name, "configured": False, "binary_available": False})
                continue
            binary = Path(engine.bin).expanduser()
            available = (
                binary.is_file() and os.access(binary, os.X_OK)
                if os.sep in engine.bin
                else shutil.which(engine.bin) is not None
            )
            evidence.append(
                {
                    "engine": name,
                    "configured": True,
                    "binary_available": available,
                    "inherited_model": engine.model_default or None,
                }
            )
        return evidence

    @staticmethod
    def _required_input_evidence(manifest: Manifest) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for task in manifest.tasks:
            base = manifest.repo if manifest.worktrees and manifest.repo is not None else manifest.workdir / task.key
            for value in task.required_inputs:
                path = Path(value).expanduser()
                resolved = path if path.is_absolute() else base / path
                rows.append({"task": task.key, "input": value, "exists": resolved.exists()})
        return rows

    def validate(self, manifest_obj: Any, *, actor: str) -> dict[str, Any]:
        def invalid_payload(finding: dict[str, str]) -> dict[str, Any]:
            return {
                "normalized": None,
                "task_plan": [],
                "validated_plan_id": None,
                "digest": None,
                "expires_at": None,
                "findings": [finding],
                "launch_allowed": False,
            }

        if not isinstance(manifest_obj, dict):
            finding = _parse_finding(manifest_obj, "manifest root must be a JSON object")
            return invalid_payload(finding)
        try:
            manifest = Manifest.from_obj(manifest_obj)
        except (TypeError, ValueError, OverflowError) as exc:
            finding = _parse_finding(manifest_obj, str(exc))
            return invalid_payload(finding)
        canonical = manifest_to_obj(manifest)
        findings = [
            {
                "code": "manifest.lint",
                "severity": finding.severity,
                "json_pointer": _lint_pointer(manifest, finding.message),
                "message": finding.message,
                "action": "Review the manifest contract before launch.",
            }
            for finding in lint_manifest_detailed(manifest, include_model_log_nudges=True)
        ]
        try:
            validate_manifest_engines(manifest, self.config)
        except ValueError as exc:
            findings.append(_parse_finding(manifest_obj, str(exc)))
        engine_evidence = self._engine_evidence(manifest)
        for row in engine_evidence:
            if row["configured"] and not row["binary_available"]:
                task_index = next(
                    i for i, task in enumerate(manifest.tasks) if task.engine == row["engine"]
                )
                findings.append(
                    {
                        "code": "engine.binary_missing",
                        "severity": "error",
                        "json_pointer": f"/tasks/{task_index}/engine",
                        "message": f"engine {row['engine']} binary is unavailable",
                        "action": "Install the configured engine binary before launch.",
                    }
                )
        required_evidence = self._required_input_evidence(manifest)
        for row in required_evidence:
            if not row["exists"]:
                task_index = next(i for i, task in enumerate(manifest.tasks) if task.key == row["task"])
                findings.append(
                    {
                        "code": "contract.required_input_missing",
                        "severity": "error",
                        "json_pointer": f"/tasks/{task_index}/required_inputs",
                        "message": f"{row['task']}: required input is missing: {row['input']}",
                        "action": "Materialize the required input before launch.",
                    }
                )
        if any(task.full_access for task in manifest.tasks) and not self.config.allow_full_access:
            findings.append(
                {
                    "code": "config.full_access_disabled",
                    "severity": "error",
                    "json_pointer": "/tasks",
                    "message": "full_access requires allow_full_access=true in configuration",
                    "action": "Remove full_access or ask an administrator to enable it.",
                }
            )
        task_plan: list[dict[str, Any]] = []
        for task in manifest.tasks:
            engine = self.config.engines.get(task.engine)
            argv = [] if engine is None else build_worker_command(
                engine,
                taskdir=(manifest.workdir / task.key).resolve(),
                spec=compile_worker_prompt(task),
                full_access=task.full_access,
                engine_args=task.engine_args,
                model=task.model,
            )
            task_plan.append(
                {
                    "key": task.key,
                    "engine": task.engine,
                    "model": task.model or (engine.model_default if engine else ""),
                    "argv": argv,
                    "check": task.check,
                    "timeout_s": task.timeout_s,
                    "required_inputs": list(task.required_inputs),
                    "expected_outputs": list(task.expected_outputs),
                    "expect_files": list(task.expect_files),
                    "owned_paths": list(task.owned_paths),
                    "forbidden_paths": list(task.forbidden_paths),
                    "input_patches": [
                        {"path": item.path, "sha256": item.sha256, "apply": item.apply}
                        for item in task.input_patches
                    ],
                    "full_access": task.full_access,
                    "engine_args": list(task.engine_args),
                    "max_attempts": task.max_attempts,
                    "layout_policy": task.layout_policy,
                }
            )
        launch_allowed = not any(item["severity"] == "error" for item in findings)
        payload: dict[str, Any] = {
            "normalized": canonical,
            "digest": canonical_digest(canonical),
            "findings": findings,
            "task_plan": task_plan,
            "launch_allowed": launch_allowed,
            "validated_plan_id": None,
            "expires_at": None,
        }
        if launch_allowed:
            plan = self.plans.put(manifest, canonical, actor, self.config, task_plan)
            payload["validated_plan_id"] = plan.plan_id
            payload["expires_at"] = plan.expires_at
        return payload
