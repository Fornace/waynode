"""Versioned atomic local manifest drafts with compare-and-set revisions."""

from __future__ import annotations

import json
import secrets
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from hammersmith.state_io import atomic_write_text, interprocess_lock

from .canonical import canonical_digest, canonical_json_bytes
from .paths import PathCapability


class DraftNotFound(LookupError):
    pass


class DraftConflict(RuntimeError):
    def __init__(self, message: str, *, current: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.current = current


def _iso(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat()


def _safe_id(value: str) -> bool:
    allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
    return 16 <= len(value) <= 80 and all(character in allowed for character in value)


class DraftStore:
    def __init__(self, state_dir: Path, *, clock: Callable[[], float] = time.time) -> None:
        self.root = (state_dir / "drafts").resolve()
        self.capability = PathCapability((self.root,))
        self.lock_path = state_dir / ".drafts.lock"
        self.clock = clock

    def _path(self, draft_id: str) -> Path:
        if not _safe_id(draft_id):
            raise DraftNotFound("draft not found")
        path = self.capability.resolve_relative(self.root, f"{draft_id}.json")
        if path is None or path.parent != self.root:
            raise DraftNotFound("draft not found")
        return path

    @staticmethod
    def _load(path: Path) -> dict[str, Any]:
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (FileNotFoundError, OSError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise DraftNotFound("draft not found") from exc
        if not isinstance(value, dict) or not isinstance(value.get("manifest"), dict):
            raise DraftNotFound("draft not found")
        return value

    @staticmethod
    def public(record: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in record.items() if key != "owner"}

    def create(self, manifest: dict[str, Any], *, owner: str) -> dict[str, Any]:
        if not isinstance(manifest, dict):
            raise ValueError("manifest must be an object")
        now = self.clock()
        self.root.mkdir(parents=True, exist_ok=True)
        with interprocess_lock(self.lock_path):
            while True:
                draft_id = secrets.token_urlsafe(18)
                path = self._path(draft_id)
                if not path.exists():
                    break
            record = {
                "id": draft_id,
                "revision": 1,
                "owner": owner,
                "created_at": _iso(now),
                "updated_at": _iso(now),
                "digest": canonical_digest(manifest),
                "manifest": manifest,
            }
            atomic_write_text(path, canonical_json_bytes(record).decode("utf-8") + "\n")
            return record

    def get(self, draft_id: str, *, actor: str, admin: bool = False) -> dict[str, Any]:
        with interprocess_lock(self.lock_path):
            record = self._load(self._path(draft_id))
        if not admin and record.get("owner") != actor:
            raise DraftNotFound("draft not found")
        return record

    def list(self, *, actor: str, admin: bool = False) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        with interprocess_lock(self.lock_path):
            try:
                paths = sorted(self.root.glob("*.json"))
            except OSError:
                paths = []
            for path in paths:
                try:
                    if path.resolve().parent != self.root:
                        continue
                except OSError:
                    continue
                try:
                    record = self._load(path)
                except DraftNotFound:
                    continue
                if admin or record.get("owner") == actor:
                    rows.append({key: value for key, value in record.items() if key != "manifest"})
        rows.sort(key=lambda item: (str(item.get("updated_at", "")), str(item.get("id", ""))), reverse=True)
        return rows

    def update(
        self,
        draft_id: str,
        manifest: dict[str, Any],
        *,
        revision: int,
        actor: str,
        admin: bool = False,
    ) -> dict[str, Any]:
        if not isinstance(manifest, dict):
            raise ValueError("manifest must be an object")
        if isinstance(revision, bool) or not isinstance(revision, int) or revision < 1:
            raise ValueError("revision must be a positive integer")
        with interprocess_lock(self.lock_path):
            path = self._path(draft_id)
            record = self._load(path)
            if not admin and record.get("owner") != actor:
                raise DraftNotFound("draft not found")
            if record.get("revision") != revision:
                raise DraftConflict("draft revision is stale", current=self.public(record))
            record["revision"] = revision + 1
            record["updated_at"] = _iso(self.clock())
            record["digest"] = canonical_digest(manifest)
            record["manifest"] = manifest
            atomic_write_text(path, canonical_json_bytes(record).decode("utf-8") + "\n")
            return record

    def delete(
        self, draft_id: str, *, revision: int, actor: str, admin: bool = False
    ) -> dict[str, Any]:
        with interprocess_lock(self.lock_path):
            path = self._path(draft_id)
            record = self._load(path)
            if not admin and record.get("owner") != actor:
                raise DraftNotFound("draft not found")
            if record.get("revision") != revision:
                raise DraftConflict("draft revision is stale", current=self.public(record))
            path.unlink()
        return {"id": draft_id, "deleted": True, "revision": revision}
