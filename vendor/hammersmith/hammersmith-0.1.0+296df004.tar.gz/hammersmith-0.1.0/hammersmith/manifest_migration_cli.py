"""Command-line interface for manifest migration."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .manifest_migration import manifest_migration_report, migrate_legacy_manifest_obj
from .manifest_migration_models import (
    MIGRATION_REVIEW_FIELDS, ManifestMigrationResult,
)
from .state_io import atomic_create_text, atomic_write_text

def print_manifest_migration_report(report: dict[str, Any]) -> None:
    status = str(report["status"]).upper()
    print(f"migration: {status}")
    print(f"source: {report['source']} (preserved)")
    for change in report["alias_changes"]:
        print(f"alias: {change}")
    if not report["alias_changes"]:
        print("alias: no legacy aliases found")
    print("structured contract review:")
    for field_name in MIGRATION_REVIEW_FIELDS:
        print(f"- {field_name}: {report['structured_review'][field_name]}")
    manual = report["manual_translations"]
    if manual:
        print("manual translations required:")
        for issue in manual:
            print(f"- {issue['location']}: {issue['message']}")
            print(f"  action: {issue['required_action']}")
    else:
        print("manual translations required: none")
    if report["output"]:
        verb = "wrote" if report["status"] == "written" else "requested output"
        print(f"{verb}: {report['output']}")
    else:
        print("dry-run: no file written; pass --output PATH to write a ready migration")


def run_manifest_migration_command(args: argparse.Namespace) -> int:
    source_path = args.manifest.expanduser().resolve()

    def fail(message: str, *, output_path: Path | None = None) -> int:
        if args.json:
            print(
                json.dumps(
                    {
                        "schema": "hammersmith.manifest-migration.v1",
                        "status": "error",
                        "source": str(source_path),
                        "source_preserved": True,
                        "output": str(output_path) if output_path is not None else None,
                        "error": message,
                    },
                    indent=2,
                    ensure_ascii=False,
                )
            )
        else:
            print(f"migration: ERROR: {message}")
        return 2

    try:
        data = json.loads(source_path.read_text(encoding="utf-8"))
        result = migrate_legacy_manifest_obj(data, source_path=source_path)
    except Exception as exc:
        return fail(str(exc))

    output_path = args.output.expanduser().resolve() if args.output is not None else None
    if args.force and output_path is None:
        return fail("--force requires --output")
    if output_path == source_path:
        return fail("--output must differ from the source manifest", output_path=output_path)
    if output_path is not None and output_path.exists() and not args.force:
        return fail(
            f"output exists (use --force): {output_path}", output_path=output_path
        )

    written = False
    if output_path is not None and not result.blocked:
        output_text = json.dumps(result.manifest, indent=2, ensure_ascii=False) + "\n"
        try:
            if args.force:
                atomic_write_text(output_path, output_text)
            else:
                atomic_create_text(output_path, output_text)
        except FileExistsError:
            return fail(
                f"output was created concurrently (use --force): {output_path}",
                output_path=output_path,
            )
        written = True

    report = manifest_migration_report(
        result,
        source_path=source_path,
        output_path=output_path,
        written=written,
    )
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print_manifest_migration_report(report)
    return 2 if result.blocked else 0
