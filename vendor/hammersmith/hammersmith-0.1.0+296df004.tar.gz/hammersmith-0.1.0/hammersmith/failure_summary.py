"""Bounded, credential-safe failure summarization client."""
from __future__ import annotations

import json
import os
import ssl
import urllib.request
from pathlib import Path
from typing import Any, Callable

from .config_models import FailureSummaryConfig
from .utils.io import parse_env_file


def bounded_failure_excerpt(text: str, limit: int = 2_000) -> str:
    """Preserve both setup and terminal failure evidence within a strict bound."""
    clean = text.strip()
    if len(clean) <= limit:
        return clean
    marker = "\n\n... [middle of check output omitted] ...\n\n"
    available = max(0, limit - len(marker))
    head_size = min(600, available // 3)
    tail_size = available - head_size
    return clean[:head_size] + marker + clean[-tail_size:]


def redact_environment_credentials(
    text: str,
    extra: dict[str, str] | None = None,
) -> str:
    """Replace exact credential values before optional remote summarization."""
    secret_markers = ("KEY", "TOKEN", "SECRET", "PASSWORD", "CREDENTIAL")
    redacted = text
    for candidates in (extra or {}, os.environ):
        for name, value in candidates.items():
            upper_name = name.upper()
            if not any(marker in upper_name for marker in secret_markers):
                continue
            if not isinstance(value, str) or len(value) < 8:
                continue
            redacted = redacted.replace(value, "[REDACTED]")
    return redacted


class LiteLLMFailureSummarizer:
    """Small, fail-open OpenAI-compatible client used only for retry explanations."""

    SYSTEM_PROMPT = (
        "Summarize a failed build or test check for an autonomous coding retry. "
        "Return plain text only. Identify the exact failed invariant, the likely cause "
        "supported by the log, relevant files/symbols/tests, and the smallest next action. "
        "If the cause is not explicit, say it is unknown. Do not name frameworks or facts "
        "absent from the evidence, include credentials, claim success, or suggest weakening checks."
    )

    def __init__(
        self,
        config: FailureSummaryConfig,
        *,
        opener: Callable[..., Any] | None = None,
    ) -> None:
        self.config = config
        self.opener = opener

    def _ssl_context(self, file_values: dict[str, str]) -> ssl.SSLContext:
        configured = self.config.ca_file
        env_path = (
            os.environ.get(self.config.ca_file_env, "")
            or file_values.get(self.config.ca_file_env, "")
        ).strip()
        candidates = [
            configured,
            Path(env_path).expanduser() if env_path else None,
            Path("/etc/ssl/cert.pem"),
            Path("/opt/homebrew/etc/openssl@3/cert.pem"),
            Path("/opt/homebrew/etc/ca-certificates/cert.pem"),
        ]
        for candidate in candidates:
            if candidate is not None and candidate.is_file():
                return ssl.create_default_context(cafile=str(candidate))
        return ssl.create_default_context()

    def summarize(
        self,
        output: str,
        *,
        check: str,
        returncode: int | None,
        timed_out: bool,
    ) -> str:
        file_values = parse_env_file(self.config.env_file) if self.config.env_file else {}
        base_url = (
            os.environ.get(self.config.base_url_env, "")
            or file_values.get(self.config.base_url_env, "")
            or self.config.base_url
        ).strip().rstrip("/")
        if not base_url:
            raise ValueError("failure summary base URL is unavailable")
        api_key = (
            os.environ.get(self.config.api_key_env, "")
            or file_values.get(self.config.api_key_env, "")
        ).strip()
        endpoint = (
            base_url
            if base_url.endswith("/chat/completions")
            else base_url + "/chat/completions"
        )
        clipped = bounded_failure_excerpt(output, self.config.max_input_chars)
        safe_output = redact_environment_credentials(clipped, file_values)
        safe_check = redact_environment_credentials(check, file_values)
        user_prompt = (
            f"Check command:\n{safe_check}\n\n"
            f"Exit code: {returncode}\nTimed out: {timed_out}\n\n"
            f"Raw check output:\n{safe_output}"
        )
        payload = json.dumps(
            {
                "model": self.config.model,
                "messages": [
                    {
                        "role": "system",
                        "content": self.SYSTEM_PROMPT
                        + f" Keep the response under {self.config.max_output_chars} characters.",
                    },
                    {"role": "user", "content": user_prompt},
                ],
                "temperature": 0,
                "max_tokens": self.config.max_tokens,
            }
        ).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        request = urllib.request.Request(
            endpoint,
            data=payload,
            headers=headers,
            method="POST",
        )
        if self.opener is not None:
            opened = self.opener(request, timeout=self.config.timeout_s)
        else:
            opened = urllib.request.urlopen(
                request,
                timeout=self.config.timeout_s,
                context=self._ssl_context(file_values),
            )
        with opened as response:
            result = json.loads(response.read().decode("utf-8", errors="replace"))
        choice = result["choices"][0]
        if choice.get("finish_reason") == "length":
            raise ValueError("failure summary model exhausted its output token cap")
        content = choice["message"]["content"]
        if isinstance(content, list):
            content = "\n".join(
                str(item.get("text", ""))
                for item in content
                if isinstance(item, dict) and item.get("text")
            )
        summary = str(content).strip()
        if not summary:
            raise ValueError("failure summary model returned empty content")
        return summary[: self.config.max_output_chars]


__all__ = [
    "LiteLLMFailureSummarizer",
    "bounded_failure_excerpt",
    "redact_environment_credentials",
]
