"""Structural checks and advisory lint for manifests."""

from __future__ import annotations

import fnmatch
import hashlib
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

from .constants import MODEL_SCOREBOARD_RUN_NAME
from .manifest_checks import (
    check_cannot_fail, check_may_fail_silently, instructs_git_commit,
    is_relative_expect_file, spec_is_file_pointer,
)
from .utils.activity import shorten

from .manifest_models import Manifest

FILE_TEST_OPS = {"-e", "-f", "-s", "-d", "-r", "-w", "-x", "-L"}


@dataclass(frozen=True)
class LintFinding:
    severity: str
    message: str


def resolve_manifest_path(manifest: Manifest, value: str) -> Path:
    path = Path(value).expanduser()
    if path.is_absolute():
        return path.resolve()
    base = manifest.source_path.parent if manifest.source_path is not None else Path.cwd()
    return (base / path).resolve()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while chunk := fh.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def normalize_contract_path(value: str) -> str:
    clean = value.strip().replace("\\", "/")
    while clean.startswith("./"):
        clean = clean[2:]
    return clean.rstrip("/")


def contract_path_covers(owner: str, target: str) -> bool:
    owner_clean = normalize_contract_path(owner)
    target_clean = normalize_contract_path(target)
    if not owner_clean or not target_clean:
        return False
    if any(char in owner_clean for char in "*?["):
        return fnmatch.fnmatchcase(target_clean, owner_clean)
    return target_clean == owner_clean or target_clean.startswith(owner_clean + "/")


def owned_paths_overlap(left: str, right: str) -> bool:
    return contract_path_covers(left, right) or contract_path_covers(right, left)


def structural_manifest_findings(manifest: Manifest) -> list[LintFinding]:
    findings: list[LintFinding] = []
    if manifest.shared_check and check_cannot_fail(manifest.shared_check):
        findings.append(
            LintFinding(
                "error",
                "manifest: shared_check cannot fail, so clean-baseline and candidate smoke proofs are meaningless.",
            )
        )
    frontend_tasks = [
        task for task in manifest.tasks if "frontend" in task.task_type.casefold()
    ]
    if manifest.max_parallel > 1 and len(frontend_tasks) > 1 and not manifest.shared_check:
        findings.append(
            LintFinding(
                "error",
                "manifest: concurrent frontend tasks require shared_check so the clean baseline and every candidate patch run the same integration smoke.",
            )
        )
    for task in manifest.tasks:
        for owner in task.owned_paths:
            for forbidden in task.forbidden_paths:
                if owned_paths_overlap(owner, forbidden):
                    findings.append(
                        LintFinding(
                            "error",
                            f"{task.key}: owned path {owner} conflicts with forbidden path {forbidden}.",
                        )
                    )
        for output in task.expected_outputs:
            if not any(contract_path_covers(owner, output) for owner in task.owned_paths):
                findings.append(
                    LintFinding(
                        "error",
                        f"{task.key}: expected output {output} is outside owned_paths.",
                    )
                )
        for patch in task.input_patches:
            patch_path = resolve_manifest_path(manifest, patch.path)
            if not patch_path.is_file():
                findings.append(
                    LintFinding(
                        "error",
                        f"{task.key}: input patch does not exist: {patch.path}.",
                    )
                )
                continue
            if patch.sha256:
                if not re.fullmatch(r"[0-9a-f]{64}", patch.sha256):
                    findings.append(
                        LintFinding(
                            "error",
                            f"{task.key}: input patch sha256 is invalid for {patch.path}.",
                        )
                    )
                elif sha256_file(patch_path) != patch.sha256:
                    findings.append(
                        LintFinding(
                            "error",
                            f"{task.key}: input patch sha256 mismatch for {patch.path}.",
                        )
                    )
        patches_to_apply = [
            resolve_manifest_path(manifest, patch.path)
            for patch in task.input_patches
            if patch.apply and resolve_manifest_path(manifest, patch.path).is_file()
        ]
        if patches_to_apply and manifest.worktrees and manifest.repo is not None:
            check = subprocess.run(
                [
                    "git",
                    "-C",
                    str(manifest.repo),
                    "apply",
                    "--check",
                    *(str(path) for path in patches_to_apply),
                ],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                check=False,
            )
            if check.returncode != 0:
                detail = shorten(check.stdout.strip(), 300) or "git apply --check failed"
                findings.append(
                    LintFinding(
                        "error",
                        f"{task.key}: input patch set cannot apply cleanly: {detail}",
                    )
                )
    if manifest.max_parallel > 1:
        for index, left in enumerate(manifest.tasks):
            for right in manifest.tasks[index + 1 :]:
                overlaps = sorted(
                    {
                        f"{left_path} <> {right_path}"
                        for left_path in left.owned_paths
                        for right_path in right.owned_paths
                        if owned_paths_overlap(left_path, right_path)
                    }
                )
                if overlaps:
                    findings.append(
                        LintFinding(
                            "error",
                            f"manifest: concurrent ownership collision between {left.key} and "
                            f"{right.key}: {', '.join(overlaps)}.",
                        )
                    )
    return findings


def _lint_manifest_warnings(manifest: Manifest, *, include_model_log_nudges: bool = False) -> list[str]:
    findings: list[str] = []
    if manifest.run_name == MODEL_SCOREBOARD_RUN_NAME:
        findings.append("manifest: run_name model-scoreboard is reserved for the scoreboard page.")
    for task in manifest.tasks:
        if check_cannot_fail(task.check):
            findings.append(f"{task.key}: check cannot fail, so the task cannot be verified.")
        if check_may_fail_silently(task.check):
            findings.append(
                f"{task.key}: check may fail without printing why; retry prompt and eval log depend on failure output."
            )
        if manifest.worktrees and any(is_relative_expect_file(path) for path in task.expect_files):
            findings.append(
                f"{task.key}: deliverable would be deleted with the worktree; write it outside the worktree or export it in the check."
            )
        if manifest.worktrees and instructs_git_commit(task.spec):
            findings.append(
                f"{task.key}: worker commits die with the worktree; have the worker leave changes uncommitted and export the diff in the check."
            )
        if len(task.spec.strip()) < 80:
            findings.append(
                f"{task.key}: spec is probably underspecified; workers are stateless and cannot ask questions."
            )
        if spec_is_file_pointer(task.spec):
            findings.append(
                f"{task.key}: spec is a pointer to an instruction file; anyone watching Hammersmith "
                "sees no real brief and the retry prompt loses context; put the instructions in the spec itself."
            )
        if not task.expect_files and not manifest.worktrees:
            findings.append(
                f"{task.key}: no expect_files; the results page will guess deliverables from the "
                "task folder; declare them so the reader sees exactly the right work."
            )
        if not task.verified:
            findings.append(
                f"{task.key}: no 'verified' description; a reader of the results page sees "
                "'checked' but not what the check proves; add one plain-English sentence."
            )
        if include_model_log_nudges and not task.task_type:
            findings.append(
                f"{task.key}: no task_type; the model log buckets this as (untyped); "
                "name one (e.g. code-feature, research, image-gen) so 'hammersmith models' can guide routing."
            )

    if len(manifest.tasks) >= 3 and manifest.max_parallel == 1:
        findings.append("manifest: tasks will run serially; set max_parallel.")

    if not manifest.worktrees:
        # Relative expect_files resolve inside each task's own directory and
        # cannot collide; only a shared absolute path is a real collision.
        paths_to_tasks: dict[str, list[str]] = {}
        for task in manifest.tasks:
            for path in task.expect_files:
                if not Path(path).expanduser().is_absolute():
                    continue
                paths_to_tasks.setdefault(path, []).append(task.key)
        for path, task_keys in paths_to_tasks.items():
            if len(task_keys) >= 2:
                findings.append(
                    f"manifest: write collision on {path}: listed by {', '.join(task_keys)}."
                )

    return findings


def lint_manifest_detailed(
    manifest: Manifest, *, include_model_log_nudges: bool = False
) -> list[LintFinding]:
    findings = structural_manifest_findings(manifest)
    findings.extend(
        LintFinding("warning", message)
        for message in _lint_manifest_warnings(
            manifest, include_model_log_nudges=include_model_log_nudges
        )
    )
    return findings


def lint_manifest(manifest: Manifest, *, include_model_log_nudges: bool = False) -> list[str]:
    """Compatibility wrapper returning plain messages for existing callers."""
    return [
        finding.message
        for finding in lint_manifest_detailed(
            manifest, include_model_log_nudges=include_model_log_nudges
        )
    ]
