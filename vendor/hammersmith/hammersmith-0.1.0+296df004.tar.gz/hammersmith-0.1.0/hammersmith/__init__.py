"""Hammersmith core implementation modules."""
from __future__ import annotations

import os
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from hammersmith import catalog as _catalog
from hammersmith import catalog_cli as _catalog_cli
from hammersmith import config_loading as _config_loading
from hammersmith import models_api as _models_api
from hammersmith import models_cli as _models_cli
from hammersmith import worker as _worker
from hammersmith.active_runs import (
    active_runs_path, read_active_runs, register_active_run, unregister_active_run,
)
from hammersmith.adjudication import run_adjudicate_command
from hammersmith.artifacts.core import file_href
from hammersmith.artifacts.library import (
    artifact_library_path, artifact_live_path, artifact_version_path,
    read_artifact_library, reconcile_artifact_library_dead_runs,
    update_artifact_library_live,
)
from hammersmith.artifacts.model_aggregation import aggregate_model_scoreboard_rows
from hammersmith.artifacts.model_metrics import humanized_log_date
from hammersmith.artifacts.model_notes import (
    model_judgment_notes, parse_model_notes_sections,
)
from hammersmith.artifacts.pages import (
    render_artifact_index_html, render_final_report_html, render_status_html,
)
from hammersmith.artifacts.renderer import ArtifactRenderer
from hammersmith.artifacts.styles import ARTIFACT_BASE_CSS
from hammersmith.browser import open_in_browser
from hammersmith.catalog import (
    CatalogRefreshResult, catalog_changes_path, normalize_catalog_payload,
)
from hammersmith.catalog_cli import run_catalog_command
from hammersmith.cli import main
from hammersmith.cli import hud as _hud
from hammersmith.cli.planning import (
    preflight_engine_bins, print_steering_notes, validate_manifest_engines,
)
from hammersmith.config import (
    ArtifactConfig, EngineConfig, EvalConfig, FailureSummaryConfig,
    SteeringConfig, SteeringProfile, SteeringRule, env_config_path, load_engines,
    load_steering_config, parse_steering_profile, resolve_steering_profile,
    steering_profile_candidates,
)
from hammersmith.config_loading import AppConfig as _AppConfig
from hammersmith.constants import (
    ARTIFACT_WRAPPER_TAIL_BYTES, CSP_META_TAG, DELIVERABLE_MAX_BYTES,
    HAMMERSMITH_HTML_PATH, RESERVED_FIXTURE_MODELS, WORKER_LOG_TAIL_BYTES,
)
from hammersmith.eval_logging import EvalLogger
from hammersmith.failure import (
    FailureAssessment, LiteLLMFailureSummarizer, bounded_failure_excerpt,
    classify_failure, compile_retry_spec,
)
from hammersmith.http_server import dashboard_html as _dashboard_html
from hammersmith.http_server.servers import Dashboard, PersistentHudServer as _PersistentHudServer
from hammersmith.http_server.state import build_projects_snapshot
from hammersmith.identity import product_identity, project_identity
from hammersmith.manifest_lint import lint_manifest, lint_manifest_detailed
from hammersmith.manifest_migration import migrate_legacy_manifest_obj
from hammersmith.manifest_models import Manifest, TaskSpec
from hammersmith.model_identity import (
    enrich_model_groups_with_identity, load_model_identity_registry,
)
from hammersmith.model_routing import routing_suggestion
from hammersmith.model_log import (
    aggregate_model_log_rows, model_log_row_is_retry, read_model_log_rows,
)
from hammersmith.models_cli import print_model_log_table
from hammersmith.prompt import compile_worker_prompt
from hammersmith.read_model import (
    ReadModelSyncResult, connect_read_model_db, create_read_model_schema,
    db_catalog_models, rebuild_read_model_db, sync_read_model_db,
)
from hammersmith.runner import HammersmithRunner as _HammersmithRunner
from hammersmith.runtime import TaskRuntime, VerifyResult, WorkerResult
from hammersmith.state_io import hammersmith_home
from hammersmith.state_writer import StateWriter
from hammersmith.steering import inject_steering_spec
from hammersmith.utils.io import atomic_create_text, atomic_write_json
from hammersmith.utils.models import (
    build_run_id, build_worker_command, effective_model_from_command,
    parse_reported_model, resolve_identity,
)
from hammersmith.verifier import Verifier

hud_is_alive = _hud.hud_is_alive


class AppConfig(_AppConfig):
    """Compatibility subclass that preserves the patched steering-loader seam."""

    @classmethod
    def load(cls, path: Path | None = None) -> "AppConfig":
        previous = _config_loading.load_steering_config
        _config_loading.load_steering_config = load_steering_config
        try:
            return super().load(path)  # type: ignore[return-value]
        finally:
            _config_loading.load_steering_config = previous


class HammersmithRunner(_HammersmithRunner):
    """Runner adapter preserving historical monkeypatch points on this module."""

    async def _run_worker(self, *args: Any, **kwargs: Any) -> WorkerResult:
        old_build = _worker.build_worker_command
        old_resolve = _worker.resolve_steering_profile
        _worker.build_worker_command = build_worker_command
        _worker.resolve_steering_profile = resolve_steering_profile
        try:
            return await super()._run_worker(*args, **kwargs)
        finally:
            _worker.build_worker_command = old_build
            _worker.resolve_steering_profile = old_resolve


class PersistentHudServer(_PersistentHudServer):
    """HUD adapter preserving the configurable HTML asset seam."""

    def start(self) -> int:
        _dashboard_html.HAMMERSMITH_HTML_PATH = HAMMERSMITH_HTML_PATH
        return super().start()


def ensure_hud_running(config: _AppConfig, *, open_browser: bool) -> None:
    old_alive = _hud.hud_is_alive
    old_open = _hud.open_in_browser
    _hud.hud_is_alive = hud_is_alive
    _hud.open_in_browser = open_in_browser
    try:
        _hud.ensure_hud_running(config, open_browser=open_browser)
    finally:
        _hud.hud_is_alive = old_alive
        _hud.open_in_browser = old_open


def refresh_openrouter_catalog(
    snapshot_path: Path,
    *,
    source: str = _catalog.DEFAULT_CATALOG_SOURCE,
    timeout: float = _catalog.CATALOG_FETCH_TIMEOUT_S,
) -> CatalogRefreshResult:
    return _catalog.refresh_openrouter_catalog(
        snapshot_path,
        source=source,
        timeout=timeout,
        atomic_write_json_fn=atomic_write_json,
    )


def start_catalog_auto_refresh(
    *,
    snapshot_path: Path | None = None,
    source: str = _catalog.DEFAULT_CATALOG_SOURCE,
    print_notice: bool = True,
) -> threading.Thread | None:
    return _catalog_cli.start_catalog_auto_refresh(
        snapshot_path=snapshot_path,
        source=source,
        print_notice=print_notice,
        refresh_fn=refresh_openrouter_catalog,
    )


def build_models_api_payload(**kwargs: Any) -> dict[str, Any]:
    old_sync = _models_api.sync_read_model_db
    old_catalog = _models_api.db_catalog_models
    _models_api.sync_read_model_db = sync_read_model_db
    _models_api.db_catalog_models = db_catalog_models
    try:
        return _models_api.build_models_api_payload(**kwargs)
    finally:
        _models_api.sync_read_model_db = old_sync
        _models_api.db_catalog_models = old_catalog


def run_models_command(config: _AppConfig, args: Any) -> int:
    old_sync = _models_cli.sync_read_model_db
    old_catalog = _models_cli.db_catalog_models
    old_open = _models_cli.open_in_browser
    from hammersmith.artifacts import scoreboard as scoreboard_module

    old_datetime = scoreboard_module.datetime
    _models_cli.sync_read_model_db = sync_read_model_db
    _models_cli.db_catalog_models = db_catalog_models
    _models_cli.open_in_browser = open_in_browser
    scoreboard_module.datetime = datetime
    try:
        return _models_cli.run_models_command(config, args)
    finally:
        _models_cli.sync_read_model_db = old_sync
        _models_cli.db_catalog_models = old_catalog
        _models_cli.open_in_browser = old_open
        scoreboard_module.datetime = old_datetime
