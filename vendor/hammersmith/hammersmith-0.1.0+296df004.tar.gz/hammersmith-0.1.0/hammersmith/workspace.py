from __future__ import annotations

import asyncio
import shutil
import time
from pathlib import Path
from typing import Any

from hammersmith.runtime import TaskRuntime, VerifyResult, WorkerResult
from hammersmith.verifier import Verifier
from hammersmith.artifacts.library import artifact_deliverables_dir
from hammersmith.constants import (
    DELIVERABLE_MAX_BYTES, FALLBACK_HARVEST_MAX_FILES,
    FALLBACK_HARVEST_SUFFIXES, TASK_REPORT_FILENAMES,
)
from hammersmith.failure_taxonomy import classify_failure
from hammersmith.manifest_lint import resolve_manifest_path, sha256_file
from hammersmith.prompt import compile_worker_prompt
from hammersmith.utils.io import append_text


class TaskWorkspaceMixin:
    def _harvest_deliverables_on_pass(self, runtime: TaskRuntime) -> None:
        harvested: list[dict[str, Any]] = []
        notes: list[str] = []
        target_dir = artifact_deliverables_dir(
            self.config.state_dir,
            self.run_id,
            runtime.task.key,
        )
        expect_files: tuple[str, ...] = runtime.task.expect_files
        worktree_task = self.manifest.worktrees and self.manifest.repo is not None
        if not expect_files and not worktree_task:
            # (In worktrees mode the taskdir root is a whole repo checkout;
            # guessing there would harvest README.md and friends, not work.)
            # No declared deliverables: rescue what the worker left at the
            # top of its task directory, or the run's real output (a review,
            # a report) never reaches the results page. Declaring
            # expect_files remains the way to control exactly what is shown.
            candidates = sorted(
                path.name
                for path in runtime.taskdir.glob("*")
                if path.is_file()
                and not path.name.startswith(".")
                and path.suffix.lower() in FALLBACK_HARVEST_SUFFIXES
            )
            if len(candidates) > FALLBACK_HARVEST_MAX_FILES:
                notes.append(
                    f"Only the first {FALLBACK_HARVEST_MAX_FILES} of {len(candidates)} files were "
                    "collected automatically; declare expect_files to choose exactly what is kept."
                )
                candidates = candidates[:FALLBACK_HARVEST_MAX_FILES]
            expect_files = tuple(candidates)
        for expect_path in expect_files:
            source = Verifier._expect_file_path(runtime.taskdir, expect_path)
            try:
                stat = source.stat()
            except OSError:
                continue
            if not source.is_file():
                continue
            if stat.st_size > DELIVERABLE_MAX_BYTES:
                notes.append(
                    f"{source.name} was not copied because it is larger than 20 MB "
                    f"({stat.st_size:,} bytes)."
                )
                continue
            target = target_dir / source.name
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
                copied_size = target.stat().st_size
            except OSError as exc:
                append_text(
                    runtime.log_path,
                    f"[hammersmith] deliverable copy failed for {source.name}: {exc}\n",
                )
                continue
            harvested.append({"name": source.name, "path": str(target), "bytes": copied_size})
        if harvested or notes:
            with self.lock:
                runtime.deliverables = harvested
                runtime.deliverable_notes.extend(notes)

    async def _prepare_taskdir(self, runtime: TaskRuntime) -> tuple[bool, str | None]:
        taskdir = runtime.taskdir
        if self.manifest.worktrees and self.manifest.repo is not None:
            taskdir.parent.mkdir(parents=True, exist_ok=True)
            if taskdir.exists():
                return False, f"worktree taskdir already exists: {taskdir}"
            proc = await asyncio.create_subprocess_exec(
                "git",
                "-C",
                str(self.manifest.repo),
                "worktree",
                "add",
                str(taskdir),
                "HEAD",
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            stdout, _ = await proc.communicate()
            if proc.returncode != 0:
                message = stdout.decode("utf-8", errors="replace")
                append_text(runtime.log_path, f"[hammersmith] git worktree add failed:\n{message}\n")
                return False, message.strip() or "git worktree add failed"
        else:
            taskdir.mkdir(parents=True, exist_ok=True)
        for required in runtime.task.required_inputs:
            required_path = Path(required).expanduser()
            if not required_path.is_absolute():
                required_path = taskdir / required_path
            if not required_path.exists():
                message = f"CONTRACT_BLOCKED: required input is missing: {required}"
                append_text(runtime.log_path, f"[hammersmith] {message}\n")
                return False, message
        for patch_index, input_patch in enumerate(runtime.task.input_patches):
            patch_path = resolve_manifest_path(self.manifest, input_patch.path)
            with self.lock:
                status = runtime.input_patch_status[patch_index]
                status["resolved_path"] = str(patch_path)
                status["status"] = "checking"
            if not patch_path.is_file():
                status["status"] = "missing"
                message = f"CONTRACT_BLOCKED: input patch is missing: {input_patch.path}"
                append_text(runtime.log_path, f"[hammersmith] {message}\n")
                return False, message
            actual_sha256 = sha256_file(patch_path)
            status["sha256"] = actual_sha256
            if input_patch.sha256 and actual_sha256 != input_patch.sha256:
                status["status"] = "hash-mismatch"
                message = (
                    f"CONTRACT_BLOCKED: input patch sha256 mismatch: {input_patch.path} "
                    f"expected={input_patch.sha256} actual={actual_sha256}"
                )
                append_text(runtime.log_path, f"[hammersmith] {message}\n")
                return False, message
            if not input_patch.apply:
                status["status"] = "verified-only"
                append_text(
                    runtime.log_path,
                    f"[hammersmith] input patch verified sha256={actual_sha256} "
                    f"apply=false path={input_patch.path}\n",
                )
                continue
            check = await asyncio.create_subprocess_exec(
                "git",
                "apply",
                "--check",
                str(patch_path),
                cwd=str(taskdir),
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            check_output, _ = await check.communicate()
            if check.returncode != 0:
                status["status"] = "cannot-apply"
                detail = check_output.decode("utf-8", errors="replace").strip()
                message = (
                    f"CONTRACT_BLOCKED: input patch cannot apply: {input_patch.path}: "
                    f"{detail or 'git apply --check failed'}"
                )
                append_text(runtime.log_path, f"[hammersmith] {message}\n")
                return False, message
            apply_proc = await asyncio.create_subprocess_exec(
                "git",
                "apply",
                str(patch_path),
                cwd=str(taskdir),
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            apply_output, _ = await apply_proc.communicate()
            if apply_proc.returncode != 0:
                status["status"] = "apply-failed"
                detail = apply_output.decode("utf-8", errors="replace").strip()
                message = (
                    f"CONTRACT_BLOCKED: input patch apply failed: {input_patch.path}: "
                    f"{detail or 'git apply failed'}"
                )
                append_text(runtime.log_path, f"[hammersmith] {message}\n")
                return False, message
            status["status"] = "applied"
            append_text(
                runtime.log_path,
                f"[hammersmith] input patch applied sha256={actual_sha256} "
                f"path={input_patch.path}\n",
            )
        with self.lock:
            runtime.contract_preflight = "passed"
        return True, None

    async def _cleanup_worktree_on_pass(self, runtime: TaskRuntime) -> None:
        if not (self.manifest.worktrees and self.manifest.repo is not None):
            return
        self._snapshot_worktree_reports(runtime)
        proc = await asyncio.create_subprocess_exec(
            "git",
            "-C",
            str(self.manifest.repo),
            "worktree",
            "remove",
            "--force",
            str(runtime.taskdir),
            stdin=asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        stdout, _ = await proc.communicate()
        if proc.returncode != 0:
            message = stdout.decode("utf-8", errors="replace")
            append_text(runtime.log_path, f"[hammersmith] git worktree remove failed:\n{message}\n")

    def _snapshot_worktree_reports(self, runtime: TaskRuntime) -> None:
        copied: dict[str, Path] = {}
        report_dir = (runtime.log_path.parent / f"{runtime.log_path.stem}.reports").resolve()
        for report_name in TASK_REPORT_FILENAMES:
            source = runtime.taskdir / report_name
            if not source.exists():
                continue
            target = report_dir / report_name
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
            except OSError as exc:
                append_text(
                    runtime.log_path,
                    f"[hammersmith] report snapshot failed for {report_name}: {exc}\n",
                )
                continue
            copied[report_name] = target
        if copied:
            with self.lock:
                runtime.report_paths.update(copied)

    async def _record_prepare_error(self, runtime: TaskRuntime, error: str) -> None:
        with self.lock:
            runtime.attempts = 0
            runtime.status = "fail"
            runtime.final_verdict = "ERROR"
            runtime.last_check_output = error
            runtime.contract_preflight = "failed"
            runtime.ended_at_monotonic = time.monotonic()
        append_text(
            runtime.log_path,
            f"[hammersmith] preparation failed before worker launch: {error}\n",
        )
        verify = VerifyResult(
            ok=False,
            check_returncode=None,
            check_timed_out=False,
            raw_output_excerpt=error,
            contract_error=error,
        )
        worker = WorkerResult(returncode=None, timed_out=False, tokens=None, error=error)
        assessment = classify_failure(worker, verify)
        with self.lock:
            runtime.failure_class = assessment.failure_class
            runtime.failure_owner = assessment.failure_owner
            runtime.model_eligible = assessment.model_eligible
            runtime.retry_decision = assessment.retry_decision
            runtime.next_action = assessment.next_action
            runtime.failure_status = assessment.status
            runtime.failure_reason = assessment.reason
        self._log_attempt(
            runtime, compile_worker_prompt(runtime.task), False, worker, verify, "ERROR", 0,
            assessment=assessment,
        )
