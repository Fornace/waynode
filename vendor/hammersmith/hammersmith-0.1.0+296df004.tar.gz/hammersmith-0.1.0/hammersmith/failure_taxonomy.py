"""Deterministic failure classification and retry-contract helpers."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .manifest_models import TaskSpec
from .prompt import compile_worker_prompt
from .runtime import VerifyResult, WorkerResult

from hammersmith.failure_models import FailureAssessment


FAILURE_CLASSES = frozenset(
    {
        "model_semantic",
        "model_instruction_following",
        "contract_invalid",
        "check_bug",
        "harness_baseline",
        "harness_flaky",
        "patch_export",
        "provider_budget",
        "provider_auth",
        "provider_timeout",
        "worker_stall",
        "host_interrupted",
        "missing_input",
        "scope_violation",
        "unknown",
    }
)

RETRYABLE_FAILURE_CLASSES = frozenset(
    {"model_semantic", "model_instruction_following", "scope_violation", "patch_export"}
)
ENGINE_CIRCUIT_FAILURE_CLASSES = frozenset(
    {
        "provider_budget",
        "provider_auth",
        "provider_timeout",
        "worker_stall",
        "host_interrupted",
    }
)
ENGINE_CIRCUIT_THRESHOLD = 2


def _contains_known_signal(text: str, literals: tuple[str, ...]) -> bool:
    """Match only small, provider-owned literals; variable prose is never parsed here."""
    lowered = text.casefold()
    return any(literal in lowered for literal in literals)


def classify_failure(
    worker: WorkerResult,
    verify: VerifyResult,
) -> FailureAssessment:
    """Classify known failure evidence conservatively, with an explicit unknown fallback."""
    evidence = "\n".join(
        part for part in (worker.error or "", worker.output_excerpt) if part
    )
    if verify.contract_error:
        return FailureAssessment(
            "contract_invalid",
            "contract",
            False,
            "stop",
            "repair task contract",
            "contract_invalid",
            verify.contract_error,
        )
    if verify.failure_stage == "baseline_shared_check":
        return FailureAssessment(
            "harness_baseline",
            "check",
            False,
            "escalate_harness_repair",
            "repair the shared harness before launching implementation workers",
            "harness_baseline_failed",
            "shared check failed on the clean baseline",
        )
    if verify.failure_stage == "candidate_shared_check_flaky":
        return FailureAssessment(
            "harness_flaky",
            "check",
            False,
            "escalate_harness_repair",
            "stabilize the shared harness before retrying implementation work",
            "shared_check_flaky",
            "candidate shared check failed and immediately passed",
        )
    if _contains_known_signal(
        evidence,
        (
            "budget has been exceeded",
            "max budget",
            "http 429",
            "status=429",
            "rate limit budget",
        ),
    ):
        return FailureAssessment(
            "provider_budget",
            "provider",
            False,
            "stop",
            "restore provider budget, then probe the engine",
            "provider_budget",
            "provider budget/rate limit signal",
        )
    if _contains_known_signal(
        evidence,
        (
            "refresh token was already used",
            "failed to refresh token",
            "http 401",
            "status=401",
            "http 403",
            "status=403",
            "authentication failed",
            "unauthorized",
        ),
    ):
        return FailureAssessment(
            "provider_auth",
            "provider",
            False,
            "stop",
            "repair credentials, then probe the engine",
            "provider_auth",
            "provider authentication signal",
        )
    if _contains_known_signal(
        evidence,
        (
            "provider timeout",
            "gateway timeout",
            "http 504",
            "status=504",
            "connection timed out",
            "connect timeout",
        ),
    ):
        return FailureAssessment(
            "provider_timeout",
            "provider",
            False,
            "stop",
            "probe provider health before resuming",
            "provider_timeout",
            "provider timeout signal",
        )
    if _contains_known_signal(
        evidence,
        (
            "host interrupted",
            "system sleep",
            "computer sleep",
            "sigterm from host",
            "launchd terminated",
        ),
    ):
        return FailureAssessment(
            "host_interrupted",
            "host",
            False,
            "stop",
            "resume after host availability is stable",
            "host_interrupted",
            "host interruption signal",
        )
    if _contains_known_signal(
        worker.error or "",
        ("no such file or directory", "missing input", "input patch does not exist"),
    ):
        return FailureAssessment(
            "missing_input",
            "contract",
            False,
            "stop",
            "supply and validate required input",
            "missing_input",
            worker.error or "missing input",
        )
    if _contains_known_signal(
        worker.error or "",
        (
            "taskdir preparation failed",
            "worktree taskdir already exists",
            "invalid task contract",
        ),
    ):
        return FailureAssessment(
            "contract_invalid",
            "contract",
            False,
            "stop",
            "repair task contract before relaunch",
            "contract_invalid",
            worker.error or "invalid task contract",
        )
    if verify.check_timed_out:
        return FailureAssessment(
            "check_bug",
            "check",
            False,
            "stop",
            "repair or right-size the executable check",
            "check_timeout",
            "verification check timed out",
        )
    if worker.timed_out:
        reason = (
            "worker timed out without observable output"
            if not worker.output_excerpt.strip()
            else "worker timed out after producing output"
        )
        return FailureAssessment(
            "worker_stall",
            "provider",
            False,
            "stop",
            "inspect worker/provider health before retrying",
            "worker_timeout",
            reason,
        )
    if verify.unexpected_paths:
        return FailureAssessment(
            "scope_violation",
            "model",
            True,
            "retry",
            "remove unowned changes and make the smallest scoped repair",
            "scope_violation",
            "worker changed paths outside the declared scope",
        )
    if verify.missing_files:
        if any(
            Path(path).suffix.casefold() == ".patch" for path in verify.missing_files
        ):
            return FailureAssessment(
                "patch_export",
                "export",
                False,
                "retry",
                "export the exact verified patch without changing implementation scope",
                "missing_patch_export",
                "required patch export is missing",
            )
        return FailureAssessment(
            "model_instruction_following",
            "model",
            True,
            "retry",
            "create the exact required outputs without renaming",
            "missing_output",
            "required output files are missing",
        )
    if worker.error:
        return FailureAssessment(
            "unknown",
            "provider",
            False,
            "stop",
            "inspect the worker error before deciding whether to retry",
            "worker_error",
            worker.error,
        )
    if worker.returncode not in (None, 0):
        return FailureAssessment(
            "model_instruction_following",
            "model",
            True,
            "retry",
            "make the smallest change needed to complete the task",
            "worker_exit",
            f"worker exited with code {worker.returncode}",
        )
    if not verify.ok:
        return FailureAssessment(
            "model_semantic",
            "model",
            True,
            "retry",
            "repair only the failed executable invariant",
            "check_failed",
            "executed acceptance check failed",
        )
    return FailureAssessment(
        "unknown",
        "model",
        True,
        "stop",
        "inspect contradictory result evidence",
        "unknown",
        "no failure signal found",
    )


def compile_retry_spec(
    task: TaskSpec,
    verify: VerifyResult,
    assessment: FailureAssessment,
) -> str:
    invariant = (
        verify.exact_failure_excerpt.strip()
        or verify.raw_output_excerpt.strip()
        or assessment.reason
    )[:2000]
    missing = "\n".join(f"- {path}" for path in verify.missing_files) or "- none"
    unexpected = (
        "\n".join(f"- {path}" for path in verify.unexpected_paths) or "- none"
    )
    required_files = tuple(
        dict.fromkeys((*task.required_inputs, *task.expected_outputs, *task.expect_files))
    )
    required = "\n".join(f"- {path}" for path in required_files) or "- none"
    observed = "\n".join(f"- {path}" for path in verify.observed_paths) or "- none"
    retry_context = (
        "RETRY CONTRACT: NON-NEGOTIABLE\n"
        "The previous attempt failed the exact invariant below. Make the smallest change needed "
        "to clear it. Do not redesign the solution, rename required files, add unowned paths, "
        "or replace the required layout with an equivalent one.\n\n"
        f"Failure class: {assessment.failure_class}\n"
        f"Expected next action: {assessment.next_action}\n"
        f"Exact invariant:\n{invariant}\n\n"
        f"Files required by the task contract (inspect these first):\n{required}\n\n"
        f"Files observed in the failed attempt:\n{observed}\n\n"
        f"Required missing files:\n{missing}\n\n"
        f"Unexpected changed paths:\n{unexpected}\n\n"
        f"Run this exact pass command before stopping:\n{task.check}\n\n"
        "Do not report completion unless that command exits 0."
    )
    return compile_worker_prompt(task, retry_context=retry_context)


def failure_fingerprint(
    worker: WorkerResult,
    verify: VerifyResult,
    assessment: FailureAssessment,
) -> str:
    """Hash exact deterministic evidence; never semantically guess that failures match."""
    payload = {
        "class": assessment.failure_class,
        "stage": verify.failure_stage,
        "worker_returncode": worker.returncode,
        "worker_timed_out": worker.timed_out,
        "check_returncode": verify.check_returncode,
        "check_timed_out": verify.check_timed_out,
        "missing_files": list(verify.missing_files),
        "unexpected_paths": list(verify.unexpected_paths),
        "exact_failure": verify.exact_failure_excerpt or verify.raw_output_excerpt,
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )
    return hashlib.sha256(encoded).hexdigest()


def verdict_for(worker: WorkerResult, verify: VerifyResult) -> str:
    if worker.error:
        return "ERROR"
    if worker.timed_out or verify.check_timed_out:
        return "TIMEOUT"
    if worker.returncode not in (None, 0):
        return "FAIL"
    if verify.ok:
        return "PASS"
    return "FAIL"


__all__ = [
    "ENGINE_CIRCUIT_FAILURE_CLASSES",
    "ENGINE_CIRCUIT_THRESHOLD",
    "FAILURE_CLASSES",
    "RETRYABLE_FAILURE_CLASSES",
    "classify_failure",
    "compile_retry_spec",
    "failure_fingerprint",
    "verdict_for",
]
