"""Evaluation attempt logging and JSONL record helpers."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from hammersmith.postgres_sink import (
    close_postgres,
    connect_postgres,
    insert_eval_attempt,
)


RESERVED_FIXTURE_MODELS = frozenset(
    {"proven-model", "probation-model", "mock-model", "test-model"}
)


@dataclass(frozen=True)
class PostgresEvalConfig:
    env_file: Path


@dataclass(frozen=True)
class EvalConfig:
    backend: str
    jsonl_path: Path
    postgres: PostgresEvalConfig | None = None


class EvalLogger:
    """Write attempts to PostgreSQL, falling back to append-only JSONL."""

    def __init__(self, config: EvalConfig) -> None:
        self.config = config
        self._conn: Any | None = None
        self._fallback_path = config.jsonl_path
        self._fallback_reason: str | None = None
        if config.backend == "postgres":
            self._connect()

    def log_attempt(self, row: dict[str, Any]) -> None:
        if self._conn is not None:
            try:
                insert_eval_attempt(self._conn, row)
                return
            except Exception as exc:
                self._fallback_reason = f"Supabase insert failed: {exc}"
                self._close_conn()
        self._write_jsonl(row)

    def close(self) -> None:
        self._close_conn()

    def _connect(self) -> None:
        if self.config.postgres is None:
            self._fallback_reason = "postgres eval config missing"
            return
        self._conn, self._fallback_reason = connect_postgres(
            self.config.postgres.env_file
        )

    def _write_jsonl(self, row: dict[str, Any]) -> None:
        self._fallback_path.parent.mkdir(parents=True, exist_ok=True)
        payload = dict(row)
        payload["logged_at"] = datetime.now(timezone.utc).isoformat()
        payload["log_sink"] = "jsonl"
        payload["fallback_reason"] = self._fallback_reason
        with self._fallback_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, sort_keys=True) + "\n")

    def _close_conn(self) -> None:
        close_postgres(self._conn)
        self._conn = None


def parse_log_date(value: Any) -> str:
    if not isinstance(value, str) or len(value) < 10:
        return ""
    candidate = value[:10]
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", candidate):
        return ""
    try:
        datetime.strptime(candidate, "%Y-%m-%d")
    except ValueError:
        return ""
    return candidate


def validate_since_date(value: str | None) -> str | None:
    if value is None:
        return None
    if not parse_log_date(value):
        raise ValueError("--since must be YYYY-MM-DD")
    return value


def model_log_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def model_log_row_engine(row: dict[str, Any]) -> str:
    value = row.get("worker_engine") if "worker_engine" in row else row.get("engine")
    return model_log_text(value)


def model_log_row_model(row: dict[str, Any]) -> str:
    return model_log_text(row.get("model")) or model_log_text(row.get("worker_engine"))


def model_log_row_is_unattributed(row: dict[str, Any]) -> bool:
    return not model_log_text(row.get("model"))


def model_log_row_is_retry(row: dict[str, Any]) -> bool:
    retry = row.get("retry")
    if isinstance(retry, bool):
        return retry
    if isinstance(retry, str) and retry.strip().lower() in {"true", "false"}:
        return retry.strip().lower() == "true"
    notes = row.get("notes", "")
    return isinstance(notes, str) and "retry=true" in notes


def model_log_row_reasoning_effort(row: dict[str, Any]) -> str | None:
    effort = model_log_text(row.get("reasoning_effort"))
    return effort or None


def model_log_row_task_type(row: dict[str, Any]) -> str:
    return model_log_text(row.get("task_type")) or "(untyped)"


def model_log_row_is_model_eligible(row: dict[str, Any]) -> bool:
    value = row.get("model_eligible")
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.strip().casefold() in {"true", "false"}:
        return value.strip().casefold() == "true"
    return True


def model_log_int(value: Any) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def model_log_task_base_key(
    row: dict[str, Any],
) -> tuple[str, str, str, str, str, bool] | None:
    run_id = model_log_text(row.get("run_id"))
    task_key = model_log_text(row.get("task_key"))
    if not run_id or not task_key:
        return None
    unattributed = model_log_row_is_unattributed(row)
    return (
        run_id,
        task_key,
        model_log_row_model(row),
        model_log_row_task_type(row),
        "" if unattributed else (model_log_row_reasoning_effort(row) or ""),
        unattributed,
    )


def apply_adjudication_records(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Overlay append-only parent decisions on attempts without mutating history."""
    decisions: dict[tuple[str, str], dict[str, Any]] = {}
    attempts: list[dict[str, Any]] = []
    for row in rows:
        if model_log_text(row.get("record_type")) == "adjudication":
            key = (model_log_text(row.get("run_id")), model_log_text(row.get("task_key")))
            if all(key):
                decisions[key] = row
            continue
        attempts.append(dict(row))
    for row in attempts:
        key = (model_log_text(row.get("run_id")), model_log_text(row.get("task_key")))
        decision = decisions.get(key)
        if decision is None:
            continue
        outcome = model_log_text(decision.get("outcome"))
        row["parent_outcome"] = outcome
        row["adjudication"] = {
            "outcome": outcome,
            "reason": model_log_text(decision.get("reason")),
            "logged_at": model_log_text(decision.get("logged_at")),
            "adjudicator": model_log_text(decision.get("adjudicator")),
        }
        if outcome == "invalid-task":
            row["model_eligible"] = False
            row["failure_owner"] = "contract"
        elif outcome == "infrastructure":
            row["model_eligible"] = False
            row["failure_owner"] = "provider"
    return attempts


def group_model_log_tasks(rows: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    if any(model_log_text(row.get("record_type")) == "adjudication" for row in rows):
        rows = apply_adjudication_records(rows)
    grouped: list[list[dict[str, Any]]] = []
    active: dict[tuple[str, str, str, str, str, bool], int] = {}
    for row in rows:
        key = model_log_task_base_key(row)
        if key is not None and model_log_row_is_retry(row) and key in active:
            grouped[active[key]].append(row)
            continue
        grouped.append([row])
        if key is not None:
            active[key] = len(grouped) - 1
    return grouped
