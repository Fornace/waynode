"""Configuration path helpers, validation, and TOML loading.

Supports zero-config operation: Hammersmith auto-detects available engines
and provides sensible defaults for all settings. Run ``hammersmith init``
to create a minimal config file, or just start using it — defaults work
out of the box when at least one worker CLI is installed.
"""

from __future__ import annotations

import os
import re
import shutil
import sys
import tomllib
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config_models import (
    CONFIG_DIR_NAME,
    CONFIG_FILE_NAME,
    DEFAULT_CODEX_MODEL_REPORT_REGEX,
    DEFAULT_DASHBOARD_PORT_BASE,
    DEFAULT_ENGINE_NAME,
    DEFAULT_HUD_PORT,
    DEFAULT_TOKEN_REGEX,
    STATE_DIR_NAME,
    ArtifactConfig,
    EngineConfig,
    EvalConfig,
    FailureSummaryConfig,
    PostgresEvalConfig,
)
from .config_defaults import (
    auto_detect_engines,
    auto_detect_pi_installation,
    built_in_codex_engine,
    built_in_pi_engine,
    create_default_config,
    print_setup_instructions,
)
from .identity import environment_setting
from .steering import SteeringConfig, load_steering_config


def default_config_path() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME")
    config_home = Path(base).expanduser() if base else Path.home() / ".config"
    return config_home / CONFIG_DIR_NAME / CONFIG_FILE_NAME


def env_config_path() -> Path | None:
    value = environment_setting("CONFIG")
    if not value or not value.strip():
        return None
    return Path(value).expanduser().resolve()


def default_state_dir() -> Path:
    return Path.home() / STATE_DIR_NAME


def expand_path(value: Any, default: Path) -> Path:
    if value is None:
        return default.expanduser().resolve()
    return Path(str(value)).expanduser().resolve()


def optional_path(value: Any) -> Path | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    return Path(text).expanduser().resolve()


def optional_string(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def as_string_tuple(value: Any, *, key: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise ValueError(f"{key} must be a list")
    return tuple(str(item) for item in value)




def load_eval_config(raw: Any, state_dir: Path) -> EvalConfig:
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raise ValueError("eval must be a TOML table")
    backend = str(raw.get("backend", "jsonl")).strip().lower()
    if backend not in {"jsonl", "postgres"}:
        raise ValueError("eval.backend must be 'jsonl' or 'postgres'")
    jsonl_path = expand_path(raw.get("jsonl_path"), state_dir / "runs.jsonl")
    postgres: PostgresEvalConfig | None = None
    postgres_raw = raw.get("postgres")
    if postgres_raw is not None:
        if not isinstance(postgres_raw, dict):
            raise ValueError("eval.postgres must be a TOML table")
        env_file_raw = optional_string(postgres_raw.get("env_file"))
        if env_file_raw is None:
            raise ValueError("eval.postgres.env_file is required")
        postgres = PostgresEvalConfig(env_file=Path(env_file_raw).expanduser().resolve())
    if backend == "postgres" and postgres is None:
        raise ValueError("eval.backend='postgres' requires [eval.postgres].env_file")
    return EvalConfig(backend=backend, jsonl_path=jsonl_path, postgres=postgres)


def load_hud_port(raw: Any) -> int:
    if raw is None:
        return DEFAULT_HUD_PORT
    if not isinstance(raw, dict):
        raise ValueError("hud must be a TOML table")
    port = int(raw.get("port", DEFAULT_HUD_PORT))
    if port <= 0:
        raise ValueError("hud.port must be positive")
    return port


def load_engines(raw: Any) -> dict[str, EngineConfig]:
    engines: dict[str, EngineConfig] = {"pi": built_in_pi_engine(), "codex": built_in_codex_engine()}
    if raw is None:
        return engines
    if not isinstance(raw, dict):
        raise ValueError("engines must be a TOML table")
    for name, section in raw.items():
        if not isinstance(section, dict):
            raise ValueError(f"engines.{name} must be a TOML table")
        clean_name = str(name).strip()
        if not clean_name:
            raise ValueError("engine name must not be empty")
        base = engines.get(clean_name)
        default_bin = base.bin if base else clean_name
        bin_path = str(section.get("bin", default_bin)).strip()
        if not bin_path:
            raise ValueError(f"engines.{clean_name}.bin must not be empty")
        args_template = as_string_tuple(
            section.get("args_template", list(base.args_template) if base else None),
            key=f"engines.{clean_name}.args_template",
        )
        if not args_template:
            raise ValueError(f"engines.{clean_name}.args_template must not be empty")
        full_access_args = as_string_tuple(
            section.get("full_access_args", list(base.full_access_args) if base else []),
            key=f"engines.{clean_name}.full_access_args",
        )
        sandbox_args = as_string_tuple(
            section.get("sandbox_args", list(base.sandbox_args) if base else []),
            key=f"engines.{clean_name}.sandbox_args",
        )
        token_regex = optional_string(section.get("token_regex"))
        if token_regex is None and base is not None:
            token_regex = base.token_regex
        if token_regex:
            try:
                re.compile(token_regex, flags=re.IGNORECASE)
            except re.error as exc:
                raise ValueError(
                    f"engines.{clean_name}.token_regex is invalid: {exc}"
                ) from exc
        model_report_regex = optional_string(section.get("model_report_regex"))
        if model_report_regex is None and base is not None:
            model_report_regex = base.model_report_regex
        if model_report_regex:
            try:
                compiled_report = re.compile(model_report_regex, flags=re.IGNORECASE)
            except re.error as exc:
                raise ValueError(
                    f"engines.{clean_name}.model_report_regex is invalid: {exc}"
                ) from exc
            if compiled_report.groups < 1:
                raise ValueError(
                    f"engines.{clean_name}.model_report_regex must have a capture group"
                )
        model_default = str(
            section.get("model_default", base.model_default if base else "")
        ).strip()
        engines[clean_name] = EngineConfig(
            name=clean_name,
            bin=bin_path,
            args_template=args_template,
            full_access_args=full_access_args,
            sandbox_args=sandbox_args,
            token_regex=token_regex,
            model_report_regex=model_report_regex,
            model_default=model_default,
        )
    return engines


def load_artifact_config(raw: Any, state_dir: Path) -> ArtifactConfig:
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raise ValueError("artifact must be a TOML table")
    default_dir = state_dir / "artifacts"
    return ArtifactConfig(
        enabled=bool(raw.get("enabled", True)),
        out_template=str(raw.get("out", str(default_dir / "{run_id}.html"))),
        report_template=str(
            raw.get("report_out", str(default_dir / "{run_id}-report.html"))
        ),
        index_out=expand_path(raw.get("index_out"), default_dir / "index.html"),
    )


def load_failure_summary_config(raw: Any) -> FailureSummaryConfig:
    if raw is None:
        return FailureSummaryConfig()
    if not isinstance(raw, dict):
        raise ValueError("failure_summary must be a TOML table")
    enabled = raw.get("enabled", False)
    if not isinstance(enabled, bool):
        raise ValueError("failure_summary.enabled must be a boolean")
    model = str(raw.get("model", "fornace-fast")).strip()
    if enabled and not model:
        raise ValueError("failure_summary.model is required when enabled")
    base_url = str(raw.get("base_url", "")).strip().rstrip("/")
    if base_url:
        parsed = urllib.parse.urlparse(base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("failure_summary.base_url must be an HTTP(S) URL")
    base_url_env = str(raw.get("base_url_env", "FORNACE_LLM_BASE_URL")).strip()
    api_key_env = str(raw.get("api_key_env", "FORNACE_LLM_API_KEY")).strip()
    env_file = optional_path(raw.get("env_file"))
    ca_file = optional_path(raw.get("ca_file"))
    ca_file_env = str(raw.get("ca_file_env", "SSL_CERT_FILE")).strip()
    timeout_s = float(raw.get("timeout_s", 8.0))
    max_input_chars = int(raw.get("max_input_chars", 24_000))
    max_output_chars = int(raw.get("max_output_chars", 2_000))
    max_tokens = int(raw.get("max_tokens", 1_024))
    if timeout_s <= 0 or timeout_s > 30:
        raise ValueError("failure_summary.timeout_s must be in (0, 30]")
    if max_input_chars < 2_000:
        raise ValueError("failure_summary.max_input_chars must be at least 2000")
    if max_output_chars < 256 or max_output_chars > 2_000:
        raise ValueError("failure_summary.max_output_chars must be between 256 and 2000")
    if max_tokens <= 0 or max_tokens > 2_048:
        raise ValueError("failure_summary.max_tokens must be in [1, 2048]")
    if enabled and not (base_url or base_url_env):
        raise ValueError("failure_summary requires base_url or base_url_env when enabled")
    return FailureSummaryConfig(
        enabled=enabled,
        model=model,
        base_url=base_url,
        base_url_env=base_url_env,
        api_key_env=api_key_env,
        env_file=env_file,
        ca_file=ca_file,
        ca_file_env=ca_file_env,
        timeout_s=timeout_s,
        max_input_chars=max_input_chars,
        max_output_chars=max_output_chars,
        max_tokens=max_tokens,
    )


@dataclass(frozen=True)
class AppConfig:
    path: Path | None
    identity_default: str | None
    state_dir: Path
    dashboard_port_base: int
    hud_port: int
    hud_app_path: Path | None
    allow_full_access: bool
    eval: EvalConfig
    engines: dict[str, EngineConfig]
    artifact: ArtifactConfig
    steering: SteeringConfig = field(default_factory=SteeringConfig)
    failure_summary: FailureSummaryConfig = field(default_factory=FailureSummaryConfig)

    @classmethod
    def load(cls, path: Path | None = None) -> "AppConfig":
        environment_path = env_config_path()
        config_path = path or environment_path or default_config_path()
        explicit = path is not None or environment_path is not None
        data: dict[str, Any] = {}
        if config_path.exists():
            with config_path.open("rb") as fh:
                loaded = tomllib.load(fh)
            if not isinstance(loaded, dict):
                raise ValueError("config root must be a TOML table")
            data = loaded
        elif explicit:
            raise ValueError(f"config file not found: {config_path}")
        else:
            # No config file and no explicit path — zero-config mode.
            # Auto-detect engines and inform the user if nothing was found.
            detected = auto_detect_engines()
            if not detected:
                print_setup_instructions()

        state_dir = expand_path(data.get("state_dir"), default_state_dir())
        dashboard_port_base = int(
            data.get("dashboard_port_base", DEFAULT_DASHBOARD_PORT_BASE)
        )
        if dashboard_port_base <= 0:
            raise ValueError("dashboard_port_base must be positive")
        hud_port = load_hud_port(data.get("hud"))
        identity_default = optional_string(data.get("identity_default"))
        hud_app_path = optional_path(data.get("hud_app_path"))
        allow_full_access = bool(data.get("allow_full_access", False))
        eval_config = load_eval_config(data.get("eval"), state_dir)
        engines = load_engines(data.get("engines"))
        artifact_config = load_artifact_config(data.get("artifact"), state_dir)
        failure_summary_config = load_failure_summary_config(data.get("failure_summary"))
        try:
            steering_config = load_steering_config(data.get("steering"))
        except Exception:
            steering_config = SteeringConfig()
        return cls(
            path=config_path if config_path.exists() else None,
            identity_default=identity_default,
            state_dir=state_dir,
            dashboard_port_base=dashboard_port_base,
            hud_port=hud_port,
            hud_app_path=hud_app_path,
            allow_full_access=allow_full_access,
            eval=eval_config,
            engines=engines,
            artifact=artifact_config,
            steering=steering_config,
            failure_summary=failure_summary_config,
        )
