"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import re
from datetime import datetime
from html import escape as html_escape
from pathlib import Path
from typing import Any

from hammersmith.model_log import model_log_text

from .core import file_href
from .model_aggregation import model_scoreboard_tier_rank

def estimated_task_cost(row: dict[str, Any], catalog_model: dict[str, Any] | None) -> float | None:
    median_tokens = row.get("median_tokens")
    if median_tokens is None or catalog_model is None or catalog_model.get("variable_pricing"):
        return None
    if catalog_model.get("free"):
        return 0.0
    try:
        tokens = float(median_tokens)
        prompt_per_m = float(catalog_model.get("prompt_per_m") or 0)
        completion_per_m = float(catalog_model.get("completion_per_m") or 0)
    except (TypeError, ValueError):
        return None
    return tokens * ((prompt_per_m + completion_per_m) / 2.0) / 1_000_000

def model_sort_cost(row: dict[str, Any], catalog_model: dict[str, Any] | None) -> float:
    cost = estimated_task_cost(row, catalog_model)
    if cost is not None:
        return cost
    if row.get("median_tokens") is None:
        return 0.0
    return float("inf")

def order_model_scoreboard_rows(
    rows: list[dict[str, Any]],
    catalog_by_id: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    return sorted(
        rows,
        key=lambda row: (
            1 if row.get("unattributed") else 0,
            model_scoreboard_tier_rank(str(row.get("tier") or "")),
            -float(row.get("first_try_pass_rate") or 0),
            -float(row.get("pass_rate") or 0),
            model_sort_cost(row, catalog_by_id.get(str(row.get("model") or ""))),
            str(row.get("engine") or ""),
            str(row.get("model") or ""),
            str(row.get("reasoning_effort") or ""),
        ),
    )

def fmt_percent(value: Any) -> str:
    try:
        return f"{float(value) * 100:.0f}%"
    except (TypeError, ValueError):
        return "0%"

def fmt_int(value: Any) -> str:
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError):
        return "0"

def fmt_task_cost(value: float | None) -> str:
    if value is None:
        return ""
    if value == 0:
        return "$0/task"
    if value < 0.01:
        return f"${value:.4f}/task"
    return f"${value:.2f}/task"

def fmt_short_task_cost(value: float | None) -> str:
    if value is None:
        return "in plan"
    if value == 0:
        return "free"
    if value < 0.10:
        cents = value * 100
        if cents < 1:
            return "<1¢"
        rounded = round(cents)
        return f"~{rounded}¢"
    return f"${value:.2f}"

def humanized_log_date(value: Any, *, prefix: str = "") -> str:
    text = model_log_text(value)
    if not text:
        return f"{prefix}unknown" if prefix else "unknown"
    candidate = text[:10]
    try:
        dt = datetime.strptime(candidate, "%Y-%m-%d")
    except ValueError:
        return f"{prefix}{text}" if prefix else text
    rendered = f"{dt.strftime('%B')} {dt.day}, {dt.year}"
    return f"{prefix}{rendered}" if prefix else rendered

def humanize_dates_in_text(value: str) -> str:
    return re.sub(
        r"\b\d{4}-\d{2}-\d{2}\b",
        lambda match: humanized_log_date(match.group(0)),
        value,
    )

def source_file_link(path: Path, label: str) -> str:
    resolved = path.expanduser().resolve()
    return (
        f'<a class="source-link" href="{html_escape(file_href(resolved))}" '
        f'title="{html_escape(str(resolved))}">{html_escape(label)}</a>'
    )

def model_task_cost_label(row: dict[str, Any], catalog_model: dict[str, Any] | None) -> str:
    median_tokens = row.get("median_tokens")
    if median_tokens is None:
        return "in plan"
    if catalog_model is None:
        return "catalog missing"
    if catalog_model.get("free"):
        return "free"
    if catalog_model.get("variable_pricing"):
        return "var"
    return fmt_short_task_cost(estimated_task_cost(row, catalog_model))

def rate_bar_html(value: Any) -> str:
    try:
        pct = max(0.0, min(100.0, float(value) * 100))
    except (TypeError, ValueError):
        pct = 0.0
    return (
        '<span class="rate-meter" aria-hidden="true">'
        f'<span class="rate-bar bar-fill" style="width: {pct:.0f}%"></span>'
        "</span>"
    )

def rate_cell_html(value: Any) -> str:
    return (
        f'<span class="rate-value">{html_escape(fmt_percent(value))}</span>'
        f"{rate_bar_html(value)}"
    )

def compact_context_label(value: Any) -> str:
    try:
        ctx = int(value)
    except (TypeError, ValueError):
        return "unknown ctx"
    if ctx >= 1_000_000 and ctx % 1_000_000 == 0:
        return f"{ctx // 1_000_000}M ctx"
    if ctx >= 1_000:
        if ctx % 1_000 == 0:
            return f"{ctx // 1_000}K ctx"
        return f"{ctx / 1000:.1f}K ctx"
    return f"{ctx} ctx"

def short_model_name(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return "unknown"
    text = text.removeprefix("openrouter/")
    text = text.removesuffix(":free")
    if "/" in text:
        text = text.rsplit("/", 1)[-1]
    text = re.sub(r"[-_]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return "unknown"
    parts = []
    for part in text.split():
        parts.append(part.upper() if part.lower() in {"gpt", "glm", "ai", "llm"} else part.capitalize())
    return " ".join(parts)

def catalog_model_display_name(model: dict[str, Any]) -> str:
    name = str(model.get("name") or "").strip()
    model_id = str(model.get("id") or "").strip()
    if name and name != model_id:
        return name.removesuffix(" (free)").strip()
    return short_model_name(model_id)

def humanized_short_date(value: Any) -> str:
    return re.sub(r",\s*\d{4}$", "", humanized_log_date(value))

def humanized_catalog_event_line(event: dict[str, Any], catalog_by_id: dict[str, dict[str, Any]]) -> str:
    model_id = str(event.get("id") or "")
    if model_id in catalog_by_id:
        label = catalog_model_display_name(catalog_by_id[model_id])
    else:
        label = short_model_name(model_id)
    kind = str(event.get("kind") or "event")
    date = humanized_short_date(event.get("ts"))
    if kind == "went_free":
        action = "went free"
    elif kind == "went_paid":
        action = "went paid"
    elif kind == "pricing_variable":
        action = "moved to variable pricing"
    elif kind == "pricing_fixed":
        action = "returned to fixed pricing"
    elif kind == "added":
        action = "was added"
    elif kind == "removed":
        action = "was removed"
    else:
        action = kind.replace("_", " ")
    return f"{label} {action}: {date}"

def watchlist_chip_html(model: dict[str, Any]) -> str:
    model_id = str(model.get("id") or "").strip()
    label = catalog_model_display_name(model)
    context = compact_context_label(model.get("context_length"))
    title = model_id or label
    return (
        '<li class="watch-chip">'
        f'<span data-model="{html_escape(model_id)}" title="{html_escape(title)}">'
        f"{html_escape(label)} · {html_escape(context)}</span></li>"
    )

def derived_quality_text(row: dict[str, Any], *, best: bool) -> str:
    candidates = [item for item in row.get("task_types", []) if int(item.get("tasks") or 0) >= 2]
    if not candidates:
        return "not enough per-task evidence yet"
    if best:
        chosen = max(candidates, key=lambda item: (float(item.get("first_try_pass_rate") or 0), int(item.get("tasks") or 0), str(item.get("task_type") or "")))
        prefix = "best derived"
    else:
        chosen = min(candidates, key=lambda item: (float(item.get("first_try_pass_rate") or 0), -int(item.get("tasks") or 0), str(item.get("task_type") or "")))
        prefix = "worst derived"
    return (
        f"{prefix}: {chosen['task_type']} "
        f"({fmt_percent(chosen.get('first_try_pass_rate'))} first-try, "
        f"{fmt_percent(chosen.get('pass_rate'))} pass, n={fmt_int(chosen.get('tasks'))})"
    )

def render_task_breakdown_table(task_rows: list[dict[str, Any]]) -> str:
    if not task_rows:
        return '<p class="empty-note">no task-type breakdown</p>'
    rows = []
    for item in task_rows:
        rows.append(
            f"""<tr>
      <td>{html_escape(str(item.get("task_type") or ""))}</td>
      <td class="num">{fmt_int(item.get("tasks"))}</td>
      <td class="num rate-cell">{rate_cell_html(item.get("first_try_pass_rate"))}</td>
      <td class="num rate-cell">{rate_cell_html(item.get("pass_rate"))}</td>
    </tr>"""
        )
    return f"""<table class="breakdown">
    <thead><tr><th>task_type</th><th>n</th><th>first-try</th><th>pass</th></tr></thead>
    <tbody>{"".join(rows)}</tbody>
  </table>"""
