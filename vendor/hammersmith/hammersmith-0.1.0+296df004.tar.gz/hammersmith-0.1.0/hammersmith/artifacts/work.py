"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import base64
import contextlib
import mimetypes
import os
import urllib.parse
from html import escape as html_escape
from pathlib import Path
from typing import Any

from hammersmith.constants import (
    IMAGE_DELIVERABLE_SUFFIXES, TASK_REPORT_FILENAMES, TEXT_DELIVERABLE_SUFFIXES,
)
from hammersmith.utils.activity import shorten

from .briefing import state_tasks, task_state_bucket, task_state_word
from .core import file_href, fmt_compact_duration, is_html_artifact
from .styles import ARTIFACT_BASE_CSS


def task_activity_line(task: dict[str, Any], bucket: str) -> str:
    if bucket not in {"working", "retry"}:
        return ""
    activity = task.get("activity") or task.get("last_action") or task.get("last-action") or ""
    return str(activity).strip()


def render_task_links(
    task: dict[str, Any],
    *,
    state: dict[str, Any],
    renderer: ArtifactRenderer | None = None,
    force_wrappers: bool = False,
    page_path: Path | None = None,
) -> str:
    def portable(href_path: Path) -> str:
        # A page viewed over http cannot follow file:// links; resolve
        # anything inside the artifact store to a relative href instead.
        if renderer is not None:
            with contextlib.suppress(Exception):
                resolved = href_path.resolve()
                if resolved.is_relative_to(renderer.artifact_dir.resolve()):
                    return artifact_relative_href(
                        resolved, page_path=page_path, artifact_root=renderer.artifact_dir
                    )
        return file_href(href_path)

    links: list[str] = []
    taskdir_path: Path | None = None
    taskdir = task.get("taskdir")
    if taskdir:
        taskdir_path = Path(str(taskdir))
    task_key = str(task.get("key", "task"))
    report_paths = task.get("report_paths") or {}
    if not isinstance(report_paths, dict):
        report_paths = {}
    for report_name in TASK_REPORT_FILENAMES:
        report_value = report_paths.get(report_name)
        report_file = Path(str(report_value)) if report_value else None
        if report_file is None and taskdir_path is not None:
            report_file = taskdir_path / report_name
        if report_file is not None and report_file.exists():
            if renderer:
                renderer.link_for_source(
                    report_file, state=state, task_key=task_key, force=force_wrappers
                )
                href = (
                    portable(
                        renderer.wrapper_path(
                            run_id=str(state.get("run_id") or "run"),
                            task_key=task_key,
                            source_name=report_file.name,
                        )
                    )
                    if not is_html_artifact(report_file)
                    else portable(report_file)
                )
            else:
                href = file_href(report_file)
            links.append(f'<a href="{html_escape(href)}">Read what it found</a>')
            break
    log_path = task.get("log_path")
    worker_log = Path(str(log_path)) if log_path else None
    if worker_log is None and taskdir_path is not None:
        worker_log = taskdir_path / "worker.log"
    if worker_log is not None and worker_log.exists():
        if renderer:
            renderer.link_for_source(
                worker_log, state=state, task_key=task_key, force=force_wrappers
            )
            href = portable(
                renderer.wrapper_path(
                    run_id=str(state.get("run_id") or "run"),
                    task_key=task_key,
                    source_name=worker_log.name,
                )
            )
        else:
            href = file_href(worker_log)
        links.append(f'<a href="{html_escape(href)}">view the work log</a>')
    return " &middot; ".join(links) if links else '<span class="muted">-</span>'

def render_work_section(
    state: dict[str, Any],
    *,
    renderer: ArtifactRenderer | None,
    page_path: Path | None,
    force_wrappers: bool = False,
    primary: bool = False,
    finished_only: bool = False,
) -> str:
    # One section carries the whole story: each worker, what it delivered,
    # how the delivery was checked, and where the raw log lives. The old
    # separate "The workers" strip and "What's happening" timeline repeated
    # this information; per-worker live detail belongs to Hammersmith's agent
    # accordion, not the artifact.
    tasks = state_tasks(state)
    if finished_only:
        tasks = [
            task
            for task in tasks
            if task_state_bucket(str(task.get("status", "queued"))) in {"pass", "fail"}
        ]
    section_class = "work is-primary" if primary else "work"
    if not tasks:
        empty_note = "Deliverables appear here as workers finish." if finished_only else "No tasks."
        body = f'<p class="empty-note">{empty_note}</p>'
    else:
        groups = "".join(
            render_work_group(
                task,
                state=state,
                renderer=renderer,
                page_path=page_path,
                force_wrappers=force_wrappers,
            )
            for task in tasks
        )
        body = f'<div class="work-list">{groups}</div>'
    return f"""<section class="{section_class}" aria-labelledby="the-work-heading">
    <h2 id="the-work-heading">The work</h2>
    {body}
  </section>"""

def render_work_group(
    task: dict[str, Any],
    *,
    state: dict[str, Any],
    renderer: ArtifactRenderer | None,
    page_path: Path | None,
    force_wrappers: bool = False,
) -> str:
    task_key = str(task.get("key", "task"))
    key = html_escape(task_key)
    status = str(task.get("status", "queued"))
    bucket = task_state_bucket(status)
    css_bucket = "working" if bucket == "working" else bucket
    state_word = html_escape(task_state_word(status))
    elapsed = html_escape(fmt_compact_duration(task.get("elapsed_s")))

    activity = task_activity_line(task, bucket)
    activity_html = (
        f'<span class="activity" title="{html_escape(activity)}">{html_escape(activity)}</span>'
        if activity
        else ""
    )

    deliverables = [item for item in (task.get("deliverables") or []) if isinstance(item, dict)]
    rows = [
        render_work_item(
            item,
            task_key=task_key,
            state=state,
            renderer=renderer,
            page_path=page_path,
            force_wrappers=force_wrappers,
        )
        for item in deliverables
    ]
    if rows:
        items_html = "".join(rows)
    elif bucket == "pass":
        items_html = '<p class="empty-note">Finished and checked: this worker filed nothing to the shelf.</p>'
    elif bucket == "fail":
        items_html = '<p class="empty-note">Failed its check: nothing was delivered.</p>'
    elif bucket in {"working", "retry"}:
        items_html = '<p class="empty-note">Nothing delivered yet: still on it.</p>'
    else:
        items_html = '<p class="empty-note">Waiting its turn.</p>'

    # Close the trust loop where the results live: say in plain English what
    # the check proved, and keep the raw evidence one click away. The proof
    # stands on its own; a failed task shows why it failed even when no
    # 'verified' sentence was written.
    verified_html = ""
    if bucket in {"pass", "fail"}:
        verified_text = str(task.get("verified") or "").strip()
        proof_tail = str(task.get("check_output_tail") or "").strip()
        if verified_text:
            how_label = "How it was checked" if bucket == "pass" else "What the check demanded"
            verified_html += f'<span class="verified">{how_label}: {html_escape(verified_text)}</span>'
        if proof_tail:
            proof_label = "See the proof" if bucket == "pass" else "See why it failed"
            verified_html += (
                f'<details class="proof"><summary>{proof_label}</summary>'
                f"<pre>{html_escape(shorten(proof_tail, 1200))}</pre></details>"
            )

    links_html = render_task_links(
        task,
        state=state,
        renderer=renderer,
        force_wrappers=force_wrappers,
        page_path=page_path,
    )

    return f"""<div class="work-group">
      <div class="worker">
        <span class="glyph {css_bucket}" aria-hidden="true"></span>
        <span class="name" title="{key}">{key}</span>
        <span class="state {css_bucket}">{state_word}</span>
        <span class="time mono">{elapsed}</span>
        {activity_html}
      </div>
      <div class="work-group-body">
        {items_html}
        {verified_html}
        <span class="links">{links_html}</span>
      </div>
    </div>"""

def render_work_item(
    item: dict[str, Any],
    *,
    task_key: str,
    state: dict[str, Any],
    renderer: ArtifactRenderer | None,
    page_path: Path | None,
    force_wrappers: bool = False,
) -> str:
    name = str(item.get("name", "")).strip() or "work"
    source_path = Path(str(item.get("path", "")))
    label, kind = work_label_and_kind(name)
    href = work_item_href(
        source_path,
        state=state,
        task_key=task_key,
        renderer=renderer,
        page_path=page_path,
        force_wrappers=force_wrappers,
    )
    thumb = ""
    if is_image_deliverable(source_path):
        thumb_src = image_data_uri(source_path)
        if thumb_src:
            thumb = (
                f'<a class="work-thumb-link" href="{html_escape(href)}">'
                f'<img class="work-thumb" src="{html_escape(thumb_src)}" alt=""></a>'
            )
    return f"""<div class="work-item">
      {thumb}
      <div class="work-main">
        <a class="work-link" href="{html_escape(href)}">{html_escape(label)}</a>
        <div class="work-kind">{html_escape(kind)}</div>
      </div>
    </div>"""

def work_item_href(
    source_path: Path,
    *,
    state: dict[str, Any],
    task_key: str,
    renderer: ArtifactRenderer | None,
    page_path: Path | None,
    force_wrappers: bool,
) -> str:
    if renderer is None:
        return "#"
    if is_text_deliverable(source_path) and source_path.exists():
        wrapper_path = renderer.wrapper_path(
            run_id=str(state.get("run_id") or "run"),
            task_key=task_key,
            source_name=source_path.name,
        )
        renderer.write_wrapper(
            source_path,
            wrapper_path,
            run_name=str(state.get("run_name") or "hammersmith"),
            task_key=task_key,
            force=force_wrappers,
        )
        return artifact_relative_href(
            wrapper_path,
            page_path=page_path,
            artifact_root=renderer.artifact_dir,
        )
    return artifact_relative_href(source_path, page_path=page_path, artifact_root=renderer.artifact_dir)

def artifact_relative_href(target: Path, *, page_path: Path | None, artifact_root: Path) -> str:
    try:
        root = artifact_root.resolve()
        resolved_target = target.resolve()
        if resolved_target != root and root not in resolved_target.parents:
            return "#"
        start = (page_path.parent if page_path is not None else artifact_root).resolve()
        rel = os.path.relpath(resolved_target, start)
    except (OSError, ValueError):
        return "#"
    return urllib.parse.quote(Path(rel).as_posix(), safe="/._-~")

def work_label_and_kind(name: str) -> tuple[str, str]:
    path = Path(name)
    stem = path.stem.replace("_", " ").replace("-", " ").strip()
    pretty = stem[:1].upper() + stem[1:] if stem else "Work"
    suffix = path.suffix.lower()
    if suffix in {".html", ".htm"}:
        kind = "web page"
    elif suffix in IMAGE_DELIVERABLE_SUFFIXES:
        kind = "image"
    elif suffix in TEXT_DELIVERABLE_SUFFIXES:
        kind = "document"
    else:
        kind = "download"
    return f"{pretty}: {kind}", kind

def is_text_deliverable(path: Path) -> bool:
    return path.suffix.lower() in TEXT_DELIVERABLE_SUFFIXES

def is_image_deliverable(path: Path) -> bool:
    return path.suffix.lower() in IMAGE_DELIVERABLE_SUFFIXES

def image_data_uri(path: Path) -> str:
    try:
        data = path.read_bytes()
    except OSError:
        return ""
    guessed, _encoding = mimetypes.guess_type(str(path))
    mime = guessed if guessed and guessed.startswith("image/") else "application/octet-stream"
    encoded = base64.b64encode(data).decode("ascii")
    return f"data:{mime};base64,{encoded}"
