"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

from html import escape as html_escape
from pathlib import Path
from typing import Any

from hammersmith.catalog import catalog_changes_path
from hammersmith.catalog_cli import read_catalog_events

from .core import sanitize_artifact_name
from .model_metrics import (
    catalog_model_display_name,
    compact_context_label,
    derived_quality_text,
    fmt_int,
    fmt_percent,
    humanized_catalog_event_line,
    humanized_log_date,
    model_task_cost_label,
    rate_cell_html,
    render_task_breakdown_table,
    source_file_link,
    watchlist_chip_html,
)
from .model_notes import (
    catalog_models_by_id, model_judgment_notes, normalize_catalog_for_scoreboard,
    render_notes_list,
)

def render_free_watchlist(
    catalog_models: list[dict[str, Any]],
    catalog_path: Path,
    *,
    events: list[dict[str, Any]] | None = None,
) -> str:
    normalized = [normalize_catalog_for_scoreboard(model) for model in catalog_models]
    catalog_by_id = catalog_models_by_id(normalized)
    free_models = sorted(
        (model for model in normalized if model.get("free")),
        key=lambda item: (-int(item.get("context_length") or 0), str(item.get("id") or "")),
    )
    if free_models:
        free_items = "".join(
            watchlist_chip_html(model)
            for model in free_models[:6]
        )
    else:
        free_items = '<li class="muted">no free catalog models in the current snapshot</li>'
    if events is None:
        events = read_catalog_events(catalog_changes_path(catalog_path), limit=6)
    event_items = "".join(
        f"<li>{html_escape(humanized_catalog_event_line(event, catalog_by_id))}</li>"
        for event in events[:3]
    )
    if not event_items:
        event_items = '<li class="muted">no catalog change log found</li>'
    return f"""<section class="watchlist" aria-label="free model watchlist">
    <div class="watchline">
      <span class="watch-title">{fmt_int(len(free_models))} models free on OpenRouter right now</span>
      <ul class="watch-chips">{free_items}</ul>
      <ul class="event-list">{event_items}</ul>
    </div>
  </section>"""

def render_model_table_pair(
    row: dict[str, Any],
    *,
    rank: int | None,
    catalog_model: dict[str, Any] | None,
    notes_sections: dict[str, list[str]],
    notes_path: Path,
) -> str:
    model_id = str(row.get("model") or "")
    model_display = str(row.get("model_display") or model_id)
    lab = str(row.get("lab") or "(unknown)")
    harness = str(row.get("harness") or "unknown")
    access = str(row.get("access") or "unknown")
    last_verified = str(row.get("last_verified") or "")
    notes = model_judgment_notes(model_id, notes_sections)
    if row.get("unattributed"):
        model_id_line = (
            f'<div class="model-id">engine: {html_escape(str(row.get("engine") or "unknown"))} '
            '· quarantined legacy data</div>'
        )
    else:
        model_id_line = "" if model_id == model_display else f'<div class="model-id">{html_escape(model_id)}</div>'
    tier = str(row.get("tier") or "")
    tier_display = "not ranked" if row.get("unattributed") else tier
    rank_display = "-" if rank is None else str(rank)
    row_id = (
        str(row.get("bucket_id") or model_id)
        if row.get("show_reasoning_effort") or row.get("unattributed")
        else model_id
    )
    unregistered_flag = (
        '<span class="identity-flag">unregistered</span>' if row.get("unregistered") else ""
    )
    verified_date = (
        f'<span class="verified-date">verified {html_escape(last_verified)}</span>'
        if last_verified
        else ""
    )
    return f"""<tr class="model-row" id="model-{html_escape(sanitize_artifact_name(row_id))}">
      <td class="rank-cell num">{rank_display}</td>
      <td class="model-cell"><div class="model-name">{html_escape(model_display)}</div>{model_id_line}{unregistered_flag}</td>
      <td>{html_escape(lab)}{verified_date}</td>
      <td>{html_escape(harness)}</td>
      <td>{html_escape(access)}</td>
      <td><span class="tier-badge {html_escape(tier)}">{html_escape(tier_display)}</span></td>
      <td class="num">{fmt_int(row.get("tasks"))}</td>
      <td class="num rate-cell">{rate_cell_html(row.get("first_try_pass_rate"))}</td>
      <td class="num rate-cell">{rate_cell_html(row.get("pass_rate"))}</td>
      <td class="num">{html_escape(model_task_cost_label(row, catalog_model))}</td>
      <td>{html_escape(humanized_log_date(row.get("last_seen")))}</td>
    </tr>
    <tr class="detail-row">
      <td colspan="11">
        <details class="model-detail">
          <summary>details for {html_escape(model_display)}</summary>
          <div class="detail-content">
            <div>
              <h3 class="detail-heading">Task types</h3>
              {render_task_breakdown_table(row.get("task_types", []))}
              <div class="quality-lines">
                <div><b>Best:</b> {html_escape(derived_quality_text(row, best=True))}</div>
                <div><b>Worst:</b> {html_escape(derived_quality_text(row, best=False))}</div>
              </div>
            </div>
            <div class="notes-panel">
              <h3 class="detail-heading">Judgment notes</h3>
              {render_notes_list(notes, notes_path=notes_path)}
            </div>
          </div>
        </details>
      </td>
    </tr>"""
