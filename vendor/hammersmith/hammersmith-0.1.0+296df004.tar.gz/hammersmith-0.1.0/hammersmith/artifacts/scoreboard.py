"""Standalone local model-scoreboard artifact."""
from __future__ import annotations

from datetime import datetime
from html import escape as html_escape
from pathlib import Path
from typing import Any

from hammersmith.config import AppConfig
from hammersmith.constants import (
    CSP_META_TAG, MODEL_SCOREBOARD_IDENTITY, MODEL_SCOREBOARD_RUN_NAME,
)

from hammersmith.utils.io import atomic_write_text

from .library import artifact_live_path, update_artifact_library_live
from .model_metrics import fmt_int, humanized_log_date, order_model_scoreboard_rows, source_file_link
from .model_notes import catalog_models_by_id
from .scoreboard_components import render_free_watchlist, render_model_table_pair
from .scoreboard_styles import MODEL_SCOREBOARD_CSS
from .styles import ARTIFACT_BASE_CSS

def render_model_scoreboard_html(
    *,
    rows: list[dict[str, Any]],
    log_path: Path,
    rows_read: int,
    skipped: int,
    catalog_path: Path,
    catalog_models: list[dict[str, Any]],
    notes_path: Path,
    notes_sections: dict[str, list[str]],
    catalog_events: list[dict[str, Any]] | None = None,
    generated_at: str | None = None,
) -> str:
    catalog_by_id = catalog_models_by_id(catalog_models)
    ordered = order_model_scoreboard_rows(rows, catalog_by_id)
    generated = generated_at or datetime.now().astimezone().replace(microsecond=0).isoformat()
    rendered_rows: list[str] = []
    rank = 0
    for row in ordered:
        row_rank = None
        if not row.get("unattributed"):
            rank += 1
            row_rank = rank
        rendered_rows.append(
            render_model_table_pair(
                row,
                rank=row_rank,
                catalog_model=catalog_by_id.get(str(row.get("model") or "")),
                notes_sections=notes_sections,
                notes_path=notes_path,
            )
        )
    table_rows = "".join(rendered_rows)
    if not table_rows:
        table_rows = '<tr><td colspan="11" class="muted">No local model evidence matched these filters.</td></tr>'
    unregistered_slugs = sorted(
        {str(row.get("model") or "") for row in ordered if row.get("unregistered") and row.get("model")}
    )
    unregistered_pointer = ""
    if unregistered_slugs:
        pointer = (
            f"Unregistered model slug(s): {', '.join(unregistered_slugs)}"
            "; run the identity procedure in docs/TAXONOMY.md."
        )
        unregistered_pointer = f'<div class="identity-pointer">{html_escape(pointer)}</div>'
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
{CSP_META_TAG}
<title>Models &middot; Hammersmith</title>
<style>{ARTIFACT_BASE_CSS}
{MODEL_SCOREBOARD_CSS}</style>
</head>
<body>
<div class="page scoreboard-page">
  <header class="scoreboard-header">
    <h1 class="scoreboard-title">Model performance scoreboard</h1>
    <div class="scoreboard-meta">
      <span>Generated {html_escape(humanized_log_date(generated))}</span>
      <nav class="source-links" aria-label="scoreboard source files">
        {source_file_link(log_path, "eval log")}
        {source_file_link(catalog_path, "catalog")}
        {source_file_link(notes_path, "model notes")}
      </nav>
    </div>
  </header>
  {render_free_watchlist(catalog_models, catalog_path, events=catalog_events)}
  <main>
    <div class="table-scroll" role="region" aria-label="Model evidence table" tabindex="0">
      <table class="ranked-table">
        <thead>
          <tr>
            <th>Rank</th>
            <th>Model</th>
            <th>Lab</th>
            <th>Harness</th>
            <th>API/Plan</th>
            <th>Tier</th>
            <th class="num">Tasks</th>
            <th class="num">First-try</th>
            <th class="num">Pass</th>
            <th class="num">Est. $/task</th>
            <th>Last used</th>
          </tr>
        </thead>
        <tbody>{table_rows}</tbody>
      </table>
    </div>
  </main>
  <footer class="scoreboard-footer">
    <span>{fmt_int(rows_read)} rows read, {fmt_int(skipped)} skipped lines. Ranking sorts by evidence tier first: proven n&gt;=3, then probation; ties use first-try pass rate, pass rate, then lower estimated cost. Unattributed legacy rows are quarantined at the bottom and are not ranked or tiered. Cost estimate assumes logged worker_tokens are split 50/50 between prompt and completion tokens, using the catalog $/M in/out blend.</span>
    {unregistered_pointer}
  </footer>
</div>
</body>
</html>
"""

def write_model_scoreboard_html(
    config: AppConfig,
    *,
    path: Path | None,
    rows: list[dict[str, Any]],
    log_path: Path,
    rows_read: int,
    skipped: int,
    catalog_path: Path,
    catalog_models: list[dict[str, Any]],
    notes_path: Path,
    notes_sections: dict[str, list[str]],
    catalog_events: list[dict[str, Any]] | None = None,
) -> Path:
    target = path
    if target is None:
        target = artifact_live_path(config.state_dir, MODEL_SCOREBOARD_RUN_NAME)
    target = target.expanduser().resolve()
    html = render_model_scoreboard_html(
        rows=rows,
        log_path=log_path,
        rows_read=rows_read,
        skipped=skipped,
        catalog_path=catalog_path,
        catalog_models=catalog_models,
        catalog_events=catalog_events,
        notes_path=notes_path,
        notes_sections=notes_sections,
    )
    atomic_write_text(target, html)
    if path is None:
        update_artifact_library_live(
            config.state_dir,
            run_name=MODEL_SCOREBOARD_RUN_NAME,
            run_id=MODEL_SCOREBOARD_RUN_NAME,
            identity=MODEL_SCOREBOARD_IDENTITY,
            state="pass",
        )
    return target
