"""Local behavior asset for live artifact pages."""
from __future__ import annotations

from pathlib import Path

from hammersmith.constants import CSP_META_TAG
from hammersmith.utils.io import atomic_write_text


ARTIFACT_REFRESH_ASSET_NAME = "artifact-refresh.js"
ARTIFACT_REFRESH_CSP = CSP_META_TAG.replace(
    "img-src data:", "img-src data:; script-src 'self'"
)
ARTIFACT_REFRESH_JAVASCRIPT = r'''"use strict";

(() => {
  const ROOT_SELECTOR = ".page, .wrap";
  const FOCUSABLE_SELECTOR = "a, button, summary, [tabindex]";
  const SCROLL_SELECTOR = ".table-scroll, [data-preserve-scroll]";
  let paused = false;
  let timer = null;

  function updateStatus(message) {
    const status = document.getElementById("artifact-update-status");
    if (status) status.textContent = message;
  }

  function keyedElements(root, selector, prefix) {
    return [...root.querySelectorAll(selector)].map((element, index) => ({
      element,
      key: element.id || `${prefix}-${index}`,
    }));
  }

  function capturePageState(root) {
    const active = document.activeElement;
    const focusables = [...root.querySelectorAll(FOCUSABLE_SELECTOR)];
    return {
      scrollX: window.scrollX,
      scrollY: window.scrollY,
      focusId: active && active.id ? active.id : "",
      focusIndex: focusables.indexOf(active),
      disclosures: keyedElements(root, "details", "details")
        .filter(({element}) => element.open)
        .map(({key}) => key),
      scrollRegions: keyedElements(root, SCROLL_SELECTOR, "scroll-region").map(
        ({element, key}) => ({key, top: element.scrollTop, left: element.scrollLeft})
      ),
    };
  }

  function restorePageState(root, state) {
    const open = new Set(state.disclosures);
    keyedElements(root, "details", "details").forEach(({element, key}) => {
      element.open = open.has(key);
    });
    const regions = new Map(state.scrollRegions.map((region) => [region.key, region]));
    keyedElements(root, SCROLL_SELECTOR, "scroll-region").forEach(({element, key}) => {
      const saved = regions.get(key);
      if (saved) {
        element.scrollTop = saved.top;
        element.scrollLeft = saved.left;
      }
    });
    window.scrollTo({left: state.scrollX, top: state.scrollY});
    const focusables = [...root.querySelectorAll(FOCUSABLE_SELECTOR)];
    const focusTarget = state.focusId
      ? document.getElementById(state.focusId)
      : focusables[state.focusIndex];
    if (focusTarget) focusTarget.focus({preventScroll: true});
  }

  function bindPauseControl() {
    const pause = document.getElementById("pause-artifact-updates");
    if (!pause) return;
    pause.setAttribute("aria-pressed", String(paused));
    pause.textContent = paused ? "Resume updates" : "Pause updates";
    if (pause.dataset.refreshBound === "true") return;
    pause.dataset.refreshBound = "true";
    pause.addEventListener("click", () => {
      paused = !paused;
      bindPauseControl();
      updateStatus(paused ? "Updates paused." : "Updates resumed.");
      if (!paused) refresh();
    });
  }

  async function refresh() {
    if (paused || document.hidden) return;
    try {
      const response = await fetch(location.href, {cache: "no-store"});
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const next = new DOMParser().parseFromString(await response.text(), "text/html");
      const incoming = next.querySelector(ROOT_SELECTOR);
      const current = document.querySelector(ROOT_SELECTOR);
      if (!incoming || !current) throw new Error("page structure unavailable");
      const state = capturePageState(current);
      const replacement = incoming.cloneNode(true);
      current.replaceChildren(...replacement.childNodes);
      bindPauseControl();
      restorePageState(current, state);
      updateStatus("Updated without moving focus, disclosures, or scroll.");
    } catch (_error) {
      updateStatus("Update unavailable; showing last-known content.");
    }
  }

  bindPauseControl();
  timer = window.setInterval(refresh, 2000);
  window.addEventListener("pagehide", () => window.clearInterval(timer), {once: true});
})();
'''


def write_artifact_refresh_asset(page_path: Path) -> Path:
    """Write the stable local refresh asset beside a generated live page."""
    target = page_path.parent / ARTIFACT_REFRESH_ASSET_NAME
    try:
        if target.read_text(encoding="utf-8") == ARTIFACT_REFRESH_JAVASCRIPT:
            return target
    except (FileNotFoundError, OSError, UnicodeDecodeError):
        pass
    atomic_write_text(target, ARTIFACT_REFRESH_JAVASCRIPT)
    return target
