"""Forge components for standalone artifacts."""

ARTIFACT_BASE_CSS_COMPONENTS = """    font-size: 11px;
  }
  details.timeline[open] > summary h2::after { content: " ▾"; }
  details.timeline > summary:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }
  .tl-row {
    display: grid;
    grid-template-columns: 76px minmax(0,1fr);
    gap: 14px;
    padding: 10px 0;
    border-bottom: 1px solid var(--hairline);
    font-size: 14px;
  }
  .tl-row time {
    color: var(--muted);
    font-size: 12px;
    padding-top: 2px;
  }
  .tl-row .catch {
    margin: 6px 0 0;
    padding: 8px 12px;
    background: var(--quote-bg);
    border-left: 2px solid var(--fail);
    border-radius: 0 6px 6px 0;
    color: var(--muted);
    font-size: 13px;
    overflow-wrap: break-word;
  }
  .tl-row .catch b {
    color: var(--fail);
    font-weight: 650;
  }
  .workers {
    margin-bottom: clamp(28px, 5vw, 44px);
  }
  .worker {
    display: grid;
    grid-template-columns: 18px minmax(0,1fr) auto auto;
    gap: 4px 12px;
    align-items: baseline;
    padding: 12px 0;
    border-bottom: 1px solid var(--hairline);
  }
  .glyph {
    width: 11px;
    height: 11px;
    border-radius: 50%;
    align-self: center;
  }
  .glyph.pass { background: var(--pass); }
  .glyph.working { background: var(--accent); }
  .glyph.retry, .glyph.fail { background: var(--fail); }
  .glyph.waiting {
    background: transparent;
    border: 1.5px solid var(--waiting);
  }
  @media (prefers-reduced-motion: no-preference) {
    .glyph.working, .glyph.retry { animation: pulse 1.4s ease-in-out infinite; }
  }
  .worker .name {
    min-width: 0;
    overflow: hidden;
    font-size: 15px;
    font-weight: 650;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .worker .state {
    font-size: 13px;
    font-weight: 650;
    white-space: nowrap;
  }
  .state.pass { color: var(--pass); }
  .state.working { color: var(--accent); }
  .state.retry, .state.fail { color: var(--fail); }
  .state.waiting { color: var(--waiting); }
  .worker .time {
    color: var(--muted);
    font-size: 12.5px;
    white-space: nowrap;
  }
  .worker .activity {
    grid-column: 2 / -1;
    min-width: 0;
    overflow: hidden;
    color: var(--muted);
    font-size: 13px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .worker .verified {
    grid-column: 2 / -1;
    min-width: 0;
    color: var(--muted);
    font-size: 13px;
    overflow-wrap: break-word;
  }
  .worker .proof {
    grid-column: 2 / -1;
    min-width: 0;
    font-size: 12px;
  }
  .worker .proof summary {
    cursor: pointer;
    color: var(--accent);
  }
  .worker .proof pre {
    margin: 6px 0 0;
    padding: 10px 12px;
    max-height: 200px;
    overflow: auto;
    border-left: 2px solid var(--hairline);
    background: var(--surface);
    color: var(--muted);
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 11.5px;
    line-height: 1.55;
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }
  .worker .links {
    grid-column: 2 / -1;
    font-size: 13px;
  }
  .worker .links a {
    color: var(--accent);
    text-decoration: none;
  }
  .worker .links a:hover,
  .worker .links a:focus-visible {
    text-decoration: underline;
  }
  .runs {
    list-style: none;
    margin: 0;
    padding: 0;
  }
  .omitted-note,
  .empty-note {
    max-width: 65ch;
    margin: 8px 0 0;
    color: var(--muted);
    font-size: 13px;
    line-height: 1.45;
  }
  .run-row {
    display: grid;
    gap: 16px;
    align-items: center;
    padding: 12px 0;
    border-top: 1px solid var(--hairline);
  }
  .run-row {
    grid-template-columns: minmax(0, 1.35fr) minmax(112px, .55fr) minmax(76px, .4fr) minmax(150px, .8fr);
  }
  .run-name {
    min-width: 0;
    overflow: hidden;
    color: var(--ink);
    font-weight: 700;
    line-height: 1.35;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .run-state {
    color: var(--state-color);
    font-weight: 800;
  }
  .run-duration {
    color: var(--muted);
  }
  .run-links {
    display: flex;
    min-width: 0;
    flex-wrap: wrap;
    gap: 8px 14px;
  }
  .run-links .muted {
    color: var(--muted);
  }
  .state-pass { --state-color: var(--pass); }
  .state-fail { --state-color: var(--fail); }
  .state-running { --state-color: var(--accent); }
  .state-waiting { --state-color: var(--waiting); }
  .meta {
    max-width: 65ch;
    margin: 0 0 18px;
    color: var(--muted);
    font-size: 13px;
    line-height: 1.55;
  }
  .meta b { color: var(--ink); }
  .mono,
  time {
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-variant-numeric: tabular-nums;
  }
  .muted { color: var(--muted); }
  table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
  th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid var(--hairline); vertical-align: top; }
  th { color: var(--muted); font-weight: 700; font-size: 10px; letter-spacing: 0; }
  .chip { display: inline-block; padding: 2px 8px; border-radius: 6px; font-size: 10px; font-weight: 800; color: var(--ground); white-space: nowrap; }
  pre {
    width: 100%;
    max-width: 100%;
    margin: 0;
    overflow: auto;
    border: 1px solid var(--hairline);
    border-radius: 6px;
    background: var(--surface);
    color: var(--ink);
    padding: clamp(14px,3vw,24px);
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 12px;
    font-variant-numeric: tabular-nums;
    line-height: 1.65;
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }
  footer,
  .page-foot {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    color: var(--muted);
    font-size: 12px;
    line-height: 1.5;
  }
  a { color: var(--accent); text-decoration: none; }
  a:hover { text-decoration: underline; }
  @media (max-width: 1200px) {
    .page { width: 100%; }
  }
  @media (max-width: 768px) {
    .table-scroll { max-width: 100%; overflow-x: auto; overscroll-behavior-inline: contain; }
  }
  @media (max-width: 640px) {
    .worker,
    .run-row {
      grid-template-columns: minmax(0, 1fr);
      gap: 6px;
    }
    .glyph {
      display: none;
    }
    .worker .activity,
    .worker .links {
      grid-column: 1 / -1;
    }
    .work-item,
    .work.is-primary .work-item {
      align-items: flex-start;
      padding: 12px 0;
      border-width: 0 0 1px;
      border-radius: 0;
      background: transparent;
    }
    .work-thumb {
      max-width: 96px;
      max-height: 72px;
    }
    .run-links {
      gap: 6px 12px;
    }
  }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { animation: none !important; transition: none !important; }
  }
"""
