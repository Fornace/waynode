"""Standalone live, final, and index artifact pages."""
from __future__ import annotations

from html import escape as html_escape
from pathlib import Path
from typing import Any

from hammersmith.constants import CSP_META_TAG

from .briefing import (
    final_briefing_html, live_briefing_html, local_time_label,
    render_progress_bar, state_tasks, task_status_counts,
)
from .core import (
    STATUS_COLORS, file_href, fmt_compact_duration, fmt_duration, status_color,
)
from .styles import ARTIFACT_BASE_CSS
from .work import render_task_links, render_work_section, task_activity_line
from .refresh import (
    ARTIFACT_REFRESH_ASSET_NAME,
    ARTIFACT_REFRESH_CSP,
    write_artifact_refresh_asset,
)


def _refresh_asset_href(renderer: Any, page_path: Path | None, fallback_name: str) -> str:
    if renderer is None:
        return ARTIFACT_REFRESH_ASSET_NAME
    target_page = page_path or (renderer.artifact_dir / fallback_name)
    write_artifact_refresh_asset(target_page)
    return ARTIFACT_REFRESH_ASSET_NAME

def render_corner_header(state: dict[str, Any], *, live: bool) -> str:
    run_name = html_escape(str(state.get("run_name", "hammersmith")))
    identity = html_escape(str(state.get("identity", "unknown")))
    elapsed = html_escape(fmt_compact_duration(state.get("elapsed_s")))
    dot_class = "live-dot is-live" if live else f"live-dot {final_dot_bucket(state)}"
    clock_label = f"{elapsed} elapsed" if live else f"{elapsed} total"
    return f"""<header class="corner">
    <span class="{dot_class}" aria-hidden="true"></span>
    <span class="eyebrow">Hammersmith &nbsp;·&nbsp; <b>{run_name}</b> &nbsp;·&nbsp; {identity}</span>
    <span class="clock mono">{clock_label}</span>
  </header>"""

def final_dot_bucket(state: dict[str, Any]) -> str:
    counts = task_status_counts(state)
    if counts["fail"]:
        return "fail"
    if counts["pass"]:
        return "pass"
    return "waiting"

def render_status_html(
    state: dict[str, Any],
    renderer: ArtifactRenderer | None = None,
    *,
    force_wrappers: bool = False,
    page_path: Path | None = None,
) -> str:
    """Tier 0 zero-LLM live status artifact. Rendered on every state flush (~1s)."""
    run_name = html_escape(str(state.get("run_name", "hammersmith")))
    tasks = state_tasks(state)
    counts = task_status_counts(state)
    briefing = live_briefing_html(state)
    refresh_asset = _refresh_asset_href(renderer, page_path, "artifact.html")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
{ARTIFACT_REFRESH_CSP}
<title>{run_name} &middot; Hammersmith</title>
<style>{ARTIFACT_BASE_CSS}</style>
</head>
<body>
<div class="page">
  {render_corner_header(state, live=True)}
  <h1 id="right-now-heading" class="briefing">{briefing}</h1>
  {render_progress_bar(tasks, counts)}
  {render_work_section(state, renderer=renderer, page_path=page_path, force_wrappers=force_wrappers, finished_only=True)}
  <footer>
    <span class="mono">Updated {html_escape(local_time_label())}</span>
    <button id="pause-artifact-updates" type="button" aria-pressed="false">Pause updates</button>
    <span id="artifact-update-status">Updates preserve focus, disclosures, and scroll.</span>
  </footer>
</div>
<script src="{html_escape(refresh_asset)}" defer></script>
</body>
</html>
"""

def render_final_report_html(
    state: dict[str, Any],
    renderer: ArtifactRenderer | None = None,
    *,
    force_wrappers: bool = True,
    page_path: Path | None = None,
) -> str:
    """Feature 4: self-contained final report, rendered once when a run finishes."""
    run_name = html_escape(str(state.get("run_name", "hammersmith")))
    tasks = state_tasks(state)
    counts = task_status_counts(state)
    briefing = final_briefing_html(state)

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
{CSP_META_TAG}
<title>{run_name} report &middot; Hammersmith</title>
<style>{ARTIFACT_BASE_CSS}</style>
</head>
<body>
<div class="page">
  {render_corner_header(state, live=False)}
  <h1 id="what-happened-heading" class="briefing">What happened: {briefing}</h1>
  {render_progress_bar(tasks, counts)}
  {render_work_section(state, renderer=renderer, page_path=page_path, force_wrappers=force_wrappers, primary=True)}
  <footer>
    <span class="mono">Finished {html_escape(local_time_label())}</span>
  </footer>
</div>
</body>
</html>
"""

def render_artifact_index_html(
    entries: list[dict[str, Any]],
    renderer: ArtifactRenderer | None = None,
    *,
    force_wrappers: bool = False,
    page_path: Path | None = None,
) -> str:
    """Multi-run index: one pane of glass across every run under this state_dir."""
    rows = []
    for entry in entries:
        state_label = str(entry.get("state", "live"))
        fail_n = entry.get("fail", 0) or 0
        color = status_color(state_label if state_label in STATUS_COLORS else ("fail" if fail_n else "pass"))
        run_name = html_escape(str(entry.get("run_name", "hammersmith")))
        identity = html_escape(str(entry.get("identity", "unknown")))
        elapsed = fmt_duration(entry.get("elapsed_s"))
        pass_n = entry.get("pass", 0)
        links: list[str] = []
        artifact_path = entry.get("artifact_path")
        if artifact_path:
            links.append(f'<a href="{html_escape(file_href(Path(str(artifact_path))))}">live</a>')
        if entry.get("report_ready") and entry.get("report_path"):
            report_path = Path(str(entry["report_path"]))
            href = (
                renderer.link_for_source(
                    report_path,
                    run_id=str(entry.get("run_id") or "run"),
                    run_name=str(entry.get("run_name") or "hammersmith"),
                    task_key="run",
                    force=force_wrappers,
                )
                if renderer
                else file_href(report_path)
            )
            links.append(f'<a href="{html_escape(href)}">report</a>')
        links_html = " &middot; ".join(links) if links else '<span class="muted">-</span>'
        rows.append(
            f"""<tr>
          <td><span class="chip" style="background:{color}">{html_escape(state_label)}</span></td>
          <td class="mono">{run_name}</td>
          <td class="mono">{identity}</td>
          <td class="mono">{pass_n} pass / {fail_n} fail</td>
          <td class="mono">{elapsed}</td>
          <td class="mono">{links_html}</td>
        </tr>"""
        )
    body = "".join(rows) if rows else '<tr><td colspan="6" class="muted">no runs recorded yet</td></tr>'
    refresh_asset = _refresh_asset_href(renderer, page_path, "index.html")
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
{ARTIFACT_REFRESH_CSP}
<title>All runs &middot; Hammersmith</title>
<style>{ARTIFACT_BASE_CSS}</style>
</head>
<body>
<div class="wrap">
  <h1>All runs</h1>
  <p class="meta">Recorded runs from this local state directory.</p>
  <p><button id="pause-artifact-updates" type="button" aria-pressed="false">Pause updates</button> <span id="artifact-update-status">Updates preserve focus and scroll.</span></p>
  <div class="table-scroll" role="region" aria-label="Run evidence table" tabindex="0"><table>
    <thead><tr><th>State</th><th>Run</th><th>Identity</th><th>Result</th><th>Elapsed</th><th>Artifacts</th></tr></thead>
    <tbody>{body}</tbody>
  </table></div>
</div>
<script src="{html_escape(refresh_asset)}" defer></script>
</body>
</html>
"""
