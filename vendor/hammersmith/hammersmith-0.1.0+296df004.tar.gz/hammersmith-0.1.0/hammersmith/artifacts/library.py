"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import contextlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from hammersmith.active_runs import read_active_runs
from hammersmith.constants import ARTIFACT_LIBRARY_MAX_VERSIONS
from hammersmith.identity import (
    UNGROUPED_PROJECT_ID, project_identity, project_selection_key,
)

from hammersmith.utils.io import atomic_write_json, interprocess_lock

from .core import sanitize_artifact_name

def artifacts_dir(state_dir: Path) -> Path:
    return state_dir / "artifacts"

def artifact_library_path(state_dir: Path) -> Path:
    return artifacts_dir(state_dir) / "library.json"

def artifact_live_path(
    state_dir: Path, run_name: str, *, project_id: str = UNGROUPED_PROJECT_ID
) -> Path:
    live_root = artifacts_dir(state_dir) / "live"
    if project_id != UNGROUPED_PROJECT_ID:
        live_root = live_root / sanitize_artifact_name(project_id)
    return live_root / f"{sanitize_artifact_name(run_name)}.html"

def artifact_version_path(
    state_dir: Path,
    run_name: str,
    run_id: str,
    *,
    project_id: str = UNGROUPED_PROJECT_ID,
) -> Path:
    version_root = artifacts_dir(state_dir) / "versions"
    if project_id != UNGROUPED_PROJECT_ID:
        version_root = version_root / sanitize_artifact_name(project_id)
    return (
        version_root
        / sanitize_artifact_name(run_name)
        / f"{sanitize_artifact_name(run_id)}.html"
    )

def artifact_deliverables_dir(state_dir: Path, run_id: str, task_key: str) -> Path:
    return (
        artifacts_dir(state_dir)
        / "deliverables"
        / sanitize_artifact_name(run_id)
        / sanitize_artifact_name(task_key)
    )

def read_artifact_library(state_dir: Path) -> dict[str, Any]:
    path = artifact_library_path(state_dir)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, json.JSONDecodeError, UnicodeDecodeError):
        return {"artifacts": {}}
    if not isinstance(data, dict):
        return {"artifacts": {}}
    artifacts = data.get("artifacts")
    if not isinstance(artifacts, dict):
        return {"artifacts": {}}
    clean: dict[str, Any] = {"artifacts": {}}
    for run_name, entry in artifacts.items():
        if isinstance(run_name, str) and isinstance(entry, dict):
            clean["artifacts"][run_name] = entry
    return clean

def write_artifact_library(state_dir: Path, library: dict[str, Any]) -> None:
    atomic_write_json(artifact_library_path(state_dir), library)

def artifact_library_lock_path(state_dir: Path) -> Path:
    return artifacts_dir(state_dir) / ".library.lock"

def artifact_library_key(run_name: str, project_id: str) -> str:
    # Keep the historical key for old/ungrouped campaigns. Explicit projects
    # get a collision-safe namespace while the display name stays in the entry.
    if project_id == UNGROUPED_PROJECT_ID:
        return run_name
    return f"{project_id}::{run_name}"

def artifact_outcome_from_state(state: dict[str, Any]) -> str:
    if str(state.get("state", "")) == "died":
        return "died"
    if not bool(state.get("finished")) and str(state.get("state", "live")) == "live":
        return "live"
    totals = state.get("totals") if isinstance(state.get("totals"), dict) else {}
    fail_n = int(totals.get("fail", state.get("fail", 0)) or 0)
    return "fail" if fail_n else "pass"

def _library_entry(
    *,
    state_dir: Path,
    run_name: str,
    run_id: str,
    identity: str,
    state: str,
    now_iso: str,
    project: str = "",
    existing: dict[str, Any] | None = None,
) -> dict[str, Any]:
    project_id, project_label = project_identity(project)
    versions = []
    if existing and isinstance(existing.get("versions"), list):
        versions = [item for item in existing["versions"] if isinstance(item, dict)]
    return {
        "run_name": run_name,
        "project": project,
        "project_id": project_id,
        "project_label": project_label,
        "selection_key": project_selection_key(project_id, run_id),
        "live_path": str(
            artifact_live_path(state_dir, run_name, project_id=project_id)
        ),
        "state": state,
        "identity": identity,
        "current_run_id": run_id,
        "updated_at": now_iso,
        "versions": versions,
    }

def update_artifact_library_live(
    state_dir: Path,
    *,
    run_name: str,
    run_id: str,
    identity: str,
    state: str,
    project: str = "",
    now: datetime | None = None,
) -> None:
    now_iso = (now or datetime.now(timezone.utc)).isoformat()
    project_id, _project_label = project_identity(project)
    key = artifact_library_key(run_name, project_id)
    with interprocess_lock(artifact_library_lock_path(state_dir)):
        library = read_artifact_library(state_dir)
        artifacts = library.setdefault("artifacts", {})
        existing = artifacts.get(key) if isinstance(artifacts.get(key), dict) else None
        artifacts[key] = _library_entry(
            state_dir=state_dir,
            run_name=run_name,
            run_id=run_id,
            identity=identity,
            state=state,
            now_iso=now_iso,
            project=project,
            existing=existing,
        )
        write_artifact_library(state_dir, library)

def append_artifact_library_version(
    state_dir: Path,
    *,
    run_name: str,
    run_id: str,
    identity: str,
    outcome: str,
    project: str = "",
    version_path: Path,
    report_path: Path | None,
    tasks_pass: int,
    tasks_fail: int,
    deliverables: list[dict[str, Any]] | None = None,
    now: datetime | None = None,
) -> None:
    now_iso = (now or datetime.now(timezone.utc)).isoformat()
    project_id, _project_label = project_identity(project)
    key = artifact_library_key(run_name, project_id)
    new_version = {
        "run_id": run_id,
        "path": str(version_path),
        "report_path": str(report_path) if report_path is not None else None,
        "finished_at": now_iso,
        "outcome": outcome,
        "tasks_pass": tasks_pass,
        "tasks_fail": tasks_fail,
        "deliverables": [dict(item) for item in deliverables or []],
    }
    with interprocess_lock(artifact_library_lock_path(state_dir)):
        library = read_artifact_library(state_dir)
        artifacts = library.setdefault("artifacts", {})
        existing = artifacts.get(key) if isinstance(artifacts.get(key), dict) else None
        entry = _library_entry(
            state_dir=state_dir,
            run_name=run_name,
            run_id=run_id,
            identity=identity,
            state=outcome,
            now_iso=now_iso,
            project=project,
            existing=existing,
        )
        versions = [new_version]
        for version in entry["versions"]:
            if version.get("run_id") != run_id:
                versions.append(version)
        entry["versions"] = versions[:ARTIFACT_LIBRARY_MAX_VERSIONS]
        artifacts[key] = entry
        write_artifact_library(state_dir, library)
    prune_artifact_versions(state_dir, versions[ARTIFACT_LIBRARY_MAX_VERSIONS:])

def prune_artifact_versions(state_dir: Path, versions: list[dict[str, Any]]) -> None:
    root = artifacts_dir(state_dir).resolve()
    for version in versions:
        for key in ("path", "report_path"):
            raw = version.get(key)
            if not raw:
                continue
            path = Path(str(raw)).expanduser()
            with contextlib.suppress(OSError):
                resolved = path.resolve()
                if resolved == root or root not in resolved.parents:
                    continue
                if resolved.is_file():
                    resolved.unlink()
                    with contextlib.suppress(OSError):
                        resolved.parent.rmdir()

def reconcile_artifact_library_dead_runs(state_dir: Path) -> None:
    active = read_active_runs()
    with interprocess_lock(artifact_library_lock_path(state_dir)):
        library = read_artifact_library(state_dir)
        artifacts = library.get("artifacts", {})
        if not isinstance(artifacts, dict):
            return
        changed = False
        now_iso = datetime.now(timezone.utc).isoformat()
        for entry in artifacts.values():
            if not isinstance(entry, dict) or entry.get("state") != "live":
                continue
            run_id = str(entry.get("current_run_id", ""))
            if not run_id or run_id not in active:
                entry["state"] = "died"
                entry["updated_at"] = now_iso
                changed = True
        if changed:
            write_artifact_library(state_dir, library)

def scan_run_states(state_dir: Path) -> list[dict[str, Any]]:
    """Best-effort scan of every run state file, for the multi-run index artifact."""
    runs_dir = state_dir / "runs"
    entries: list[dict[str, Any]] = []
    try:
        paths = list(runs_dir.glob("*.json"))
    except OSError:
        return entries
    for path in paths:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(data, dict):
            continue
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
        entries.append(
            {
                "run_id": data.get("run_id", path.stem),
                "run_name": data.get("run_name", "hammersmith"),
                "identity": data.get("identity", "unknown"),
                "state": data.get("state", "finished" if data.get("finished") else "live"),
                "pass": data.get("pass", 0),
                "fail": data.get("fail", 0),
                "elapsed_s": data.get("elapsed_s", 0),
                "started_at": data.get("started_at", ""),
                "artifact_path": data.get("artifact_path"),
                "report_path": data.get("report_path"),
                "report_ready": data.get("report_ready", False),
                "mtime": mtime,
            }
        )
    entries.sort(key=lambda item: item["mtime"], reverse=True)
    return entries
