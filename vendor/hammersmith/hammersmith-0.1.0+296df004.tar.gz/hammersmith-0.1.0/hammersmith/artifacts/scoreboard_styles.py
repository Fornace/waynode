"""Stylesheet for model-scoreboard artifacts."""

MODEL_SCOREBOARD_CSS = """
  .scoreboard-page { max-width: 1240px; }
  .scoreboard-header {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 18px;
    align-items: end;
    margin-bottom: clamp(14px, 2.5vw, 22px);
  }
  .scoreboard-title {
    margin: 0;
    font-size: clamp(28px, 5vw, 54px);
    line-height: .98;
    letter-spacing: 0;
    text-wrap: balance;
  }
  .scoreboard-meta {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 12px;
    flex-wrap: wrap;
    color: var(--muted);
    font-size: 12px;
  }
  .source-links {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }
  .source-link {
    color: var(--ink);
    text-decoration: none;
    border-bottom: 1px solid var(--hairline);
  }
  .source-link:hover { border-bottom-color: var(--ink); }
  .watchlist {
    border-top: 1px solid var(--hairline);
    border-bottom: 1px solid var(--hairline);
    padding: 12px 0;
    margin: 0 0 clamp(18px, 3vw, 28px);
    color: var(--muted);
    font-size: 13px;
  }
  .watchline {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  }
  .watch-title { color: var(--ink); font-weight: 650; }
  .watch-chips, .event-list {
    display: contents;
    margin: 0;
    padding: 0;
    list-style: none;
  }
  .watch-chip {
    border: 1px solid var(--hairline);
    padding: 3px 7px 4px;
    font-size: 12px;
    color: var(--ink);
    background: rgba(255, 255, 255, .03);
  }
  .event-list li {
    color: var(--muted);
  }
  .event-list li::before {
    content: "/";
    color: var(--hairline);
    margin: 0 8px 0 2px;
  }
  .table-scroll {
    overflow-x: auto;
    border: 1px solid var(--hairline);
    border-left: 0;
    border-right: 0;
  }
  .ranked-table {
    width: 100%;
    min-width: 1040px;
    border-collapse: collapse;
    font-size: 13px;
  }
  .ranked-table th {
    color: var(--muted);
    font-size: 11px;
    font-weight: 650;
    letter-spacing: .08em;
    text-transform: uppercase;
    text-align: left;
    padding: 10px 12px;
    border-bottom: 1px solid var(--hairline);
    white-space: nowrap;
  }
  .ranked-table td {
    padding: 17px 12px;
    border-bottom: 1px solid var(--hairline);
    vertical-align: middle;
    color: var(--ink);
  }
  .ranked-table tr.model-row:hover td {
    background: color-mix(in srgb, var(--surface) 48%, transparent);
  }
  .rank-cell {
    width: 58px;
    font-size: 16px;
    font-weight: 760;
  }
  .model-cell { min-width: 230px; }
  .model-name {
    font-size: 16px;
    font-weight: 760;
    line-height: 1.2;
    overflow-wrap: anywhere;
  }
  .model-id {
    margin-top: 3px;
    color: var(--muted);
    font-size: 12px;
    overflow-wrap: anywhere;
  }
  .identity-flag, .verified-date {
    display: block;
    margin-top: 3px;
    color: var(--muted);
    font-size: 11px;
  }
  .tier-badge {
    display: inline-flex;
    align-items: center;
    min-width: 78px;
    justify-content: center;
    padding: 3px 8px 4px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 700;
    color: var(--ink);
    border: 1px solid transparent;
  }
  .tier-badge.proven {
    background: color-mix(in srgb, var(--pass) 30%, transparent);
    border-color: color-mix(in srgb, var(--pass) 58%, var(--hairline));
  }
  .tier-badge.probation {
    background: color-mix(in srgb, var(--accent) 24%, transparent);
    border-color: color-mix(in srgb, var(--accent) 48%, var(--hairline));
  }
  .num {
    text-align: right;
    font-variant-numeric: tabular-nums;
  }
  .rate-cell {
    min-width: 108px;
  }
  .rate-value {
    display: inline-block;
    min-width: 38px;
  }
  .rate-meter {
    display: inline-block;
    width: 48px;
    height: 6px;
    margin-left: 8px;
    vertical-align: 1px;
    border-radius: 4px;
    background: color-mix(in srgb, var(--muted) 22%, transparent);
    overflow: hidden;
  }
  .rate-bar {
    display: block;
    height: 100%;
    border-radius: 4px;
    background: var(--pass);
  }
  .detail-row td {
    padding: 0;
    background: color-mix(in srgb, var(--surface) 55%, transparent);
  }
  .model-detail {
    padding: 0;
  }
  .model-detail summary {
    cursor: pointer;
    color: var(--ink);
    padding: 11px 12px;
    font-size: 13px;
    border-bottom: 1px solid var(--hairline);
  }
  .model-detail summary:hover { background: color-mix(in srgb, var(--surface) 70%, transparent); }
  .detail-content {
    display: grid;
    grid-template-columns: minmax(0, .86fr) minmax(260px, 1.14fr);
    gap: 22px;
    padding: 16px 12px 20px;
  }
  .detail-heading {
    margin: 0 0 8px;
    color: var(--muted);
    font-size: 11px;
    font-weight: 650;
    letter-spacing: .08em;
    text-transform: uppercase;
  }
  .quality-lines {
    display: grid;
    gap: 6px;
    margin: 12px 0 0;
    color: var(--muted);
    font-size: 13px;
  }
  .quality-lines b { color: var(--ink); }
  .notes-panel {
    min-width: 0;
  }
  .breakdown {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
  }
  .breakdown th, .breakdown td {
    border-bottom: 1px solid var(--hairline);
    padding: 8px 6px;
    text-align: left;
  }
  .breakdown th {
    color: var(--muted);
    font-weight: 650;
  }
  .notes-list {
    display: grid;
    gap: 10px;
    margin: 0;
    padding: 0;
    list-style: none;
    color: var(--ink);
  }
  .notes-list li {
    display: grid;
    grid-template-columns: 72px minmax(0, 1fr);
    gap: 12px;
    align-items: baseline;
  }
  .notes-list time {
    color: var(--muted);
    font-size: 11px;
    font-variant-caps: all-small-caps;
    letter-spacing: .08em;
    white-space: nowrap;
  }
  .more-notes {
    color: var(--muted);
    font-size: 12px;
  }
  .empty-note { color: var(--muted); margin: 0; }
  .muted { color: var(--muted); }
  .mono { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace; }
  footer.scoreboard-footer {
    margin-top: 14px;
    color: var(--muted);
    font-size: 12px;
  }
  @media (prefers-color-scheme: dark) {
    .watch-chip { background: rgba(255, 255, 255, .035); }
  }
  @media (max-width: 1200px) {
    .scoreboard-page { width: 100%; }
  }
  @media (max-width: 768px) {
    body { padding: 18px 14px; }
    .scoreboard-header, .detail-content { grid-template-columns: 1fr; }
    .scoreboard-meta { justify-content: flex-start; }
    .table-scroll { margin-left: -14px; margin-right: -14px; padding-left: 14px; }
    .notes-list li { grid-template-columns: 1fr; gap: 2px; }
  }
  @media (max-width: 640px) {
    .scoreboard-title { font-size: clamp(28px, 12vw, 42px); }
  }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { animation: none !important; transition: none !important; }
  }
"""
