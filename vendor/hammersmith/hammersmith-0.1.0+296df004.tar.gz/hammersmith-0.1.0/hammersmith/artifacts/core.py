"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import mimetypes
import re
import urllib.parse
from datetime import datetime
from pathlib import Path
from typing import Any

from hammersmith.constants import TASK_REPORT_FILENAMES

STATUS_COLORS = {
    "pass": "var(--pass)",
    "fail": "var(--fail)",
    "error": "var(--fail)",
    "timeout": "var(--fail)",
    "running": "var(--running)",
    "retrying": "var(--running)",
    "verifying": "var(--running)",
    "queued": "var(--waiting)",
    "died": "var(--fail)",
    "live": "var(--running)",
    "finished": "var(--pass)",
}

def status_color(status: str) -> str:
    return STATUS_COLORS.get(str(status).lower(), "var(--waiting)")

def fmt_duration(seconds: Any) -> str:
    try:
        total = max(0, int(float(seconds or 0)))
    except (TypeError, ValueError):
        total = 0
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"

def fmt_datetime(value: str) -> str:
    if not value:
        return ""
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        return value
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC")

def fmt_compact_duration(seconds: Any) -> str:
    try:
        total = max(0, int(float(seconds or 0)))
    except (TypeError, ValueError):
        total = 0
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    parts: list[str] = []
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    if s or not parts:
        parts.append(f"{s}s")
    return " ".join(parts)

def fmt_plain_ago(seconds: Any) -> str:
    try:
        total = max(0, int(float(seconds or 0)))
    except (TypeError, ValueError):
        total = 0
    if total < 60:
        return f"{total} second{'s' if total != 1 else ''}"
    minutes, seconds_left = divmod(total, 60)
    if minutes < 60:
        if seconds_left == 0:
            return f"{minutes} minute{'s' if minutes != 1 else ''}"
        return (
            f"{minutes} minute{'s' if minutes != 1 else ''} "
            f"{seconds_left} second{'s' if seconds_left != 1 else ''}"
        )
    hours, minutes_left = divmod(minutes, 60)
    if minutes_left == 0:
        return f"{hours} hour{'s' if hours != 1 else ''}"
    return (
        f"{hours} hour{'s' if hours != 1 else ''} "
        f"{minutes_left} minute{'s' if minutes_left != 1 else ''}"
    )

def file_href(path: Path) -> str:
    try:
        return path.resolve().as_uri()
    except ValueError:
        return "file://" + urllib.parse.quote(str(path))

def sanitize_artifact_name(value: str) -> str:
    sanitized = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip(".-")
    return sanitized or "artifact"

def is_html_artifact(path: Path) -> bool:
    return path.suffix.lower() in {".html", ".htm"}

def deliverable_title(path: Path) -> str:
    name = path.name.lower()
    if name == "worker.log":
        return "Work log"
    if name in TASK_REPORT_FILENAMES:
        return "What this worker produced"
    stem = path.stem.replace("_", " ").replace("-", " ").strip()
    return stem.capitalize() if stem else "Worker output"

def artifact_content_type(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".html", ".htm"}:
        return "text/html; charset=utf-8"
    if suffix == ".json":
        return "application/json; charset=utf-8"
    guessed, _encoding = mimetypes.guess_type(str(path))
    if guessed:
        if guessed.startswith("text/"):
            return f"{guessed}; charset=utf-8"
        return guessed
    return "application/octet-stream"
