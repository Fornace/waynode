"""Forge layout tokens and structure for standalone artifacts."""

ARTIFACT_BASE_CSS_LAYOUT = """
  :root {
    color-scheme: dark;
    --canvas: #10100f;
    --surface: #181816;
    --elevated: #211f1c;
    --border: #3a3732;
    --text: #f3f0ea;
    --muted: #aaa39a;
    --accent: #c87543;
    --focus: #f0a66d;
    --success: #68b884;
    --warning: #d5a95c;
    --danger: #df7770;
    --space-1: .25rem;
    --space-2: .5rem;
    --space-3: .75rem;
    --space-4: 1rem;
    --space-5: 1.5rem;
    --space-6: 2rem;
    --radius-sm: .375rem;
    --radius-md: .75rem;
    --radius-lg: 1rem;
    --elevation-1: 0 1px 2px rgba(0, 0, 0, .22);
    --elevation-2: 0 16px 42px rgba(0, 0, 0, .32);
    --ground: var(--canvas);
    --ink: var(--text);
    --hairline: var(--border);
    --pass: var(--success);
    --fail: var(--danger);
    --waiting: var(--muted);
    --quote-bg: color-mix(in srgb, var(--danger) 9%, transparent);
  }
  @media (prefers-color-scheme: light) {
    :root {
      color-scheme: light;
      --canvas: #f3f0ea;
      --surface: #fffdf9;
      --elevated: #ffffff;
      --border: #cec6bb;
      --text: #24211d;
      --muted: #665f56;
      --accent: #99502e;
      --focus: #7f3e22;
      --success: #287846;
      --warning: #8a6116;
      --danger: #a53834;
      --elevation-1: 0 1px 2px rgba(49, 39, 29, .12);
      --elevation-2: 0 16px 42px rgba(49, 39, 29, .16);
    }
  }
  :root[data-theme="dark"] {
    color-scheme: dark;
    --canvas: #10100f; --surface: #181816; --elevated: #211f1c; --border: #3a3732;
    --text: #f3f0ea; --muted: #aaa39a; --accent: #c87543; --focus: #f0a66d;
    --success: #68b884; --warning: #d5a95c; --danger: #df7770;
  }
  :root[data-theme="light"] {
    color-scheme: light;
    --canvas: #f3f0ea; --surface: #fffdf9; --elevated: #ffffff; --border: #cec6bb;
    --text: #24211d; --muted: #665f56; --accent: #99502e; --focus: #7f3e22;
    --success: #287846; --warning: #8a6116; --danger: #a53834;
  }
  * { box-sizing: border-box; }
  html, body {
    margin: 0;
    min-height: 100%;
    overflow-x: hidden;
    background: var(--ground);
    color: var(--ink);
    font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    line-height: 1.5;
  }
  body {
    padding: clamp(18px, 4vw, 52px);
  }
  .page {
    max-width: 860px;
    margin: 0 auto;
  }
  :where(a, button, summary, [tabindex]):focus-visible {
    outline: 3px solid var(--focus);
    outline-offset: 3px;
  }
  .corner {
    display: flex;
    align-items: baseline;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: clamp(14px, 3vw, 26px);
  }
  .live-dot {
    width: 9px;
    height: 9px;
    border-radius: 50%;
    background: var(--accent);
    align-self: center;
    flex: 0 0 9px;
  }
  .live-dot.pass { background: var(--pass); }
  .live-dot.fail, .live-dot.retry { background: var(--fail); }
  .live-dot.waiting { background: var(--waiting); }
  @media (prefers-reduced-motion: no-preference) {
    .live-dot.is-live { animation: pulse 1.4s ease-in-out infinite; }
    @keyframes pulse { 50% { opacity: .35; } }
  }
  .eyebrow {
    color: var(--muted);
    font-size: 12px;
    font-weight: 700;
    letter-spacing: .12em;
    letter-spacing: .02em;
  }
  .eyebrow b {
    color: var(--ink);
  }
  .clock {
    margin-left: auto;
    color: var(--muted);
    font-size: 12px;
  }
  button {
    min-height: 44px;
    padding: 0 var(--space-4);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    background: var(--elevated);
    color: var(--text);
    font: inherit;
    font-weight: 700;
    cursor: pointer;
  }
  .briefing {
    max-width: 30ch;
    margin: 0 0 clamp(16px, 3vw, 24px);
    font-size: clamp(20px, 3.4vw, 30px);
    font-weight: 800;
    letter-spacing: 0;
    line-height: 1.25;
    text-wrap: balance;
  }
  .briefing .n-pass { color: var(--pass); }
  .briefing .n-fail { color: var(--fail); }
  .rounds {
    display: flex;
    gap: 5px;
    margin-bottom: 8px;
  }
  .rounds span {
    flex: 1;
    height: 7px;
    border-radius: 4px;
    background: var(--waiting);
    opacity: .45;
  }
  .rounds .pass { background: var(--pass); opacity: 1; }
  .rounds .working { background: var(--accent); opacity: 1; }
  .rounds .retry, .rounds .fail { background: var(--fail); opacity: 1; }
  @media (prefers-reduced-motion: no-preference) {
    .rounds .working, .rounds .retry { animation: pulse 1.4s ease-in-out infinite; }
  }
  .legend {
    margin: 0;
    margin-bottom: clamp(26px, 5vw, 40px);
    color: var(--muted);
    font-size: 12.5px;
  }
  .work {
    margin-bottom: clamp(28px, 5vw, 44px);
  }
  .work-list {
    display: grid;
    gap: 10px;
    margin-top: 10px;
  }
  .work-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 0;
    border-bottom: 1px solid var(--hairline);
  }
  .work-main {
    min-width: 0;
  }
  .work-link {
    color: var(--ink);
    font-size: 15px;
    font-weight: 750;
  }
  .work-kind {
    margin-top: 2px;
    color: var(--muted);
    font-size: 12.5px;
  }
  .work-task {
    display: inline-block;
    margin-left: 6px;
  }
  .work-thumb-link {
    flex: 0 0 auto;
  }
  .work-thumb {
    display: block;
    max-width: 132px;
    max-height: 96px;
    border: 1px solid var(--hairline);
    border-radius: 6px;
    object-fit: cover;
  }
  .work.is-primary .work-list {
    gap: 12px;
  }
  .work.is-primary .work-link {
    font-size: clamp(17px, 2.6vw, 22px);
  }
  .work-group .worker {
    border-bottom: none;
    padding-bottom: 6px;
  }
  .work-group-body {
    padding: 0 0 14px 30px;
    border-bottom: 1px solid var(--hairline);
  }
  .work-group:last-child .work-group-body { border-bottom: none; }
  .work-group-body .work-item:last-of-type { border-bottom: none; }
  .work-group-body .empty-note { margin: 4px 0 8px; }
  .work-group-body .verified {
    display: block;
    margin-top: 6px;
    color: var(--muted);
    font-size: 13px;
    overflow-wrap: break-word;
  }
  .work-group-body .proof {
    margin-top: 4px;
    font-size: 12px;
  }
  .work-group-body .proof summary {
    cursor: pointer;
    color: var(--accent);
  }
  .work-group-body .proof pre {
    margin: 6px 0 0;
    padding: 10px 12px;
    max-height: 200px;
    overflow: auto;
    border-left: 2px solid var(--hairline);
    background: var(--surface);
    color: var(--muted);
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    font-size: 11.5px;
    line-height: 1.55;
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }
  .work-group-body .links {
    display: block;
    margin-top: 8px;
    font-size: 13px;
  }
  .work-group-body .links a {
    color: var(--accent);
    text-decoration: none;
  }
  .work-group-body .links a:hover,
  .work-group-body .links a:focus-visible {
    text-decoration: underline;
  }
  .work.is-primary .work-group {
    padding: 12px 16px 2px;
    border: 1px solid var(--hairline);
    border-radius: 8px;
    background: var(--surface);
  }
  .work.is-primary .work-group-body { border-bottom: none; }
  section h2 {
    margin: 0 0 4px;
    padding-bottom: 8px;
    border-bottom: 1px solid var(--hairline);
    color: var(--muted);
    font-size: 12px;
    font-weight: 700;
    letter-spacing: .1em;
    text-transform: uppercase;
  }
  .timeline {
    margin-bottom: clamp(28px, 5vw, 44px);
  }
  details.timeline > summary {
    cursor: pointer;
    list-style: none;
  }
  details.timeline > summary::-webkit-details-marker { display: none; }
  details.timeline > summary h2::after {
    content: " ▸";
    color: var(--muted);
"""
