"""Standalone artifact renderer for Hammersmith."""
from __future__ import annotations

import os
from datetime import datetime
from html import escape as html_escape
from pathlib import Path
from typing import Any

from hammersmith.constants import (
    ARTIFACT_WRAPPER_TAIL_BYTES, CSP_META_TAG,
)
from .briefing import plain_transition_event

from hammersmith.utils.io import atomic_write_text

from .core import deliverable_title, file_href, is_html_artifact, sanitize_artifact_name
from .styles import ARTIFACT_BASE_CSS

class ArtifactRenderer:
    def __init__(self, artifact_path: Path) -> None:
        self.artifact_dir = artifact_path.parent
        self._wrapper_cache: dict[tuple[Path, Path], tuple[int, int]] = {}
        self._last_task_status: dict[str, str] = {}
        self._last_run_state: str | None = None
        self._seen_transition_keys: set[tuple[str, str]] = set()
        self._transition_log: list[dict[str, str]] = []

    def render_status_html(self, state: dict[str, Any], *, page_path: Path | None = None) -> str:
        return render_status_html(state, renderer=self, force_wrappers=False, page_path=page_path)

    def render_final_report_html(self, state: dict[str, Any], *, page_path: Path | None = None) -> str:
        return render_final_report_html(state, renderer=self, force_wrappers=True, page_path=page_path)

    def render_artifact_index_html(
        self,
        entries: list[dict[str, Any]],
        *,
        page_path: Path | None = None,
    ) -> str:
        return render_artifact_index_html(
            entries,
            renderer=self,
            force_wrappers=False,
            page_path=page_path or (self.artifact_dir / "index.html"),
        )

    def transition_feed(self, state: dict[str, Any], *, limit: int | None = None) -> list[dict[str, str]]:
        self.record_transitions(state)
        if limit is None:
            return list(reversed(self._transition_log))
        return list(reversed(self._transition_log[-limit:]))

    def omitted_transition_count(self, limit: int) -> int:
        return max(0, len(self._transition_log) - limit)

    def record_transitions(self, state: dict[str, Any]) -> None:
        run_state = str(state.get("state", "live"))
        if self._last_run_state is None:
            if run_state == "live":
                self._append_transition(("run", "live"), "Hammersmith started")
        elif self._last_run_state != run_state and run_state == "finished":
            self._append_transition(("run", "finished"), "Hammersmith finished")
        self._last_run_state = run_state

        current_status: dict[str, str] = {}
        tasks = state.get("tasks") or []
        if not isinstance(tasks, list):
            tasks = []
        for task in tasks:
            if not isinstance(task, dict):
                continue
            task_key = str(task.get("key", "task"))
            status = str(task.get("status", "queued"))
            previous = self._last_task_status.get(task_key)
            current_status[task_key] = status
            if previous == status:
                continue
            event = plain_transition_event(task_key, previous, status, task)
            if event:
                self._append_transition((task_key, status), event)
        self._last_task_status = current_status

    def _append_transition(self, key: tuple[str, str], event: str | dict[str, str]) -> None:
        if key in self._seen_transition_keys:
            return
        self._seen_transition_keys.add(key)
        if isinstance(event, str):
            event = {"line": event}
        self._transition_log.append({"time": datetime.now().strftime("%H:%M:%S"), **event})

    def link_for_source(
        self,
        source_path: Path,
        *,
        state: dict[str, Any] | None = None,
        run_id: str | None = None,
        run_name: str | None = None,
        task_key: str,
        force: bool = False,
    ) -> str:
        if is_html_artifact(source_path):
            return file_href(source_path)
        if not source_path.exists():
            return file_href(source_path)

        wrapper_path = self.wrapper_path(
            run_id=str(run_id or (state or {}).get("run_id") or "run"),
            task_key=task_key,
            source_name=source_path.name,
        )
        self.write_wrapper(
            source_path,
            wrapper_path,
            run_name=str(run_name or (state or {}).get("run_name") or "hammersmith"),
            task_key=task_key,
            force=force,
        )
        return file_href(wrapper_path)

    def wrapper_path(self, *, run_id: str, task_key: str, source_name: str) -> Path:
        filename = f"{sanitize_artifact_name(task_key)}--{sanitize_artifact_name(source_name)}.html"
        return self.artifact_dir / "view" / sanitize_artifact_name(run_id) / filename

    def write_wrapper(
        self,
        source_path: Path,
        wrapper_path: Path,
        *,
        run_name: str,
        task_key: str,
        force: bool = False,
    ) -> None:
        stat = source_path.stat()
        cache_key = (source_path.resolve(), wrapper_path)
        current = (stat.st_mtime_ns, stat.st_size)
        if not force and wrapper_path.exists() and self._wrapper_cache.get(cache_key) == current:
            return

        html = render_file_wrapper_html(
            source_path=source_path,
            source_stat=stat,
            run_name=run_name,
            task_key=task_key,
        )
        atomic_write_text(wrapper_path, html)
        self._wrapper_cache[cache_key] = current

def render_file_wrapper_html(
    *,
    source_path: Path,
    source_stat: os.stat_result,
    run_name: str,
    task_key: str,
) -> str:
    size = int(source_stat.st_size)
    truncated = size > ARTIFACT_WRAPPER_TAIL_BYTES
    start = max(0, size - ARTIFACT_WRAPPER_TAIL_BYTES)
    with source_path.open("rb") as fh:
        if start:
            fh.seek(start)
        raw = fh.read()
    content = raw.decode("utf-8", errors="replace")
    source_mtime = datetime.fromtimestamp(source_stat.st_mtime).astimezone().strftime(
        "%Y-%m-%d %H:%M:%S %Z"
    )
    truncation_note = (
        f" Showing the last <b>{ARTIFACT_WRAPPER_TAIL_BYTES:,}</b> bytes"
        f" of <b>{size:,}</b>."
        if truncated
        else ""
    )
    title = html_escape(deliverable_title(source_path))
    safe_run_name = html_escape(run_name)
    safe_task_key = html_escape(task_key)
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
{CSP_META_TAG}
<title>{title}</title>
<style>{ARTIFACT_BASE_CSS}</style>
</head>
<body>
<div class="page">
  <header class="corner">
    <span class="live-dot waiting" aria-hidden="true"></span>
    <span class="eyebrow">Hammersmith &nbsp;·&nbsp; <b>{safe_run_name}</b> &nbsp;·&nbsp; {safe_task_key}</span>
    <span class="clock mono">artifact</span>
  </header>
  <section class="timeline" aria-label="{title}">
    <h1 class="briefing">{title}</h1>
    <p class="meta">{safe_task_key} produced this on <b>{source_mtime}</b>.{truncation_note}</p>
  </section>
  <pre>{html_escape(content)}</pre>
</div>
</body>
</html>
"""

# Rebind class method lookups after both modules exist; the delayed import avoids
# a pages/renderer cycle while keeping the copied method bodies unchanged.
from .pages import (  # noqa: E402
    render_artifact_index_html,
    render_final_report_html,
    render_status_html,
)
