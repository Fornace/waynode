"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import re
from datetime import datetime
from html import escape as html_escape
from typing import Any

from hammersmith.utils.activity import shorten

from .core import fmt_compact_duration, fmt_plain_ago

def state_tasks(state: dict[str, Any]) -> list[dict[str, Any]]:
    tasks = state.get("tasks") or []
    if not isinstance(tasks, list):
        return []
    return [task for task in tasks if isinstance(task, dict)]

def collect_state_deliverables(state: dict[str, Any]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for task in state_tasks(state):
        task_key = str(task.get("key", "task"))
        deliverables = task.get("deliverables") or []
        if not isinstance(deliverables, list):
            continue
        for item in deliverables:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name", "")).strip()
            path = str(item.get("path", "")).strip()
            if not name or not path:
                continue
            try:
                size = int(item.get("bytes", 0) or 0)
            except (TypeError, ValueError):
                size = 0
            items.append(
                {
                    "task_key": task_key,
                    "name": name,
                    "path": path,
                    "bytes": size,
                }
            )
    return items

def task_status_counts(state: dict[str, Any]) -> dict[str, int]:
    tasks = state_tasks(state)
    buckets = [task_state_bucket(str(task.get("status", "queued"))) for task in tasks]
    pass_n = sum(1 for bucket in buckets if bucket == "pass")
    fail_n = sum(1 for bucket in buckets if bucket == "fail")
    running_n = sum(1 for bucket in buckets if bucket == "working")
    retry_n = sum(1 for bucket in buckets if bucket == "retry")
    waiting_n = sum(1 for bucket in buckets if bucket == "waiting")
    return {
        "total": len(tasks),
        "pass": pass_n,
        "fail": fail_n,
        "running": running_n,
        "retry": retry_n,
        "waiting": waiting_n,
    }

def task_word(count: int) -> str:
    return "task" if count == 1 else "tasks"

def passed_phrase(count: int) -> str:
    if count == 1:
        return "1 finished and checked"
    return f"{count} finished and checked"

def failed_phrase(count: int) -> str:
    if count == 1:
        return "1 failed"
    return f"{count} failed"

def running_phrase(count: int) -> str:
    if count == 1:
        return "1 working"
    return f"{count} working"

def retry_phrase(count: int) -> str:
    if count == 1:
        return "1 sent back"
    return f"{count} sent back"

def waiting_phrase(count: int) -> str:
    if count == 1:
        return "1 is waiting"
    return f"{count} are waiting"

def live_briefing_sentence(state: dict[str, Any]) -> str:
    return html_to_text(live_briefing_html(state))

def live_briefing_html(state: dict[str, Any]) -> str:
    counts = task_status_counts(state)
    elapsed = fmt_plain_ago(state.get("elapsed_s"))
    total = counts["total"]
    if total == 0:
        return f"Hammersmith has no tasks. Started {html_escape(elapsed)} ago."
    parts = []
    if counts["pass"]:
        parts.append(f'<span class="n-pass">{html_escape(passed_phrase(counts["pass"]))}</span>')
    if counts["running"]:
        parts.append(html_escape(running_phrase(counts["running"])))
    if counts["retry"]:
        parts.append(f'<span class="n-fail">{html_escape(retry_phrase(counts["retry"]))}</span>')
    if counts["waiting"]:
        parts.append(html_escape(waiting_phrase(counts["waiting"])))
    if counts["fail"]:
        parts.append(f'<span class="n-fail">{html_escape(failed_phrase(counts["fail"]))}</span>')
    status_sentence = join_plain_html_parts(parts)
    return (
        f"Hammersmith is working on {total} {task_word(total)}: "
        f"{status_sentence}, started {html_escape(elapsed)} ago."
    )

def final_briefing_sentence(state: dict[str, Any]) -> str:
    return html_to_text(final_briefing_html(state))

def final_briefing_html(state: dict[str, Any]) -> str:
    counts = task_status_counts(state)
    total = counts["total"]
    pass_n = counts["pass"]
    fail_n = counts["fail"]
    elapsed = fmt_compact_duration(state.get("elapsed_s"))
    first = f"Hammersmith finished {total} {task_word(total)} in {elapsed}."
    if fail_n == 0:
        return f"{html_escape(first)} <span class=\"n-pass\">All {total} finished and checked.</span>"
    return (
        f"{html_escape(first)} <span class=\"n-pass\">{pass_n} finished and checked</span>, "
        f"<span class=\"n-fail\">{fail_n} failed after retry.</span>"
    )

def join_plain_html_parts(parts: list[str]) -> str:
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0]
    if len(parts) == 2:
        return f"{parts[0]} and {parts[1]}"
    return ", ".join(parts[:-1]) + f", and {parts[-1]}"

def html_to_text(value: str) -> str:
    return re.sub(r"<[^>]+>", "", value)

def plain_transition_line(
    task_key: str,
    previous_status: str | None,
    status: str,
    task: dict[str, Any],
) -> str | None:
    event = plain_transition_event(task_key, previous_status, status, task)
    if not event:
        return None
    return event["line"]

def plain_transition_event(
    task_key: str,
    previous_status: str | None,
    status: str,
    task: dict[str, Any],
) -> dict[str, str] | None:
    attempts = int(task.get("attempts") or 0)
    timed_out = bool(task.get("check_timed_out")) or status == "timeout"
    check_excerpt = first_check_output_line(task)
    if status == "running" and previous_status in {None, "queued"}:
        return {"line": f"{task_key} started"}
    if status == "retrying":
        if timed_out:
            return {"line": f"{task_key} timed out: trying again"}
        if check_excerpt:
            return {
                "line": f"{task_key} didn't finish cleanly: sent back to redo the work.",
                "catch": check_excerpt,
            }
        return {"line": f"{task_key} did not finish cleanly: trying again"}
    if status == "pass":
        if attempts > 1:
            return {"line": f"{task_key} passed on the second try, {fmt_compact_duration(task.get('elapsed_s'))}"}
        return {"line": f"{task_key} finished and checked, {fmt_compact_duration(task.get('elapsed_s'))}"}
    if status == "fail":
        if timed_out:
            return {"line": f"{task_key} timed out"}
        if check_excerpt:
            return {"line": f"{task_key} could not finish.", "catch": check_excerpt}
        if attempts > 1:
            return {"line": f"{task_key} failed after the second try"}
        return {"line": f"{task_key} failed"}
    if status == "timeout":
        return {"line": f"{task_key} timed out"}
    return None

def first_check_output_line(task: dict[str, Any]) -> str:
    raw = task.get("check_output_tail") or task.get("check_output") or ""
    for line in str(raw).splitlines():
        clean = line.strip()
        if clean:
            return shorten(clean, 120)
    return ""

def task_state_bucket(status: str) -> str:
    status = str(status).lower()
    if status == "pass":
        return "pass"
    if status in {"fail", "error", "timeout", "died"}:
        return "fail"
    if status == "retrying":
        return "retry"
    if status in {"running", "verifying"}:
        return "working"
    return "waiting"

def task_state_word(status: str) -> str:
    bucket = task_state_bucket(status)
    if bucket == "pass":
        return "finished & checked"
    if bucket == "working":
        return "working"
    if bucket == "retry":
        return "sent back: redoing"
    if bucket == "fail":
        return "failed"
    return "waiting"

def local_time_label() -> str:
    return datetime.now().astimezone().strftime("%H:%M:%S %Z")

def render_progress_bar(tasks: list[dict[str, Any]], counts: dict[str, int]) -> str:
    segments = []
    for task in tasks:
        key = html_escape(str(task.get("key", "task")))
        bucket = task_state_bucket(str(task.get("status", "queued")))
        state_word = html_escape(task_state_word(str(task.get("status", "queued"))))
        css_class = "" if bucket == "waiting" else f' class="{bucket}"'
        segments.append(
            f'<span{css_class} aria-label="{key}: {state_word}"></span>'
        )
    bar = "".join(segments) if segments else ""
    legend_parts = []
    if counts["pass"]:
        legend_parts.append(f'{counts["pass"]} finished')
    if counts["running"]:
        legend_parts.append(f'{counts["running"]} working')
    if counts["retry"]:
        legend_parts.append(f'{counts["retry"]} sent back')
    if counts["fail"]:
        legend_parts.append(f'{counts["fail"]} failed')
    if counts["waiting"]:
        legend_parts.append(f'{counts["waiting"]} waiting')
    legend = " · ".join(legend_parts) if legend_parts else "No tasks"
    aria = (
        f'{counts["total"]} tasks: {counts["pass"]} passed, {counts["running"]} working, '
        f'{counts["retry"]} retrying, {counts["waiting"]} waiting, {counts["fail"]} failed'
    )
    return f"""<div class="rounds" role="img" aria-label="{html_escape(aria)}">{bar}</div>
    <p class="legend">{html_escape(legend)}</p>"""
