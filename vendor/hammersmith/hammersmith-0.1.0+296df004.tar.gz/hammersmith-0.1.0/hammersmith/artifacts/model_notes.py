"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import re
from html import escape as html_escape
from pathlib import Path
from typing import Any

from hammersmith.catalog import normalize_catalog_model
from hammersmith.model_log import model_log_text

from .model_metrics import humanized_log_date, source_file_link

def normalize_notes_match_text(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip().lower()

def parse_model_notes_sections(path: Path) -> dict[str, list[str]]:
    """Return dated bullet blocks keyed by the raw level-2 heading text."""
    try:
        lines = path.expanduser().read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError):
        return {}
    sections: dict[str, list[str]] = {}
    current_heading: str | None = None
    current_bullets: list[str] = []
    active_bullet: list[str] | None = None

    def flush_bullet() -> None:
        nonlocal active_bullet
        if active_bullet is not None:
            text = "\n".join(active_bullet).strip()
            if re.search(r"\b\d{4}-\d{2}-\d{2}\b", text):
                current_bullets.append(text)
            active_bullet = None

    def flush_section() -> None:
        flush_bullet()
        if current_heading is not None:
            sections[current_heading] = list(current_bullets)

    for line in lines:
        heading_match = re.match(r"^##\s+(.+?)\s*$", line)
        if heading_match:
            flush_section()
            current_heading = heading_match.group(1).strip()
            current_bullets = []
            active_bullet = None
            continue
        if current_heading is None:
            continue
        if line.startswith("## "):
            flush_section()
            current_heading = None
            current_bullets = []
            active_bullet = None
            continue
        if line.startswith("- "):
            flush_bullet()
            active_bullet = [line[2:].strip()]
            continue
        if active_bullet is not None and (line.startswith("  ") or not line.strip()):
            active_bullet.append(line.strip())
            continue
        flush_bullet()
    flush_section()
    return sections

def model_judgment_notes(model_id: str, notes_sections: dict[str, list[str]]) -> list[str]:
    needle = normalize_notes_match_text(model_id)
    if not needle:
        return []
    id_boundary = r"A-Za-z0-9._/:-"
    needle_re = re.compile(rf"(?<![{id_boundary}]){re.escape(needle)}(?![{id_boundary}])")
    matches: list[tuple[int, int, int, list[str]]] = []
    for index, (heading, bullets) in enumerate(notes_sections.items()):
        normalized_heading = normalize_notes_match_text(heading)
        if not needle_re.search(normalized_heading):
            continue
        exact_score = 1 if normalized_heading == needle else 0
        matches.append((exact_score, len(normalized_heading), -index, bullets))
    if not matches:
        return []
    return max(matches, key=lambda item: (item[0], item[1], item[2]))[3]

def strip_inline_markdown(value: str) -> str:
    text = re.sub(r"`([^`]*)`", r"\1", value)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"[*_]{1,3}([^*_]+)[*_]{1,3}", r"\1", text)
    return re.sub(r"\s+", " ", text).strip()

def normalized_judgment_note(item: str) -> tuple[str, str] | None:
    text = re.sub(r"\s+", " ", item).strip()
    match = re.match(r"^-?\s*(\d{4}-\d{2}-\d{2})\s+(?:[-\u2013\u2014]+\s*)?(.*)$", text)
    if not match:
        return None
    body = strip_inline_markdown(match.group(2))
    if not body:
        return None
    date = humanized_log_date(match.group(1))
    short_date = re.sub(r",\s*\d{4}$", "", date)
    return short_date, body

def note_date_key(item: str) -> str:
    match = re.search(r"\b\d{4}-\d{2}-\d{2}\b", item)
    return match.group(0) if match else ""

def render_notes_list(items: list[str], *, notes_path: Path | None = None, limit: int = 5) -> str:
    if not items:
        return '<p class="empty-note">no judgment notes yet</p>'
    ordered_items = sorted(items, key=note_date_key, reverse=True)
    rendered = []
    for item in ordered_items[:limit]:
        note = normalized_judgment_note(item)
        if note is None:
            body = strip_inline_markdown(item)
            if not body:
                continue
            rendered.append(f"<li><span>{html_escape(body)}</span></li>")
            continue
        date, body = note
        rendered.append(
            f'<li><time>{html_escape(date)}</time><span>{html_escape(body)}</span></li>'
        )
    if not rendered:
        return '<p class="empty-note">no judgment notes yet</p>'
    more = ""
    if len(ordered_items) > limit and notes_path is not None:
        more = (
            f'<li class="more-notes">{source_file_link(notes_path, "more in model notes")}</li>'
        )
    return f'<ul class="notes-list">{"".join(rendered)}{more}</ul>'

def normalize_catalog_for_scoreboard(model: dict[str, Any]) -> dict[str, Any]:
    if "prompt_per_m" in model and "completion_per_m" in model:
        return model
    if isinstance(model.get("pricing"), dict):
        return normalize_catalog_model(model, fetched_at=str(model.get("fetched_at") or ""))
    return model

def catalog_models_by_id(catalog_models: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    by_id: dict[str, dict[str, Any]] = {}
    for model in catalog_models:
        model_id = str(model.get("id") or "").strip()
        if model_id:
            by_id[model_id] = normalize_catalog_for_scoreboard(model)
    return by_id

def catalog_identity_fields(
    model_key: str,
    catalog_by_id: dict[str, dict[str, Any]],
) -> dict[str, str]:
    if not model_key.startswith("openrouter/"):
        return {}
    catalog_id = model_key.removeprefix("openrouter/")
    model = catalog_by_id.get(catalog_id) or catalog_by_id.get(model_key)
    if model is None:
        return {}
    name = model_log_text(model.get("name"))
    if not name or name in {catalog_id, model_key}:
        return {}
    display = name.removesuffix(" (free)").strip()
    org = catalog_id.split("/", 1)[0] if "/" in catalog_id else ""
    lab = f"{org}?" if org else "(unverified)"
    if ":" in display:
        prefix, candidate = (part.strip() for part in display.split(":", 1))
        if candidate:
            display = candidate
        if prefix:
            lab = f"{prefix}?"
    return {"model_display": display, "lab": lab}
