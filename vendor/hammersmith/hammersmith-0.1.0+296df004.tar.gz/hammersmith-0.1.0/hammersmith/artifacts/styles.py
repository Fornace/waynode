"""Composed stylesheet for run artifacts."""

from .styles_components import ARTIFACT_BASE_CSS_COMPONENTS
from .styles_layout import ARTIFACT_BASE_CSS_LAYOUT

ARTIFACT_BASE_CSS = ARTIFACT_BASE_CSS_LAYOUT + ARTIFACT_BASE_CSS_COMPONENTS
