"""Fail-closed legacy manifest translation."""
from __future__ import annotations

import json
import re
from dataclasses import replace as dataclass_replace
from pathlib import Path
from typing import Any

from .manifest_lint import structural_manifest_findings
from .manifest_models import Manifest
from .manifest_migration_models import (
    MIGRATION_REVIEW_FIELDS, ManifestMigrationIssue, ManifestMigrationResult,
    _migration_issue, migration_executable_check, migration_path_token,
)

def migrate_legacy_manifest_obj(
    obj: Any, *, source_path: Path | None = None
) -> ManifestMigrationResult:
    """Preview a fail-closed legacy-to-Hammersmith manifest translation.

    Only aliases with one unambiguous meaning are rewritten. Structured contract
    prose, patch semantics, and integration checks are surfaced for human review.
    The caller decides whether and where to write the returned object.
    """
    if not isinstance(obj, dict):
        raise ValueError("manifest root must be a JSON object")
    migrated = json.loads(json.dumps(obj))
    changes: list[str] = []
    issues: list[ManifestMigrationIssue] = []
    review = {field_name: "not present" for field_name in MIGRATION_REVIEW_FIELDS}
    tasks = migrated.get("tasks")
    if not isinstance(tasks, list):
        _migration_issue(
            issues,
            "tasks",
            "tasks is not a list, so task aliases and contracts cannot be inspected",
            "replace tasks with a non-empty list of task objects",
        )
        tasks = []

    for index, task in enumerate(tasks):
        task_location = f"tasks[{index}]"
        if not isinstance(task, dict):
            _migration_issue(
                issues,
                task_location,
                "task is not a JSON object",
                "replace it with a task object before migration",
            )
            continue
        key = task.get("key")
        if isinstance(key, str) and key.strip():
            task_location = f"tasks[{index}]({key.strip()})"

        if "executed_check_proof" in task:
            alias_value = task.get("executed_check_proof")
            canonical_value = task.get("verified")
            location = f"{task_location}.executed_check_proof"
            if not isinstance(alias_value, str) or not alias_value.strip():
                _migration_issue(
                    issues,
                    location,
                    "executed_check_proof is not a non-empty string",
                    "write one plain-English proof sentence in verified",
                )
            elif canonical_value in (None, ""):
                task["verified"] = alias_value.strip()
                del task["executed_check_proof"]
                changes.append(f"{location} -> {task_location}.verified")
            elif isinstance(canonical_value, str) and canonical_value.strip() == alias_value.strip():
                task["verified"] = canonical_value.strip()
                del task["executed_check_proof"]
                changes.append(f"{location} removed (verified already matches)")
            else:
                _migration_issue(
                    issues,
                    location,
                    "executed_check_proof conflicts with verified",
                    "choose the authoritative proof sentence and keep only verified",
                )

        expect_files = task.get("expect_files", [])
        if not isinstance(expect_files, list) or not all(
            isinstance(item, str) for item in expect_files
        ):
            if any(alias in task for alias in ("patch_export_path", "report_export_path")):
                _migration_issue(
                    issues,
                    f"{task_location}.expect_files",
                    "expect_files is not a list of strings",
                    "repair expect_files before translating export aliases",
                )
            expect_files_valid = False
        else:
            expect_files_valid = True
            expect_files = list(expect_files)

        for alias in ("patch_export_path", "report_export_path"):
            if alias not in task:
                continue
            location = f"{task_location}.{alias}"
            alias_value = task.get(alias)
            if not isinstance(alias_value, str) or not alias_value.strip():
                _migration_issue(
                    issues,
                    location,
                    f"{alias} is not a non-empty string",
                    "declare the exported file explicitly in expect_files",
                )
                continue
            if not expect_files_valid:
                continue
            clean_value = alias_value.strip()
            if not migration_path_token(clean_value):
                _migration_issue(
                    issues,
                    location,
                    f"{alias} is ambiguous prose or an unqualified token: {alias_value!r}",
                    "replace it with the exact exported file path in expect_files",
                )
                continue
            if clean_value not in expect_files:
                expect_files.append(clean_value)
            task["expect_files"] = expect_files
            del task[alias]
            changes.append(f"{location} -> {task_location}.expect_files")

        for field_name in ("required_inputs", "expected_outputs", "forbidden_paths"):
            if field_name not in task:
                continue
            value = task[field_name]
            review[field_name] = "reviewed"
            location = f"{task_location}.{field_name}"
            if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
                _migration_issue(
                    issues,
                    location,
                    f"{field_name} is not a list of path strings",
                    f"keep only literal filesystem paths in {field_name}; move prose to spec",
                )
                continue
            for item_index, item in enumerate(value):
                item_location = f"{location}[{item_index}]"
                if (
                    field_name == "required_inputs"
                    and Path(item.strip()).suffix.casefold() == ".patch"
                ):
                    _migration_issue(
                        issues,
                        item_location,
                        "a patch is declared as a required input, so apply and integrity semantics are unknown",
                        "move it to input_patches and explicitly set path, sha256, and apply",
                    )
                elif not migration_path_token(
                    item, allow_glob=field_name == "forbidden_paths"
                ):
                    _migration_issue(
                        issues,
                        item_location,
                        f"{field_name} entry is ambiguous prose or an unqualified token: {item!r}",
                        f"move semantic requirements to spec; keep only literal paths in {field_name}",
                    )

        if "input_patches" in task:
            review["input_patches"] = "reviewed"
            patches = task["input_patches"]
            location = f"{task_location}.input_patches"
            if not isinstance(patches, list):
                _migration_issue(
                    issues,
                    location,
                    "input_patches is not a list",
                    "declare each patch as {path, sha256, apply}",
                )
            else:
                for patch_index, patch in enumerate(patches):
                    patch_location = f"{location}[{patch_index}]"
                    if not isinstance(patch, dict):
                        _migration_issue(
                            issues,
                            patch_location,
                            "input patch is not an object",
                            "declare it as {path, sha256, apply}",
                        )
                        continue
                    missing = [
                        field_name
                        for field_name in ("path", "sha256", "apply")
                        if field_name not in patch
                    ]
                    if missing:
                        _migration_issue(
                            issues,
                            patch_location,
                            f"input patch leaves migration semantics implicit: {', '.join(missing)}",
                            "explicitly set path, a verified SHA-256 digest, and apply true or false",
                        )
                        continue
                    patch_path = patch.get("path")
                    patch_sha256 = patch.get("sha256")
                    patch_apply = patch.get("apply")
                    if not migration_path_token(patch_path):
                        _migration_issue(
                            issues,
                            f"{patch_location}.path",
                            "input patch path is not a literal filesystem path",
                            "set path to the exact patch file",
                        )
                    if not isinstance(patch_sha256, str) or not re.fullmatch(
                        r"[0-9a-fA-F]{64}", patch_sha256
                    ):
                        _migration_issue(
                            issues,
                            f"{patch_location}.sha256",
                            "input patch does not have an explicit valid SHA-256 digest",
                            "hash the reviewed patch bytes and record the 64-character digest",
                        )
                    if not isinstance(patch_apply, bool):
                        _migration_issue(
                            issues,
                            f"{patch_location}.apply",
                            "input patch apply policy is not a boolean",
                            "set apply explicitly to true or false",
                        )

    if "shared_check" in migrated:
        review["shared_check"] = "configured"
        shared_check = migrated.get("shared_check")
        if not isinstance(shared_check, str) or not shared_check.strip():
            _migration_issue(
                issues,
                "shared_check",
                "shared_check is present but empty or not a string",
                "remove it for a non-parallel run or provide one executable integration check",
            )
        elif not migration_executable_check(shared_check):
            review["shared_check"] = "manual translation required"
            _migration_issue(
                issues,
                "shared_check",
                "shared_check has no positively identified executable command or script path",
                "replace descriptive prose with the exact shell command to execute",
            )
    else:
        max_parallel = migrated.get("max_parallel", 1)
        frontend_tasks = [
            task
            for task in tasks
            if isinstance(task, dict)
            and isinstance(task.get("task_type"), str)
            and "frontend" in task["task_type"].casefold()
        ]
        if isinstance(max_parallel, int) and max_parallel > 1 and len(frontend_tasks) > 1:
            review["shared_check"] = "manual translation required"
            _migration_issue(
                issues,
                "shared_check",
                "parallel frontend tasks have no shared integration check",
                "declare one fast check that passes on clean HEAD and on every candidate worktree",
            )
        elif isinstance(max_parallel, int) and max_parallel > 1:
            review["shared_check"] = "not configured; review recommended"

    try:
        manifest = Manifest.from_obj(migrated)
        manifest = dataclass_replace(manifest, source_path=source_path)
        for finding in structural_manifest_findings(manifest):
            if finding.severity == "error":
                _migration_issue(
                    issues,
                    "manifest",
                    finding.message,
                    "repair the structural contract and rerun migration",
                )
    except Exception as exc:
        _migration_issue(
            issues,
            "manifest",
            f"migrated manifest does not satisfy the Hammersmith schema: {exc}",
            "translate or remove the reported legacy field before writing output",
        )

    unique_issues = tuple(
        dict.fromkeys(
            (issue.location, issue.message, issue.required_action) for issue in issues
        )
    )
    return ManifestMigrationResult(
        manifest=migrated,
        alias_changes=tuple(changes),
        manual_translations=tuple(
            ManifestMigrationIssue(*issue_parts) for issue_parts in unique_issues
        ),
        review=review,
    )


def manifest_migration_report(
    result: ManifestMigrationResult,
    *, source_path: Path,
    output_path: Path | None = None,
    written: bool = False,
) -> dict[str, Any]:
    return {
        "schema": "hammersmith.manifest-migration.v1",
        "status": "written" if written else ("blocked" if result.blocked else "ready"),
        "source": str(source_path),
        "source_preserved": True,
        "output": str(output_path) if output_path is not None else None,
        "alias_changes": list(result.alias_changes),
        "manual_translations": [
            issue.as_dict() for issue in result.manual_translations
        ],
        "structured_review": result.review,
        "proposed_manifest": result.manifest,
    }
