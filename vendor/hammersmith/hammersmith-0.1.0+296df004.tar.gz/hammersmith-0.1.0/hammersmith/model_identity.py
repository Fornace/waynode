"""Model identity registry and evidence enrichment."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .catalog import normalize_catalog_model
from .model_log import (
    UNATTRIBUTED_MODEL_DISPLAY,
    group_model_log_tasks,
    model_log_row_engine,
    model_log_row_is_reserved_fixture,
    model_log_row_is_retry,
    model_log_row_is_unattributed,
    model_log_row_model,
    model_log_row_reasoning_effort,
    model_log_row_task_type,
    model_log_text,
)


@dataclass(frozen=True)
class ModelIdentity:
    model_display: str
    lab: str
    harness: str
    access: str
    alias: bool = False
    confidence: str = ""
    source: str = ""
    last_verified: str = ""
    unregistered: bool = False


@dataclass(frozen=True)
class ModelIdentityRegistry:
    identities: dict[tuple[str, str], ModelIdentity]
    defaults: dict[str, str]
    engine_meta: dict[str, ModelIdentity]

    def resolve(self, engine: str, model_key: str) -> ModelIdentity:
        engine_key = model_log_text(engine)
        raw_model_key = model_log_text(model_key)
        lookup_key = raw_model_key or self.defaults.get(engine_key, "")
        identity = self.identities.get((engine_key, lookup_key))
        if identity is not None:
            return identity
        meta = self.engine_meta.get(engine_key)
        if raw_model_key.startswith("openrouter/"):
            slug = raw_model_key.removeprefix("openrouter/")
            org = slug.split("/", 1)[0] if "/" in slug else ""
            return ModelIdentity(
                model_display=raw_model_key,
                lab=f"{org}?" if org else "(unverified)",
                harness=(meta.harness if meta else "OpenCode"),
                access=(meta.access if meta else "OpenRouter API"),
                confidence="fallback",
                source="unlisted OpenRouter slug",
                unregistered=True,
            )
        if raw_model_key:
            return ModelIdentity(
                model_display=raw_model_key,
                lab="(unverified)",
                harness=meta.harness if meta else (engine_key or "unknown"),
                access=meta.access if meta else "unknown",
                confidence="fallback",
                source="unregistered model slug",
                unregistered=True,
            )
        unknown = engine_key or "unknown"
        return ModelIdentity(
            model_display=unknown,
            lab="(unknown)",
            harness=unknown,
            access="unknown",
            confidence="unknown",
            source="",
        )


EMPTY_MODEL_IDENTITY_REGISTRY = ModelIdentityRegistry({}, {}, {})


def default_model_registry_path() -> Path:
    return Path(__file__).resolve().parents[1] / "registry" / "model-identity.toml"


def load_model_identity_registry(path: Path | None = None) -> ModelIdentityRegistry:
    registry_path = (path or default_model_registry_path()).expanduser().resolve()
    try:
        with registry_path.open("rb") as fh:
            data = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError):
        return EMPTY_MODEL_IDENTITY_REGISTRY
    engines_raw = data.get("engines", {})
    if not isinstance(engines_raw, dict):
        return EMPTY_MODEL_IDENTITY_REGISTRY
    identities: dict[tuple[str, str], ModelIdentity] = {}
    defaults: dict[str, str] = {}
    engine_meta: dict[str, ModelIdentity] = {}
    for engine_name, raw_engine in engines_raw.items():
        if not isinstance(raw_engine, dict):
            continue
        engine = str(engine_name).strip()
        if not engine:
            continue
        harness = model_log_text(raw_engine.get("harness")) or engine
        access = model_log_text(raw_engine.get("access")) or "unknown"
        default_key = model_log_text(raw_engine.get("default_model_key"))
        if default_key:
            defaults[engine] = default_key
        engine_meta[engine] = ModelIdentity(
            model_display=engine,
            lab="(unknown)",
            harness=harness,
            access=access,
            confidence="engine",
            source="",
        )
        models_raw = raw_engine.get("models", {})
        if not isinstance(models_raw, dict):
            continue
        for model_key_raw, raw_model in models_raw.items():
            if not isinstance(raw_model, dict):
                continue
            model_key = str(model_key_raw).strip()
            if not model_key:
                continue
            identities[(engine, model_key)] = ModelIdentity(
                model_display=model_log_text(raw_model.get("display")) or model_key,
                lab=model_log_text(raw_model.get("lab")) or "(unknown)",
                harness=harness,
                access=access,
                alias=bool(raw_model.get("alias", False)),
                confidence=model_log_text(raw_model.get("confidence")),
                source=model_log_text(raw_model.get("source")),
                last_verified=model_log_text(raw_model.get("last_verified")),
            )
    return ModelIdentityRegistry(identities, defaults, engine_meta)


def row_identity_fields(row: dict[str, Any], registry: ModelIdentityRegistry) -> dict[str, Any]:
    if model_log_row_is_unattributed(row):
        engine = model_log_row_engine(row)
        meta = registry.engine_meta.get(engine)
        return {
            "model_display": UNATTRIBUTED_MODEL_DISPLAY,
            "lab": "(unknown)",
            "harness": meta.harness if meta else (engine or "unknown"),
            "access": meta.access if meta else "unknown",
            "alias": False,
            "last_verified": "",
            "unregistered": False,
        }
    identity = registry.resolve(model_log_row_engine(row), model_log_text(row.get("model")))
    return {
        "model_display": identity.model_display,
        "lab": identity.lab,
        "harness": identity.harness,
        "access": identity.access,
        "alias": identity.alias,
        "last_verified": identity.last_verified,
        "unregistered": identity.unregistered,
    }


def normalize_catalog_for_scoreboard(model: dict[str, Any]) -> dict[str, Any]:
    if "prompt_per_m" in model and "completion_per_m" in model:
        return model
    if isinstance(model.get("pricing"), dict):
        return normalize_catalog_model(model, fetched_at=str(model.get("fetched_at") or ""))
    return model


def catalog_models_by_id(catalog_models: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    by_id: dict[str, dict[str, Any]] = {}
    for model in catalog_models:
        model_id = str(model.get("id") or "").strip()
        if model_id:
            by_id[model_id] = normalize_catalog_for_scoreboard(model)
    return by_id


def catalog_identity_fields(
    model_key: str,
    catalog_by_id: dict[str, dict[str, Any]],
) -> dict[str, str]:
    if not model_key.startswith("openrouter/"):
        return {}
    catalog_id = model_key.removeprefix("openrouter/")
    model = catalog_by_id.get(catalog_id) or catalog_by_id.get(model_key)
    if model is None:
        return {}
    name = model_log_text(model.get("name"))
    if not name or name in {catalog_id, model_key}:
        return {}
    display = name.removesuffix(" (free)").strip()
    org = catalog_id.split("/", 1)[0] if "/" in catalog_id else ""
    lab = f"{org}?" if org else "(unverified)"
    if ":" in display:
        prefix, candidate = (part.strip() for part in display.split(":", 1))
        if candidate:
            display = candidate
        if prefix:
            lab = f"{prefix}?"
    return {"model_display": display, "lab": lab}


def task_final_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    finals: list[dict[str, Any]] = []
    for task_rows in group_model_log_tasks(rows):
        ordered = sorted(
            task_rows,
            key=lambda row: (
                model_log_text(row.get("logged_at")),
                1 if model_log_row_is_retry(row) else 0,
            ),
        )
        if ordered:
            finals.append(ordered[-1])
    return finals


def enrich_model_groups_with_identity(
    groups: list[dict[str, Any]],
    rows: list[dict[str, Any]],
    registry: ModelIdentityRegistry,
    *,
    include_task_type: bool,
    catalog_models: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    catalog_by_id = catalog_models_by_id(catalog_models or [])
    identity_rows: dict[tuple[Any, ...], dict[str, Any]] = {}
    latest: dict[tuple[Any, ...], str] = {}
    for row in task_final_rows(rows):
        if model_log_row_is_reserved_fixture(row):
            continue
        group_engine = model_log_row_engine(row)
        group_model = model_log_row_model(row)
        group_task_type = model_log_row_task_type(row)
        unattributed = model_log_row_is_unattributed(row)
        reasoning_effort = None if unattributed else model_log_row_reasoning_effort(row)
        key = (
            (group_engine, group_model, group_task_type, reasoning_effort, unattributed)
            if include_task_type
            else (group_engine, group_model, reasoning_effort, unattributed)
        )
        logged_at = model_log_text(row.get("logged_at"))
        if key not in latest or logged_at >= latest[key]:
            latest[key] = logged_at
            identity = row_identity_fields(row, registry)
            if identity.get("unregistered"):
                identity.update(catalog_identity_fields(model_log_text(row.get("model")), catalog_by_id))
            identity_rows[key] = identity
    enriched: list[dict[str, Any]] = []
    for group in groups:
        key = (
            (
                str(group.get("engine") or ""), str(group.get("model") or ""),
                str(group.get("task_type") or ""), group.get("reasoning_effort"),
                bool(group.get("unattributed")),
            )
            if include_task_type
            else (
                str(group.get("engine") or ""), str(group.get("model") or ""),
                group.get("reasoning_effort"), bool(group.get("unattributed")),
            )
        )
        item = dict(group)
        item.update(identity_rows.get(key, {
            "model_display": str(group.get("model") or ""),
            "lab": "(unknown)", "harness": "unknown", "access": "unknown",
            "alias": False, "last_verified": "", "unregistered": bool(group.get("model")),
        }))
        if item.get("show_reasoning_effort") and not item.get("unattributed"):
            effort = item.get("reasoning_effort") or "(effort unrecorded)"
            item["model_display"] = f"{item['model_display']} · {effort}"
        if item.get("unattributed"):
            item["model"] = ""
        item["bucket_id"] = "|".join((
            str(item.get("engine") or ""), str(item.get("model") or ""),
            str(item.get("reasoning_effort") or ""),
            "unattributed" if item.get("unattributed") else "model",
        ))
        enriched.append(item)
    return enriched


def refresh_identity_tables(conn: Any, registry_path: Path) -> None:
    """Replace SQLite identity tables from the TOML registry."""
    registry = load_model_identity_registry(registry_path)
    conn.execute("DELETE FROM identity")
    conn.execute("DELETE FROM identity_defaults")
    if registry.identities:
        conn.executemany(
            """INSERT INTO identity (
                engine, model_key, model_display, lab, harness, access, alias,
                confidence, source, last_verified
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            [
                (
                    engine, model_key, identity.model_display, identity.lab,
                    identity.harness, identity.access, 1 if identity.alias else 0,
                    identity.confidence, identity.source, identity.last_verified,
                )
                for (engine, model_key), identity in sorted(registry.identities.items())
            ],
        )
    if registry.engine_meta:
        conn.executemany(
            """INSERT INTO identity_defaults(
                engine, default_model_key, harness, access
            ) VALUES (?, ?, ?, ?)""",
            [
                (engine, registry.defaults.get(engine, ""), identity.harness, identity.access)
                for engine, identity in sorted(registry.engine_meta.items())
            ],
        )


def load_identity_registry_from_db(conn: Any) -> ModelIdentityRegistry:
    """Load model identity registry data from SQLite."""
    identities: dict[tuple[str, str], ModelIdentity] = {}
    defaults: dict[str, str] = {}
    engine_meta: dict[str, ModelIdentity] = {}
    for row in conn.execute("SELECT * FROM identity"):
        engine = model_log_text(row["engine"])
        model_key = model_log_text(row["model_key"])
        if not engine or not model_key:
            continue
        identities[(engine, model_key)] = ModelIdentity(
            model_display=model_log_text(row["model_display"]) or model_key,
            lab=model_log_text(row["lab"]) or "(unknown)",
            harness=model_log_text(row["harness"]) or engine,
            access=model_log_text(row["access"]) or "unknown",
            alias=bool(row["alias"]), confidence=model_log_text(row["confidence"]),
            source=model_log_text(row["source"]),
            last_verified=model_log_text(row["last_verified"]),
        )
    for row in conn.execute("SELECT * FROM identity_defaults"):
        engine = model_log_text(row["engine"])
        if not engine:
            continue
        defaults[engine] = model_log_text(row["default_model_key"])
        engine_meta[engine] = ModelIdentity(
            model_display=engine, lab="(unknown)",
            harness=model_log_text(row["harness"]) or engine,
            access=model_log_text(row["access"]) or "unknown",
            confidence="engine", source="",
        )
    return ModelIdentityRegistry(identities, defaults, engine_meta)
