from __future__ import annotations

import time
from dataclasses import replace as dataclass_replace
from datetime import datetime, timezone
from pathlib import Path

from hammersmith.runtime import TaskRuntime, VerifyResult, WorkerResult
from hammersmith.artifacts.core import sanitize_artifact_name
from hammersmith.failure import (
    ENGINE_CIRCUIT_FAILURE_CLASSES, ENGINE_CIRCUIT_THRESHOLD,
    RETRYABLE_FAILURE_CLASSES, FailureAssessment, classify_failure,
    compile_retry_spec, failure_fingerprint, verdict_for,
)
from hammersmith.prompt import compile_worker_prompt
from hammersmith.utils.io import append_text, atomic_write_json


class TaskLifecycleMixin:
    async def _run_task(self, runtime: TaskRuntime) -> None:
        """Run one task behind a fail-closed lifecycle boundary."""
        try:
            await self._run_task_lifecycle(runtime)
        except Exception as exc:
            self._record_lifecycle_exception(runtime, exc)

    async def _run_task_lifecycle(self, runtime: TaskRuntime) -> None:
        async with self.semaphore:
            with self.lock:
                runtime.started_at_monotonic = time.monotonic()
                health = self.engine_health.setdefault(runtime.task.engine, {"state": "closed"})
                if health.get("state") == "open":
                    runtime.attempts = 0
                    runtime.status = "fail"
                    runtime.final_verdict = "ERROR"
                    runtime.failure_class = str(health.get("failure_class") or "provider_timeout")
                    runtime.failure_owner = "provider"
                    runtime.model_eligible = False
                    runtime.retry_decision = "circuit_open"
                    runtime.next_action = "restore and probe this engine; no automatic fallback"
                    runtime.failure_status = "engine_circuit_open"
                    runtime.failure_reason = str(health.get("reason") or "same-engine circuit is open")
                    runtime.ended_at_monotonic = time.monotonic()
                    self.state_writer.flush()
                    return
            prepared, prepare_error = await self._prepare_taskdir(runtime)
            if not prepared:
                await self._record_prepare_error(runtime, prepare_error or "taskdir preparation failed")
                return
            current_spec = self._with_shared_check(compile_worker_prompt(runtime.task))
            max_attempts = runtime.task.max_attempts
            try:
              for attempt in range(1, max_attempts + 1):
                retrying = attempt > 1
                with self.lock:
                    runtime.attempts = attempt
                    runtime.status = "retrying" if retrying else "running"
                attempt_started = time.monotonic()
                try:
                    worker = await self._run_worker(runtime, current_spec, attempt)
                except Exception as exc:
                    # Safety net: any unexpected exception in _run_worker must not
                    # leave the task stuck in "running" state. Convert to a WorkerResult
                    # with an error so the verdict logic can record a terminal state.
                    worker = WorkerResult(
                        returncode=None,
                        timed_out=False,
                        tokens=None,
                        error=f"worker lifecycle exception: {exc}",
                    )
                    append_text(
                        runtime.log_path,
                        f"\n[hammersmith] worker lifecycle exception: {exc}\n",
                    )
                with self.lock:
                    runtime.worker_pid = None
                    runtime.status = "verifying"
                    if worker.tokens is not None:
                        runtime.tokens = (runtime.tokens or 0) + worker.tokens
                verify = await self.verifier.verify(runtime.task, runtime.taskdir)
                verdict = verdict_for(worker, verify)
                if verdict == "PASS":
                    # Preserve a verified candidate before any cross-cutting smoke can fail.
                    # A failed sibling or harness must never erase a passing export.
                    self._harvest_deliverables_on_pass(runtime)
                    with self.lock:
                        runtime.exports_preserved = True
                    if self.manifest.shared_check:
                        shared_verify = await self.verifier.verify_shared_check(
                            self.manifest.shared_check,
                            runtime.taskdir,
                            timeout_s=self.manifest.shared_check_timeout_s,
                            stage="candidate_shared_check",
                        )
                        if not shared_verify.ok:
                            confirmation = await self.verifier.verify_shared_check(
                                self.manifest.shared_check,
                                runtime.taskdir,
                                timeout_s=self.manifest.shared_check_timeout_s,
                                stage="candidate_shared_check_confirmation",
                            )
                            if confirmation.ok:
                                first_failure = (
                                    shared_verify.exact_failure_excerpt
                                    or shared_verify.raw_output_excerpt
                                    or "shared check failed without output"
                                )
                                shared_verify = VerifyResult(
                                    ok=False,
                                    check_returncode=shared_verify.check_returncode,
                                    check_timed_out=shared_verify.check_timed_out,
                                    raw_output_excerpt=(
                                        "[ringer] shared check is non-deterministic: the first "
                                        "candidate run failed and the immediate confirmation passed.\n"
                                        f"First failure:\n{first_failure}"
                                    ),
                                    failure_stage="candidate_shared_check_flaky",
                                    exact_failure_excerpt=first_failure,
                                )
                        with self.lock:
                            runtime.shared_check_status = (
                                "passed"
                                if shared_verify.ok
                                else (
                                    "flaky"
                                    if shared_verify.failure_stage
                                    == "candidate_shared_check_flaky"
                                    else "failed"
                                )
                            )
                        if not shared_verify.ok:
                            verify = dataclass_replace(
                                shared_verify,
                                observed_paths=verify.observed_paths,
                            )
                            verdict = verdict_for(worker, verify)
                    else:
                        with self.lock:
                            runtime.shared_check_status = "not_configured"
                assessment = None if verdict == "PASS" else classify_failure(worker, verify)
                with self.lock:
                    runtime.last_check_returncode = verify.check_returncode
                    runtime.last_check_timed_out = verify.check_timed_out
                    runtime.last_check_output = verify.raw_output_excerpt
                    runtime.check_summary_source = verify.summary_source
                    runtime.check_summary_error = verify.summary_error
                    runtime.missing_files = verify.missing_files
                    runtime.unexpected_paths = verify.unexpected_paths
                    runtime.observed_paths = verify.observed_paths
                    if assessment is not None:
                        runtime.failure_class = assessment.failure_class
                        runtime.failure_owner = assessment.failure_owner
                        runtime.model_eligible = assessment.model_eligible
                        runtime.retry_decision = assessment.retry_decision
                        runtime.next_action = assessment.next_action
                        runtime.failure_status = assessment.status
                        runtime.failure_reason = assessment.reason
                duration_ms = int((time.monotonic() - attempt_started) * 1000)
                self._log_attempt(
                    runtime, current_spec, retrying, worker, verify, verdict, duration_ms,
                    assessment=assessment,
                )
                if verdict == "PASS":
                    self._record_engine_success(runtime.task.engine)
                    with self.lock:
                        runtime.status = "pass"
                        runtime.final_verdict = verdict
                        runtime.integration_ready = True
                        runtime.failure_class = None
                        runtime.failure_owner = None
                        runtime.model_eligible = True
                        runtime.retry_decision = "none"
                        runtime.next_action = None
                        runtime.failure_status = None
                        runtime.failure_reason = None
                        runtime.ended_at_monotonic = time.monotonic()
                    await self._cleanup_worktree_on_pass(runtime)
                    return
                assert assessment is not None
                fingerprint = failure_fingerprint(worker, verify, assessment)
                repeated = runtime.last_failure_fingerprint == fingerprint
                with self.lock:
                    runtime.last_failure_fingerprint = fingerprint
                    runtime.repeated_failure_count = (
                        runtime.repeated_failure_count + 1 if repeated else 1
                    )
                if (
                    repeated
                    and attempt > 1
                    and assessment.category in {"implementation", "test_harness"}
                    and verify.failure_stage in {"task_check", "candidate_shared_check"}
                ):
                    escalation_path = self._write_harness_repair_escalation(
                        runtime, verify, assessment, fingerprint
                    )
                    with self.lock:
                        runtime.retry_decision = "escalate_harness_repair"
                        runtime.next_action = (
                            "review the repeated invariant and launch the scoped harness-repair "
                            "request; do not spend another implementation retry"
                        )
                        runtime.escalation_path = escalation_path
                        runtime.status = "fail"
                        runtime.final_verdict = verdict
                        runtime.ended_at_monotonic = time.monotonic()
                    return
                self._record_engine_failure(runtime.task.engine, worker, assessment)
                if attempt < max_attempts and assessment.failure_class in RETRYABLE_FAILURE_CLASSES:
                    with self.lock:
                        runtime.retry_decision = "retry"
                    current_spec = self._with_shared_check(
                        compile_retry_spec(runtime.task, verify, assessment)
                    )
                    continue
                with self.lock:
                    if assessment.failure_class in RETRYABLE_FAILURE_CLASSES and attempt >= max_attempts:
                        runtime.retry_decision = "attempts_exhausted"
                    runtime.status = "fail"
                    runtime.final_verdict = verdict
                    runtime.ended_at_monotonic = time.monotonic()
                return
            except Exception as exc:
                self._record_lifecycle_exception(runtime, exc)

    def _record_lifecycle_exception(
        self, runtime: TaskRuntime, exc: Exception
    ) -> None:
        """Force unexpected lifecycle failures into a persisted terminal state."""
        with self.lock:
            runtime.status = "fail"
            runtime.final_verdict = "ERROR"
            runtime.failure_class = "unknown"
            runtime.failure_owner = "host"
            runtime.model_eligible = False
            runtime.retry_decision = "stop"
            runtime.next_action = f"inspect task lifecycle; unexpected exception: {exc}"
            runtime.failure_status = "lifecycle_exception"
            runtime.failure_reason = str(exc)
            runtime.ended_at_monotonic = time.monotonic()
        try:
            append_text(
                runtime.log_path,
                f"\n[hammersmith] task lifecycle exception: {exc}\n",
            )
        except Exception:
            pass
        try:
            self.state_writer.flush()
        except Exception:
            pass

    def _record_engine_success(self, engine: str) -> None:
        with self.lock:
            health = self.engine_health.setdefault(engine, {})
            health.update(
                {
                    "state": "closed",
                    "consecutive_zero_output_failures": 0,
                    "failure_class": None,
                    "reason": None,
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                }
            )

    def _record_engine_failure(
        self,
        engine: str,
        worker: WorkerResult,
        assessment: FailureAssessment,
    ) -> None:
        zero_output_infra = assessment.failure_class in ENGINE_CIRCUIT_FAILURE_CLASSES and not worker.output_excerpt.strip()
        hard_provider_stop = assessment.failure_class in {"provider_budget", "provider_auth"}
        with self.lock:
            health = self.engine_health.setdefault(engine, {})
            count = int(health.get("consecutive_zero_output_failures", 0) or 0)
            count = count + 1 if zero_output_infra else 0
            health.update(
                {
                    "consecutive_zero_output_failures": count,
                    "failure_class": assessment.failure_class,
                    "reason": assessment.reason,
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                }
            )
            if hard_provider_stop or count >= ENGINE_CIRCUIT_THRESHOLD:
                health["state"] = "open"
                health["next_action"] = "restore and probe this engine; no automatic fallback"
            else:
                health["state"] = "closed"

    def _write_harness_repair_escalation(
        self,
        runtime: TaskRuntime,
        verify: VerifyResult,
        assessment: FailureAssessment,
        fingerprint: str,
    ) -> Path:
        """Write a scoped repair request without inventing ownership or auto-running it."""
        target = (
            self.config.state_dir
            / "escalations"
            / self.run_id
            / f"{sanitize_artifact_name(runtime.task.key)}.harness-repair.json"
        )
        required_files = tuple(
            dict.fromkeys(
                (
                    *runtime.task.required_inputs,
                    *runtime.task.expected_outputs,
                    *runtime.task.expect_files,
                    *verify.observed_paths,
                )
            )
        )
        payload = {
            "schema": "hammersmith.harness-repair-request.v1",
            "status": "awaiting_scoped_launch",
            "run_id": self.run_id,
            "source_task": runtime.task.key,
            "task_type": "harness-repair",
            "failure_category": assessment.category,
            "failure_class": assessment.failure_class,
            "failure_fingerprint": fingerprint,
            "repeated_failure_count": runtime.repeated_failure_count,
            "exact_failing_invariant": (
                verify.exact_failure_excerpt or verify.raw_output_excerpt
            ),
            "exact_check": runtime.task.check,
            "shared_check": self.manifest.shared_check or None,
            "required_files": list(required_files),
            "source_owned_paths": list(runtime.task.owned_paths),
            "source_forbidden_paths": list(runtime.task.forbidden_paths),
            "launch_guard": (
                "The integration authority must declare the repair task's exact owned_paths "
                "before launch. This request does not grant new write scope."
            ),
            "suggested_spec": (
                "Inspect the exact failing invariant and required files first. Determine whether "
                "the executable harness is wrong or the implementation still violates it. Repair "
                "only explicitly declared owned paths, preserve the original acceptance meaning, "
                "and run the exact checks before exporting a patch."
            ),
        }
        atomic_write_json(target, payload)
        append_text(
            runtime.log_path,
            f"[hammersmith] repeated failure escalated to scoped harness-repair request: {target}\n",
        )
        return target
