"""Parent adjudication command."""
from __future__ import annotations

import argparse
from .config import AppConfig
from .control_plane.adjudications import AdjudicationStore
from .model_log import ADJUDICATION_OUTCOMES, model_log_text, read_model_log_rows

def run_adjudicate_command(config: AppConfig, args: argparse.Namespace) -> int:
    outcome = model_log_text(args.outcome)
    if outcome not in ADJUDICATION_OUTCOMES:
        raise ValueError(f"unsupported adjudication outcome: {outcome}")
    reason = model_log_text(args.reason)
    if not reason:
        raise ValueError("--reason is required")
    run_id = model_log_text(args.run_id)
    task_key = model_log_text(args.task_key)
    known_rows, _ = read_model_log_rows(config.eval.jsonl_path)
    if not any(
        model_log_text(row.get("run_id")) == run_id
        and model_log_text(row.get("task_key")) == task_key
        for row in known_rows
    ):
        raise ValueError(f"no recorded task attempt for {run_id}/{task_key}")
    adjudicator = model_log_text(getattr(args, "adjudicator", "")) or "operator"
    AdjudicationStore(config.state_dir, eval_path=config.eval.jsonl_path).append(
        run_id=run_id,
        task_key=task_key,
        outcome=outcome,
        reason=reason,
        actor=adjudicator,
        idempotency_key=f"cli:{run_id}:{task_key}:{outcome}:{reason}",
        require_finished=False,
    )
    print(f"adjudicated {run_id}/{task_key}: {outcome}")
    return 0
