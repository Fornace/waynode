"""Product, environment, and project identity helpers."""

from __future__ import annotations

import hashlib
import os
import unicodedata
from typing import Any


TOOL_NAME = "ringer"
ENV_VAR_PREFIX = "HAMMERSMITH"

PRODUCT_NAME = "Hammersmith"
ORCHESTRATOR_NAME = "Hammersmith"
PRODUCT_SLUG = "fornace-hammersmith"
UNGROUPED_PROJECT_ID = "ungrouped"
UNGROUPED_PROJECT_LABEL = "Ungrouped"


def product_identity() -> dict[str, Any]:
    """Stable public identity exposed in state and monitoring APIs."""
    return {
        "name": PRODUCT_NAME,
        "short_name": ORCHESTRATOR_NAME,
        "slug": PRODUCT_SLUG,
        "legacy_cli": TOOL_NAME,
        "env_prefix": ENV_VAR_PREFIX,
        "compatibility": {
            "cli": "hammersmith",
            "manifest_schema": "ringer",
            "environment_precedence": (
                "explicit CLI/manifest > HAMMERSMITH_* > existing config/default"
            ),
        },
    }


def environment_setting(name: str) -> str | None:
    """Resolve a branded setting from HAMMERSMITH_* environment variables."""
    value = os.environ.get(f"{ENV_VAR_PREFIX}_{name}")
    if value and value.strip():
        return value
    return None


def project_identity(project: str) -> tuple[str, str]:
    """Return a deterministic collision-resistant id and a display label."""
    label = " ".join(project.split())
    if not label:
        return UNGROUPED_PROJECT_ID, UNGROUPED_PROJECT_LABEL
    canonical = unicodedata.normalize("NFKC", label).casefold()
    ascii_text = (
        unicodedata.normalize("NFKD", canonical)
        .encode("ascii", errors="ignore")
        .decode("ascii")
    )
    slug_parts: list[str] = []
    separator_pending = False
    for character in ascii_text:
        if character.isalnum():
            if separator_pending and slug_parts:
                slug_parts.append("-")
            slug_parts.append(character)
            separator_pending = False
        else:
            separator_pending = True
    slug = "".join(slug_parts).strip("-") or "project"
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:10]
    return f"{slug[:48]}-{digest}", label


def project_selection_key(project_id: str, run_id: str) -> str:
    """Unambiguous run selector even when projects reuse run names/ids."""
    return f"{project_id}:{run_id}"
