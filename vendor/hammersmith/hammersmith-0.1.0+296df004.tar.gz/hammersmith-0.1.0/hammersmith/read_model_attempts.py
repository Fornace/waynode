"""Attempt queries for the SQLite read model."""
from __future__ import annotations

import contextlib
from pathlib import Path
from typing import Any

from .model_identity import ModelIdentityRegistry, load_identity_registry_from_db
from .model_log import (
    apply_adjudication_records, group_model_log_tasks, model_log_row_is_retry,
    model_log_text, parse_log_date,
)
from .read_model import connect_read_model_db_readonly

def db_attempt_rows(
    db_path: Path,
    *,
    since: str | None = None,
    engine: str | None = None,
) -> tuple[list[dict[str, Any]], ModelIdentityRegistry]:
    with contextlib.closing(connect_read_model_db_readonly(db_path)) as conn:
        query = """
            SELECT run_id, task_key, logged_at, engine, model, reported_model, expected_model,
                   reasoning_effort, task_type, retry,
                   verdict, duration_ms, worker_tokens, orchestrator,
                   failure_class, failure_owner, model_eligible
            FROM attempts
        """
        params: list[Any] = []
        if engine is not None:
            query += " WHERE engine = ?"
            params.append(engine)
        query += " ORDER BY id"
        rows = [
            {
                "run_id": row["run_id"],
                "task_key": row["task_key"],
                "logged_at": row["logged_at"],
                "worker_engine": row["engine"],
                "model": row["model"],
                "reported_model": row["reported_model"],
                "expected_model": row["expected_model"],
                "reasoning_effort": row["reasoning_effort"],
                "task_type": row["task_type"],
                "retry": bool(row["retry"]),
                "verdict": row["verdict"],
                "duration_ms": row["duration_ms"],
                "worker_tokens": row["worker_tokens"],
                "orchestrator": row["orchestrator"],
                "failure_class": row["failure_class"],
                "failure_owner": row["failure_owner"],
                "model_eligible": True if row["model_eligible"] is None else bool(row["model_eligible"]),
            }
            for row in conn.execute(query, params)
        ]
        adjudication_rows = [
            {
                "record_type": "adjudication",
                "run_id": row["run_id"],
                "task_key": row["task_key"],
                "logged_at": row["logged_at"],
                "outcome": row["outcome"],
                "reason": row["reason"],
                "adjudicator": row["adjudicator"],
            }
            for row in conn.execute("SELECT * FROM adjudications ORDER BY id")
        ]
        rows = apply_adjudication_records(rows + adjudication_rows)
        registry = load_identity_registry_from_db(conn)
    if since is not None:
        selected_row_ids: set[int] = set()
        for task_rows in group_model_log_tasks(rows):
            ordered = sorted(
                task_rows,
                key=lambda row: (
                    model_log_text(row.get("logged_at")),
                    1 if model_log_row_is_retry(row) else 0,
                ),
            )
            final_date = parse_log_date(ordered[-1].get("logged_at"))
            if final_date and final_date >= since:
                selected_row_ids.update(id(row) for row in task_rows)
        rows = [row for row in rows if id(row) in selected_row_ids]
    return rows, registry
