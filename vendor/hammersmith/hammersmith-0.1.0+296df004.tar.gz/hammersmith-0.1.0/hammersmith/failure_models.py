"""Failure taxonomy constants and assessment data models."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class FailureAssessment:
    failure_class: str
    failure_owner: str
    model_eligible: bool
    retry_decision: str
    next_action: str
    status: str
    reason: str

    @property
    def category(self) -> str:
        """Stable broad bucket; detailed failure_class remains backward compatible."""
        if self.failure_class.startswith("provider_"):
            return "provider"
        if self.failure_class in {"check_bug", "harness_baseline", "harness_flaky"}:
            return "test_harness"
        if self.failure_class == "patch_export":
            return "patch_export"
        if self.failure_owner == "provider":
            return "provider"
        if self.failure_owner == "check":
            return "test_harness"
        if self.failure_owner == "export":
            return "patch_export"
        if self.failure_owner == "model":
            return "implementation"
        if self.failure_owner in {"contract", "host"}:
            return self.failure_owner
        return "unknown"


__all__ = ["FailureAssessment"]
