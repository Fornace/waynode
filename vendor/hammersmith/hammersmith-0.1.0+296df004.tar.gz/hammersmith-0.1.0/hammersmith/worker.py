from __future__ import annotations

import asyncio
import contextlib
import sys
from datetime import datetime, timezone
from typing import Any

from hammersmith.process import kill_process_group, terminate_process_group
from hammersmith.runtime import TaskRuntime, WorkerResult
from hammersmith.steering import inject_steering_spec, resolve_steering_profile
from hammersmith.utils.io import append_text
from hammersmith.utils.models import (
    build_worker_command, parse_reported_model, parse_token_count,
    resolved_task_model, shell_command_for_display,
)


class RollingBytes:
    def __init__(self, max_bytes: int) -> None:
        self.max_bytes = max_bytes
        self.data = bytearray()

    def extend(self, chunk: bytes) -> None:
        self.data.extend(chunk)
        overflow = len(self.data) - self.max_bytes
        if overflow > 0:
            del self.data[:overflow]

    def text(self) -> str:
        return bytes(self.data).decode("utf-8", errors="replace")


class AsyncFileCloser:
    def __init__(self, fh: Any) -> None:
        self.fh = fh

    async def __aenter__(self) -> Any:
        return self.fh

    async def __aexit__(self, _exc_type: Any, _exc: Any, _tb: Any) -> None:
        self.fh.close()


class WorkerExecutionMixin:
    async def kill_all_workers(self) -> None:
        procs = list(self.active_processes.values())
        for proc in procs:
            if proc.returncode is None:
                terminate_process_group(proc)
        if procs:
            await asyncio.sleep(1)
        for proc in procs:
            if proc.returncode is None:
                kill_process_group(proc)

    async def _run_worker(self, runtime: TaskRuntime, spec: str, attempt: int) -> WorkerResult:
        log_path = runtime.log_path
        engine = self.config.engines.get(runtime.task.engine)
        if engine is None:
            return WorkerResult(
                returncode=None,
                timed_out=False,
                tokens=None,
                error=f"unknown worker engine: {runtime.task.engine}",
            )
        if runtime.task.full_access and not self.config.allow_full_access:
            return WorkerResult(
                returncode=None,
                timed_out=False,
                tokens=None,
                error=(
                    f"task requested full_access with engine {runtime.task.engine}, "
                    "but config allow_full_access is false"
                ),
            )
        cmd = build_worker_command(
            engine,
            taskdir=runtime.taskdir,
            spec=spec,
            full_access=runtime.task.full_access,
            engine_args=runtime.task.engine_args,
            model=runtime.task.model,
        )
        if self.config.steering.dir is not None:
            original_cmd = cmd
            steering_state: dict[str, Any] = {
                "profile": None,
                "version": None,
                "rule_ids": [],
            }
            steering_line = "[hammersmith] steering: no profile matched\n"
            try:
                resolved_model = resolved_task_model(runtime.task, engine, cmd)
                profile = resolve_steering_profile(self.config.steering.dir, resolved_model)
                injected_spec, rule_ids = inject_steering_spec(
                    spec,
                    profile,
                    inject_candidates=self.config.steering.inject_candidates,
                )
                if profile is not None:
                    steering_state = {
                        "profile": profile.slug,
                        "version": profile.profile_version,
                        "rule_ids": list(rule_ids),
                    }
                    shown_rules = ", ".join(rule_ids) if rule_ids else "(none)"
                    steering_line = (
                        f"[hammersmith] steering: profile={profile.slug} "
                        f"version={profile.profile_version} rule_ids={shown_rules}\n"
                    )
                if injected_spec != spec:
                    cmd = build_worker_command(
                        engine,
                        taskdir=runtime.taskdir,
                        spec=injected_spec,
                        full_access=runtime.task.full_access,
                        engine_args=runtime.task.engine_args,
                        model=runtime.task.model,
                    )
            except Exception:
                cmd = original_cmd
                steering_state = {"profile": None, "version": None, "rule_ids": []}
                steering_line = "[hammersmith] steering: no profile matched\n"
            with self.lock:
                runtime.steering = steering_state
            with contextlib.suppress(Exception):
                append_text(log_path, steering_line)
        with self.lock:
            runtime.last_worker_command = list(cmd)
        append_text(
            log_path,
            "\n"
            f"[hammersmith] attempt {attempt} started {datetime.now(timezone.utc).isoformat()}\n"
            f"[hammersmith] engine: {runtime.task.engine}\n"
            f"[hammersmith] command: {shell_command_for_display(cmd)} < /dev/null\n",
        )
        capture = RollingBytes(max_bytes=1_000_000)
        try:
            log_fh = log_path.open("ab")
        except OSError as exc:
            return WorkerResult(returncode=None, timed_out=False, tokens=None, error=str(exc))
        async with AsyncFileCloser(log_fh):
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    cwd=str(runtime.taskdir),
                    env=self.worker_environment(),
                    stdin=asyncio.subprocess.DEVNULL,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.STDOUT,
                    start_new_session=True,
                )
            except Exception as exc:
                message = f"[hammersmith] worker spawn failed: {exc}\n"
                log_fh.write(message.encode("utf-8", errors="replace"))
                log_fh.flush()
                return WorkerResult(returncode=None, timed_out=False, tokens=None, error=str(exc))
            with self.lock:
                runtime.worker_pid = proc.pid
            self.active_processes[proc.pid] = proc
            reader = asyncio.create_task(self._tee_stream(proc, log_fh, capture))
            timed_out = False
            try:
                await asyncio.wait_for(proc.wait(), timeout=runtime.task.timeout_s)
            except asyncio.TimeoutError:
                timed_out = True
                terminate_process_group(proc)
                try:
                    await asyncio.wait_for(proc.wait(), timeout=5)
                except asyncio.TimeoutError:
                    kill_process_group(proc)
                    await proc.wait()
            try:
                await asyncio.wait_for(reader, timeout=5)
            except asyncio.TimeoutError:
                reader.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await reader
            self.active_processes.pop(proc.pid, None)
        output_tail = capture.text()
        tokens = parse_token_count(output_tail, engine.token_regex)
        reported_model = parse_reported_model(output_tail, engine.model_report_regex)
        if timed_out:
            append_text(log_path, f"\n[hammersmith] worker timed out after {runtime.task.timeout_s}s\n")
        append_text(log_path, f"[hammersmith] attempt {attempt} exited rc={proc.returncode}\n")
        return WorkerResult(
            returncode=proc.returncode,
            timed_out=timed_out,
            tokens=tokens,
            reported_model=reported_model,
            output_excerpt=output_tail[-4000:],
        )

    async def _tee_stream(
        self,
        proc: asyncio.subprocess.Process,
        log_fh: Any,
        capture: "RollingBytes",
    ) -> None:
        if proc.stdout is None:
            return
        while True:
            chunk = await proc.stdout.read(4096)
            if not chunk:
                return
            log_fh.write(chunk)
            log_fh.flush()
            capture.extend(chunk)
            try:
                sys.stdout.buffer.write(chunk)
                sys.stdout.buffer.flush()
            except Exception:
                pass
