"""Browser opening isolated from HTTP server and CLI modules."""
import subprocess
import sys
import webbrowser


def open_in_browser(url: str) -> None:
    try:
        if sys.platform == "darwin":
            subprocess.Popen(
                ["open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
        else:
            webbrowser.open(url)
    except Exception:
        pass
