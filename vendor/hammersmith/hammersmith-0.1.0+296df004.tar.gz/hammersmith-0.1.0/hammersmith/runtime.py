from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .manifest_models import TaskSpec


@dataclass
class TaskRuntime:
    task: TaskSpec
    taskdir: Path
    log_path: Path
    report_paths: dict[str, Path] = field(default_factory=dict)
    deliverables: list[dict[str, Any]] = field(default_factory=list)
    deliverable_notes: list[str] = field(default_factory=list)
    status: str = "queued"
    spec_short: str = ""
    attempts: int = 0
    started_at_monotonic: float | None = None
    ended_at_monotonic: float | None = None
    worker_pid: int | None = None
    tokens: int | None = None
    final_verdict: str | None = None
    last_check_returncode: int | None = None
    last_check_timed_out: bool = False
    last_check_output: str = ""
    check_summary_source: str = "raw"
    check_summary_error: str | None = None
    last_worker_command: list[str] = field(default_factory=list)
    steering: dict[str, Any] | None = None
    input_patch_status: list[dict[str, Any]] = field(default_factory=list)
    failure_class: str | None = None
    failure_owner: str | None = None
    model_eligible: bool | None = None
    retry_decision: str | None = None
    next_action: str | None = None
    failure_status: str | None = None
    failure_reason: str | None = None
    missing_files: tuple[str, ...] = ()
    unexpected_paths: tuple[str, ...] = ()
    observed_paths: tuple[str, ...] = ()
    contract_preflight: str = "pending"
    shared_check_status: str = "not_configured"
    exports_preserved: bool = False
    integration_ready: bool = False
    last_failure_fingerprint: str | None = None
    repeated_failure_count: int = 0
    escalation_path: Path | None = None

    def elapsed_s(self, now: float) -> float:
        if self.started_at_monotonic is None:
            return 0.0
        end = self.ended_at_monotonic if self.ended_at_monotonic is not None else now
        return max(0.0, end - self.started_at_monotonic)


@dataclass(frozen=True)
class WorkerResult:
    returncode: int | None
    timed_out: bool
    tokens: int | None
    error: str | None = None
    reported_model: str | None = None
    output_excerpt: str = ""


@dataclass(frozen=True)
class VerifyResult:
    ok: bool
    check_returncode: int | None
    check_timed_out: bool
    raw_output_excerpt: str
    missing_files: tuple[str, ...] = ()
    scope_violations: tuple[str, ...] = ()
    unexpected_paths: tuple[str, ...] = ()
    observed_paths: tuple[str, ...] = ()
    contract_error: str | None = None
    failure_stage: str = "task_check"
    exact_failure_excerpt: str = ""
    summary_source: str = "raw"
    summary_error: str | None = None
