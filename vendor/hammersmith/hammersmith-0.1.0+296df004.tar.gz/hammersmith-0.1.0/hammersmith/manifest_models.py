"""Manifest schema models and JSON loading."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .config_models import DEFAULT_ENGINE_NAME
from .constants import (
    DEFAULT_SHARED_CHECK_TIMEOUT_S, DEFAULT_TIMEOUT_S, MODEL_SCOREBOARD_RUN_NAME,
)
from .identity import environment_setting

@dataclass(frozen=True)
class InputPatch:
    path: str
    sha256: str = ""
    apply: bool = True

    @classmethod
    def from_obj(cls, obj: Any, *, task_key: str) -> "InputPatch":
        if not isinstance(obj, dict):
            raise ValueError(f"task {task_key}: each input_patches item must be an object")
        unknown = sorted(set(obj) - {"path", "sha256", "apply"})
        if unknown:
            raise ValueError(
                f"task {task_key}: unknown input patch field(s): {', '.join(unknown)}"
            )
        path = obj.get("path", "")
        if not isinstance(path, str) or not path.strip():
            raise ValueError(f"task {task_key}: input patch path must be a non-empty string")
        sha256 = obj.get("sha256", "")
        if not isinstance(sha256, str):
            raise ValueError(f"task {task_key}: input patch sha256 must be a string")
        apply_patch = obj.get("apply", True)
        if not isinstance(apply_patch, bool):
            raise ValueError(f"task {task_key}: input patch apply must be a boolean")
        return cls(path=path.strip(), sha256=sha256.strip().lower(), apply=apply_patch)


TASK_SPEC_FIELDS = frozenset(
    {
        "key",
        "spec",
        "check",
        "engine",
        "expect_files",
        "timeout_s",
        "full_access",
        "engine_args",
        "verified",
        "model",
        "task_type",
        "owned_paths",
        "forbidden_paths",
        "required_inputs",
        "expected_outputs",
        "input_patches",
        "max_attempts",
        "layout_policy",
    }
)

MANIFEST_FIELDS = frozenset(
    {
        "run_name",
        "workdir",
        "max_parallel",
        "worktrees",
        "repo",
        "tasks",
        "project",
        "root_run_id",
        "parent_run_id",
        "replay_of",
        "duplicate_of",
        "shared_check",
        "shared_check_timeout_s",
    }
)

HIERARCHY_ENV_FIELDS = {
    "project": "PROJECT",
    "root_run_id": "ROOT_RUN_ID",
    "parent_run_id": "PARENT_RUN_ID",
}


def optional_manifest_string(
    obj: dict[str, Any], field_name: str, *, env_name: str | None = None
) -> str:
    if field_name in obj:
        value = obj[field_name]
    else:
        value = (environment_setting(env_name) or "") if env_name else ""
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a string")
    return value.strip()


@dataclass(frozen=True)
class TaskSpec:
    key: str
    spec: str
    check: str
    engine: str = DEFAULT_ENGINE_NAME
    expect_files: tuple[str, ...] = ()
    timeout_s: int = DEFAULT_TIMEOUT_S
    full_access: bool = False
    engine_args: tuple[str, ...] = ()
    verified: str = ""
    # Which model a harness engine should run for this task (fills the
    # engine's {model} placeholder); empty means the engine's model_default.
    model: str = ""
    task_type: str = ""
    owned_paths: tuple[str, ...] = ()
    forbidden_paths: tuple[str, ...] = ()
    required_inputs: tuple[str, ...] = ()
    expected_outputs: tuple[str, ...] = ()
    input_patches: tuple[InputPatch, ...] = ()
    max_attempts: int = 2
    layout_policy: str = "flexible"

    @classmethod
    def from_obj(cls, obj: dict[str, Any]) -> "TaskSpec":
        if not isinstance(obj, dict):
            raise ValueError("each task must be a JSON object")
        unknown = sorted(set(obj) - TASK_SPEC_FIELDS)
        if unknown:
            key_hint = obj.get("key", "(unknown)")
            raise ValueError(
                f"task {key_hint}: unknown task field(s): {', '.join(unknown)}"
            )
        key_raw = obj.get("key", "")
        if not isinstance(key_raw, str):
            raise ValueError("task key must be a string")
        key = key_raw.strip()
        if not key:
            raise ValueError("task key is required")
        spec = obj.get("spec", "")
        if not isinstance(spec, str):
            raise ValueError(f"task {key}: spec must be a string")
        if not spec:
            raise ValueError(f"task {key}: spec is required")
        check = obj.get("check", "")
        if not isinstance(check, str):
            raise ValueError(f"task {key}: check must be a string")
        if not check:
            raise ValueError(f"task {key}: check is required")
        expect_files = obj.get("expect_files", [])
        if not isinstance(expect_files, list) or not all(
            isinstance(item, str) for item in expect_files
        ):
            raise ValueError(f"task {key}: expect_files must be a list of strings")
        engine_raw = obj.get("engine", DEFAULT_ENGINE_NAME)
        if not isinstance(engine_raw, str):
            raise ValueError(f"task {key}: engine must be a string")
        engine = engine_raw.strip()
        if not engine:
            raise ValueError(f"task {key}: engine must not be empty")
        timeout_raw = obj.get("timeout_s", DEFAULT_TIMEOUT_S)
        if isinstance(timeout_raw, bool) or not isinstance(timeout_raw, int):
            raise ValueError(f"task {key}: timeout_s must be a positive integer")
        timeout_s = timeout_raw
        if timeout_s <= 0:
            raise ValueError(f"task {key}: timeout_s must be positive")
        full_access = obj.get("full_access", False)
        if not isinstance(full_access, bool):
            raise ValueError(f"task {key}: full_access must be a boolean")
        engine_args = obj.get("engine_args", [])
        if not isinstance(engine_args, list) or not all(isinstance(item, str) for item in engine_args):
            raise ValueError(f"task {key}: engine_args must be a list of strings")
        verified = obj.get("verified", "")
        if not isinstance(verified, str):
            raise ValueError(f"task {key}: verified must be a string (plain-English description of what the check proves)")
        model = obj.get("model", "")
        if not isinstance(model, str):
            raise ValueError(f"task {key}: model must be a string (e.g. 'openrouter/z-ai/glm-5.2')")
        task_type = obj.get("task_type", "")
        if not isinstance(task_type, str):
            raise ValueError(f"task {key}: task_type must be a string")
        structured_lists: dict[str, tuple[str, ...]] = {}
        for field_name in (
            "owned_paths",
            "forbidden_paths",
            "required_inputs",
            "expected_outputs",
        ):
            value = obj.get(field_name, [])
            if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
                raise ValueError(f"task {key}: {field_name} must be a list of strings")
            structured_lists[field_name] = tuple(item.strip() for item in value if item.strip())
        input_patches_raw = obj.get("input_patches", [])
        if not isinstance(input_patches_raw, list):
            raise ValueError(f"task {key}: input_patches must be a list")
        input_patches = tuple(
            InputPatch.from_obj(item, task_key=key) for item in input_patches_raw
        )
        max_attempts_raw = obj.get("max_attempts", 2)
        if isinstance(max_attempts_raw, bool) or not isinstance(max_attempts_raw, int):
            raise ValueError(f"task {key}: max_attempts must be a positive integer")
        max_attempts = max_attempts_raw
        if max_attempts <= 0:
            raise ValueError(f"task {key}: max_attempts must be a positive integer")
        layout_policy = obj.get("layout_policy", "flexible")
        if not isinstance(layout_policy, str) or layout_policy not in {"exact", "flexible"}:
            raise ValueError(f"task {key}: layout_policy must be 'exact' or 'flexible'")
        return cls(
            key=key,
            spec=spec,
            check=check,
            engine=engine,
            expect_files=tuple(expect_files),
            timeout_s=timeout_s,
            full_access=full_access,
            engine_args=tuple(engine_args),
            verified=verified.strip(),
            model=model.strip(),
            task_type=task_type.strip(),
            owned_paths=structured_lists["owned_paths"],
            forbidden_paths=structured_lists["forbidden_paths"],
            required_inputs=structured_lists["required_inputs"],
            expected_outputs=structured_lists["expected_outputs"],
            input_patches=input_patches,
            max_attempts=max_attempts,
            layout_policy=layout_policy,
        )


@dataclass(frozen=True)
class Manifest:
    run_name: str
    workdir: Path
    max_parallel: int
    worktrees: bool
    repo: Path | None
    tasks: tuple[TaskSpec, ...]
    project: str = ""
    root_run_id: str = ""
    parent_run_id: str = ""
    replay_of: str = ""
    duplicate_of: str = ""
    shared_check: str = ""
    shared_check_timeout_s: int = DEFAULT_SHARED_CHECK_TIMEOUT_S
    source_path: Path | None = None

    @classmethod
    def from_path(cls, path: Path) -> "Manifest":
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("manifest root must be a JSON object")
        manifest = cls.from_obj(data)
        return cls(
            run_name=manifest.run_name,
            workdir=manifest.workdir,
            max_parallel=manifest.max_parallel,
            worktrees=manifest.worktrees,
            repo=manifest.repo,
            tasks=manifest.tasks,
            project=manifest.project,
            root_run_id=manifest.root_run_id,
            parent_run_id=manifest.parent_run_id,
            replay_of=manifest.replay_of,
            duplicate_of=manifest.duplicate_of,
            shared_check=manifest.shared_check,
            shared_check_timeout_s=manifest.shared_check_timeout_s,
            source_path=path,
        )

    @classmethod
    def from_obj(cls, obj: dict[str, Any]) -> "Manifest":
        if not isinstance(obj, dict):
            raise ValueError("manifest root must be a JSON object")
        unknown = sorted(set(obj) - MANIFEST_FIELDS)
        if unknown:
            raise ValueError(f"unknown manifest field(s): {', '.join(unknown)}")
        run_name_raw = obj.get("run_name", "")
        if not isinstance(run_name_raw, str):
            raise ValueError("run_name must be a string")
        run_name = run_name_raw.strip()
        if not run_name:
            raise ValueError("run_name is required")
        if run_name == MODEL_SCOREBOARD_RUN_NAME:
            raise ValueError("run_name model-scoreboard is reserved for the scoreboard page")
        workdir_raw = obj.get("workdir")
        if not isinstance(workdir_raw, str) or not workdir_raw.strip():
            raise ValueError("workdir is required")
        workdir = Path(workdir_raw).expanduser().resolve()
        max_parallel_raw = obj.get("max_parallel", 1)
        if isinstance(max_parallel_raw, bool) or not isinstance(max_parallel_raw, int):
            raise ValueError("max_parallel must be a positive integer")
        max_parallel = max_parallel_raw
        if max_parallel <= 0:
            raise ValueError("max_parallel must be positive")
        repo_raw = obj.get("repo")
        if repo_raw is not None and not isinstance(repo_raw, str):
            raise ValueError("repo must be a string or null")
        repo = Path(repo_raw).expanduser().resolve() if repo_raw else None
        tasks_raw = obj.get("tasks")
        if not isinstance(tasks_raw, list) or not tasks_raw:
            raise ValueError("tasks must be a non-empty list")
        tasks = tuple(TaskSpec.from_obj(task) for task in tasks_raw)
        keys = [task.key for task in tasks]
        duplicates = sorted({key for key in keys if keys.count(key) > 1})
        if duplicates:
            raise ValueError(f"duplicate task keys: {', '.join(duplicates)}")
        worktrees_raw = obj.get("worktrees", False)
        if not isinstance(worktrees_raw, bool):
            raise ValueError("worktrees must be a boolean")
        worktrees = worktrees_raw
        shared_check_raw = obj.get("shared_check", "")
        if not isinstance(shared_check_raw, str):
            raise ValueError("shared_check must be a string")
        shared_check = shared_check_raw.strip()
        shared_timeout_raw = obj.get(
            "shared_check_timeout_s", DEFAULT_SHARED_CHECK_TIMEOUT_S
        )
        if isinstance(shared_timeout_raw, bool) or not isinstance(shared_timeout_raw, int):
            raise ValueError("shared_check_timeout_s must be a positive integer")
        if shared_timeout_raw <= 0:
            raise ValueError("shared_check_timeout_s must be a positive integer")
        if worktrees:
            reserved_logs_dir = (workdir / "logs").resolve()
            collisions = []
            for task in tasks:
                taskdir = (workdir / task.key).resolve()
                if taskdir == reserved_logs_dir or reserved_logs_dir in taskdir.parents:
                    collisions.append(task.key)
            if collisions:
                raise ValueError(
                    "task key(s) collide with reserved worktree logs directory "
                    f"'logs': {', '.join(collisions)}"
                )
        hierarchy = {
            field_name: optional_manifest_string(
                obj, field_name, env_name=HIERARCHY_ENV_FIELDS.get(field_name)
            )
            for field_name in (
                "project",
                "root_run_id",
                "parent_run_id",
                "replay_of",
                "duplicate_of",
            )
        }
        return cls(
            run_name=run_name,
            workdir=workdir,
            max_parallel=max_parallel,
            worktrees=worktrees,
            repo=repo,
            tasks=tasks,
            shared_check=shared_check,
            shared_check_timeout_s=shared_timeout_raw,
            **hierarchy,
        )

    def with_max_parallel(self, value: int | None) -> "Manifest":
        if value is None:
            return self
        if value <= 0:
            raise ValueError("--max-parallel must be positive")
        return Manifest(
            run_name=self.run_name,
            workdir=self.workdir,
            max_parallel=value,
            worktrees=self.worktrees,
            repo=self.repo,
            tasks=self.tasks,
            project=self.project,
            root_run_id=self.root_run_id,
            parent_run_id=self.parent_run_id,
            replay_of=self.replay_of,
            duplicate_of=self.duplicate_of,
            shared_check=self.shared_check,
            shared_check_timeout_s=self.shared_check_timeout_s,
            source_path=self.source_path,
        )
