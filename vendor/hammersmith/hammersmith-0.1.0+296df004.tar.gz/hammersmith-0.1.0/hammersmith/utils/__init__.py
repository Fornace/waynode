"""Small filesystem, model-selection, and activity-log utilities."""
