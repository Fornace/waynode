"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import os
import re
import shlex
import socket
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from hammersmith.config_models import DEFAULT_TOKEN_REGEX
from hammersmith.identity import TOOL_NAME, environment_setting

def build_run_id(run_name: str) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "-", run_name.strip()).strip("-")
    # pid suffix: same-second launches of the same run_name must not collide
    # (concurrent ringer runs would otherwise share a state file and eval run_id).
    # time_ns makes repeated in-process launches collision-safe as well as the
    # historical same-second cross-process case covered by the pid suffix.
    nonce = f"{time.time_ns():x}"
    return f"{safe_name or TOOL_NAME}-{stamp}-p{os.getpid()}-{nonce}"

def find_repo_identity(start: Path | None = None) -> str | None:
    """Per-repo agent identity: nearest .fleet-agent file walking up from start.

    Jon's fleet convention (2026-07-02): each repo has its own agent name
    (projects.agent_name in the fleet DB); a .fleet-agent file in the repo
    root mirrors it so stdlib-only tools like ringer resolve it without a
    database connection.
    """
    current = (start or Path.cwd()).resolve()
    for directory in (current, *current.parents):
        candidate = directory / ".fleet-agent"
        try:
            if candidate.is_file():
                name = re.sub(r"[^A-Za-z0-9_-]", "", candidate.read_text(encoding="utf-8", errors="replace").strip())
                if name:
                    return name
        except OSError:
            continue
    return None

def resolve_identity(
    value: str | None,
    config: AppConfig,
    identity_start_paths: Iterable[Path] = (),
) -> str:
    repo_identities = [find_repo_identity(start) for start in identity_start_paths]
    for candidate in (
        value,
        environment_setting("IDENTITY"),
        os.environ.get("FLEET_IDENTITY"),
        *repo_identities,
        find_repo_identity(),
        config.identity_default,
    ):
        if candidate and candidate.strip():
            return candidate.strip()
    return socket.gethostname().split(".", 1)[0] or TOOL_NAME

def parse_token_count(text: str, token_regex: str | None = DEFAULT_TOKEN_REGEX) -> int | None:
    if token_regex:
        matches = list(re.finditer(token_regex, text, flags=re.IGNORECASE))
        for match in reversed(matches):
            groups = [item for item in match.groups() if item]
            value = groups[0] if groups else match.group(0)
            number = re.search(r"([0-9][0-9,]*)", value)
            if number:
                return int(number.group(1).replace(",", ""))
        return None
    matches = re.findall(r"tokens\s+used\s*:?\s*([0-9][0-9,]*)", text, flags=re.IGNORECASE)
    if not matches:
        matches = re.findall(
            r"tokens\s+used\s*\r?\n\s*([0-9][0-9,]*)",
            text,
            flags=re.IGNORECASE,
        )
    if not matches:
        return None
    return int(matches[-1].replace(",", ""))

def parse_reported_model(text: str, model_report_regex: str | None) -> str | None:
    if not model_report_regex:
        return None
    match = re.search(model_report_regex, text, flags=re.IGNORECASE)
    if match is None or match.lastindex is None:
        return None
    value = match.group(1).strip()
    return value or None

def effective_model_from_command(command: list[str]) -> str:
    """Return the model selected by a composed worker argv, if present."""
    for index, item in enumerate(command):
        if item in {"-m", "--model"}:
            if index + 1 >= len(command):
                return ""
            return command[index + 1]
        if item.startswith("--model="):
            return item.removeprefix("--model=")
    return ""

def effective_reasoning_effort_from_command(command: list[str]) -> str | None:
    """Return an explicitly configured model reasoning effort from worker argv."""
    for item in command:
        match = re.search(
            r"(?:^|[=,\s])model_reasoning_effort\s*=\s*[\"']?([^\"',\s]+)",
            item,
        )
        if match:
            effort = match.group(1).strip()
            return effort or None
    return None

def resolved_task_model(
    task: TaskSpec,
    engine: EngineConfig | None,
    command: list[str] | None = None,
) -> str:
    return (
        task.model
        or (engine.model_default if engine else "")
        or effective_model_from_command(command or [])
    )

def build_worker_command(
    engine: EngineConfig,
    *,
    taskdir: Path,
    spec: str,
    full_access: bool,
    engine_args: tuple[str, ...] = (),
    model: str = "",
) -> list[str]:
    access_args = engine.full_access_args if full_access else engine.sandbox_args
    resolved_model = model or engine.model_default
    command = [engine.bin]
    for item in engine.args_template:
        if item == "{access_args}":
            command.extend(access_args)
            continue
        if item == "{model_args}":
            if resolved_model:
                model_flag = "--model" if engine.name == "pi" else "-m"
                command.extend((model_flag, resolved_model))
            continue
        if item == "{engine_args}":
            command.extend(engine_args)
            continue
        if item == "{sandbox_args}":
            command.extend(engine.sandbox_args)
            continue
        if item == "{full_access_args}":
            command.extend(engine.full_access_args)
            continue
        command.append(
            item.replace("{taskdir}", str(taskdir))
            .replace("{spec}", spec)
            .replace("{model}", resolved_model)
        )
    return command

def shell_command_for_display(parts: Iterable[str]) -> str:
    return " ".join(shlex.quote(part) for part in parts)
