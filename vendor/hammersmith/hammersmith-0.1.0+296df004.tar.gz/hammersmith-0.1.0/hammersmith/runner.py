from __future__ import annotations

import asyncio
import contextlib
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from hammersmith.lifecycle import TaskLifecycleMixin
from hammersmith.observability import RunnerObservabilityMixin
from hammersmith.runtime import TaskRuntime, WorkerResult
from hammersmith.verifier import Verifier
from hammersmith.worker import WorkerExecutionMixin
from hammersmith.workspace import TaskWorkspaceMixin
from hammersmith.cli.planning import print_summary
from hammersmith.config import AppConfig
from hammersmith.eval_logging import EvalLogger
from hammersmith.failure_taxonomy import classify_failure
from hammersmith.http_server.servers import Dashboard
from hammersmith.identity import ENV_VAR_PREFIX
from hammersmith.manifest_models import Manifest, TaskSpec
from hammersmith.state_io import hammersmith_home
from hammersmith.state_writer import StateWriter
from hammersmith.runtime import VerifyResult
from hammersmith.utils.activity import shorten
from hammersmith.utils.models import build_run_id


class HammersmithRunner(
    TaskLifecycleMixin,
    WorkerExecutionMixin,
    TaskWorkspaceMixin,
    RunnerObservabilityMixin,
):
    def __init__(
        self,
        manifest: Manifest,
        config: AppConfig,
        identity: str,
        dashboard_enabled: bool = True,
        force_browser: bool = False,
    ) -> None:
        self.manifest = manifest
        self.config = config
        self.identity = identity
        self.dashboard_enabled = dashboard_enabled
        self.run_id = build_run_id(manifest.run_name)
        self.root_run_id = manifest.root_run_id or self.run_id
        self.started_at = datetime.now(timezone.utc)
        self.lock = threading.RLock()
        self.runtimes = [self._task_runtime(task) for task in manifest.tasks]
        self.engine_health: dict[str, dict[str, Any]] = {
            name: {
                "state": "closed",
                "consecutive_zero_output_failures": 0,
                "failure_class": None,
                "reason": None,
                "updated_at": self.started_at.isoformat(),
            }
            for name in config.engines
        }
        self.shared_check_state: dict[str, Any] = {
            "status": "pending" if manifest.shared_check else "not_configured",
            "command": manifest.shared_check or None,
            "timeout_s": (
                manifest.shared_check_timeout_s if manifest.shared_check else None
            ),
            "returncode": None,
            "timed_out": False,
            "output_tail": "",
        }
        self.state_writer = StateWriter(
            self.run_id,
            manifest.run_name,
            identity,
            config.state_dir,
            config.engines,
            self.started_at,
            self.runtimes,
            self.lock,
            max_parallel=manifest.max_parallel,
            artifact=config.artifact,
            engine_health=self.engine_health,
            project=manifest.project,
            root_run_id=self.root_run_id,
            parent_run_id=manifest.parent_run_id,
            replay_of=manifest.replay_of,
            duplicate_of=manifest.duplicate_of,
            shared_check_state=self.shared_check_state,
        )
        self.dashboard = (
            Dashboard(
                state_path=self.state_writer.path,
                preferred_port=config.dashboard_port_base,
                hud_app_path=config.hud_app_path,
                force_browser=force_browser,
            )
            if dashboard_enabled
            else None
        )
        self.logger = EvalLogger(config.eval)
        self.verifier = Verifier(config.failure_summary)
        self.semaphore = asyncio.Semaphore(manifest.max_parallel)
        self.active_processes: dict[int, asyncio.subprocess.Process] = {}

    def worker_environment(self) -> dict[str, str]:
        """Environment inherited by workers and any recursive child Hammersmith run."""
        environment = os.environ.copy()
        resolved_settings = {
            "PROJECT": self.manifest.project,
            "ROOT_RUN_ID": self.root_run_id,
            "PARENT_RUN_ID": self.run_id,
            "IDENTITY": self.identity,
            "HOME": str(hammersmith_home()),
        }
        if self.config.steering.dir is not None:
            resolved_settings["STEERING_DIR"] = str(self.config.steering.dir)
        for name, value in resolved_settings.items():
            environment[f"{ENV_VAR_PREFIX}_{name}"] = value
        return environment

    def _with_shared_check(self, spec: str) -> str:
        if not self.manifest.shared_check:
            return spec
        return (
            f"{spec}\n\nSHARED CLEAN-BASE AND CANDIDATE CHECK\n"
            f"{self.manifest.shared_check}\n\n"
            "Hammersmith proved this check on the clean baseline before launch and will run it "
            "again after your exact task check. Do not weaken, bypass, or rewrite it."
        )

    async def run(self) -> int:
        self.manifest.workdir.mkdir(parents=True, exist_ok=True)
        final_state = False
        try:
            self.state_writer.start()
            if self.dashboard is not None:
                self.state_writer.set_port(self.dashboard.start())
            if not await self._run_shared_check_baseline():
                final_state = True
                return 1
            await asyncio.gather(*(self._run_task(runtime) for runtime in self.runtimes))
            final_state = True
            return 0 if all(runtime.status == "pass" for runtime in self.runtimes) else 1
        except asyncio.CancelledError:
            await self.kill_all_workers()
            with self.lock:
                now = time.monotonic()
                for runtime in self.runtimes:
                    if runtime.status not in {"pass", "fail"}:
                        runtime.status = "fail"
                        runtime.final_verdict = "ERROR"
                        runtime.failure_class = "host_interrupted"
                        runtime.failure_owner = "host"
                        runtime.model_eligible = False
                        runtime.retry_decision = "stop"
                        runtime.next_action = "resume after host availability is stable"
                        runtime.failure_status = "host_interrupted"
                        runtime.failure_reason = "orchestrator task was cancelled"
                        runtime.ended_at_monotonic = runtime.ended_at_monotonic or now
            self.state_writer.flush()
            final_state = True
            raise
        finally:
            if final_state:
                self.state_writer.finish()
            self.state_writer.stop()
            if self.dashboard is not None:
                self.dashboard.stop()
            self.logger.close()
            print_summary(self.run_id, self.runtimes)
            print("Model log updated; run 'hammersmith models' for the per-model scoreboard.")
            # The post-run journey: tell a human exactly where the results live.
            with contextlib.suppress(Exception):
                if self.state_writer.artifact is not None and self.state_writer.artifact.enabled:
                    results_page = self.state_writer.live_path
                    print(f"\nYour results: {results_page}")
                    print("Open it in a browser, or run 'hammersmith hud' for the full Hammersmith view (http://127.0.0.1:8700).")

    async def _run_shared_check_baseline(self) -> bool:
        """Prove the shared harness on an isolated clean base before workers fan out."""
        command = self.manifest.shared_check
        if not command:
            return True
        baseline_dir: Path | None = None
        cwd: Path
        worktree_created = False
        if self.manifest.repo is not None:
            if self.manifest.worktrees:
                baseline_dir = self.manifest.workdir / ".hammersmith-shared-check-baseline"
                if baseline_dir.exists():
                    return await self._record_shared_baseline_failure(
                        VerifyResult(
                            ok=False,
                            check_returncode=None,
                            check_timed_out=False,
                            raw_output_excerpt=(
                                f"baseline worktree already exists: {baseline_dir}"
                            ),
                            contract_error=(
                                f"baseline worktree already exists: {baseline_dir}"
                            ),
                            failure_stage="baseline_shared_check",
                            exact_failure_excerpt=(
                                f"baseline worktree already exists: {baseline_dir}"
                            ),
                        )
                    )
                baseline_dir.parent.mkdir(parents=True, exist_ok=True)
                proc = await asyncio.create_subprocess_exec(
                    "git", "-C", str(self.manifest.repo), "worktree", "add", "--detach",
                    str(baseline_dir), "HEAD",
                    stdin=asyncio.subprocess.DEVNULL,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.STDOUT,
                )
                stdout, _ = await proc.communicate()
                if proc.returncode != 0:
                    detail = stdout.decode("utf-8", errors="replace").strip()
                    return await self._record_shared_baseline_failure(
                        VerifyResult(
                            ok=False,
                            check_returncode=proc.returncode,
                            check_timed_out=False,
                            raw_output_excerpt=detail,
                            contract_error=detail or "baseline worktree creation failed",
                            failure_stage="baseline_shared_check",
                            exact_failure_excerpt=detail,
                        )
                    )
                worktree_created = True
                cwd = baseline_dir
            else:
                cwd = self.manifest.repo
        else:
            self.manifest.workdir.mkdir(parents=True, exist_ok=True)
            cwd = self.manifest.workdir
        try:
            verify = await self.verifier.verify_shared_check(
                command,
                cwd,
                timeout_s=self.manifest.shared_check_timeout_s,
                stage="baseline_shared_check",
            )
        finally:
            if worktree_created and baseline_dir is not None:
                cleanup = await asyncio.create_subprocess_exec(
                    "git", "-C", str(self.manifest.repo), "worktree", "remove", "--force",
                    str(baseline_dir),
                    stdin=asyncio.subprocess.DEVNULL,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.STDOUT,
                )
                await cleanup.communicate()
        if not verify.ok:
            return await self._record_shared_baseline_failure(verify)
        with self.lock:
            self.shared_check_state.update(
                {
                    "status": "passed",
                    "returncode": verify.check_returncode,
                    "timed_out": verify.check_timed_out,
                    "output_tail": shorten(verify.raw_output_excerpt, 2000),
                }
            )
            for runtime in self.runtimes:
                runtime.shared_check_status = "baseline_passed"
        self.state_writer.flush()
        return True

    async def _record_shared_baseline_failure(self, verify: VerifyResult) -> bool:
        assessment = classify_failure(WorkerResult(0, False, None), verify)
        now = time.monotonic()
        with self.lock:
            self.shared_check_state.update(
                {
                    "status": "failed",
                    "returncode": verify.check_returncode,
                    "timed_out": verify.check_timed_out,
                    "output_tail": shorten(verify.raw_output_excerpt, 2000),
                    "failure_class": assessment.failure_class,
                    "failure_category": assessment.category,
                }
            )
            for runtime in self.runtimes:
                runtime.status = "fail"
                runtime.final_verdict = "FAIL"
                runtime.failure_class = assessment.failure_class
                runtime.failure_owner = assessment.failure_owner
                runtime.model_eligible = assessment.model_eligible
                runtime.retry_decision = assessment.retry_decision
                runtime.next_action = assessment.next_action
                runtime.failure_status = assessment.status
                runtime.failure_reason = assessment.reason
                runtime.last_check_returncode = verify.check_returncode
                runtime.last_check_timed_out = verify.check_timed_out
                runtime.last_check_output = verify.raw_output_excerpt
                runtime.shared_check_status = "baseline_failed"
                runtime.ended_at_monotonic = now
        self.state_writer.flush()
        return False

    def _task_runtime(self, task: TaskSpec) -> TaskRuntime:
        taskdir = self._taskdir(task)
        log_path = self._log_path(task, taskdir)
        with contextlib.suppress(FileNotFoundError):
            log_path.unlink()
        return TaskRuntime(
            task=task,
            taskdir=taskdir,
            log_path=log_path,
            spec_short=shorten(task.spec, 120),
            input_patch_status=[
                {
                    "path": patch.path,
                    "declared_sha256": patch.sha256 or None,
                    "apply": patch.apply,
                    "status": "pending",
                }
                for patch in task.input_patches
            ],
        )

    def _taskdir(self, task: TaskSpec) -> Path:
        taskdir = (self.manifest.workdir / task.key).resolve()
        workdir = self.manifest.workdir.resolve()
        if taskdir != workdir and workdir not in taskdir.parents:
            raise ValueError(f"task key escapes workdir: {task.key}")
        return taskdir

    def _log_path(self, task: TaskSpec, taskdir: Path) -> Path:
        if not self.manifest.worktrees:
            return taskdir / "worker.log"
        logs_dir = (self.manifest.workdir / "logs").resolve()
        logs_dir.mkdir(parents=True, exist_ok=True)
        log_path = (logs_dir / f"{task.key}.worker.log").resolve()
        if log_path != logs_dir and logs_dir not in log_path.parents:
            raise ValueError(f"task key escapes logs dir: {task.key}")
        return log_path
