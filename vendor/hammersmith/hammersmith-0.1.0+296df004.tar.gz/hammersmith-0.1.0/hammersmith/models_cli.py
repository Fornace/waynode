"""Model evidence CLI and generated scoreboard command."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .artifacts.core import file_href
from .artifacts.model_aggregation import aggregate_model_scoreboard_rows
from .artifacts.model_notes import parse_model_notes_sections
from .artifacts.scoreboard import write_model_scoreboard_html
from .catalog import default_catalog_path, load_catalog_snapshot
from .catalog_cli import format_catalog_price
from .browser import open_in_browser
from .config import AppConfig
from .model_identity import (
    default_model_registry_path, enrich_model_groups_with_identity,
    load_model_identity_registry,
)
from .model_log import (
    UNATTRIBUTED_MODEL_DISPLAY, aggregate_model_log_rows, read_model_log_rows,
    validate_since_date,
)
from .model_routing import catalog_explore_candidates, proven_model_group
from .model_paths import default_model_notes_path, default_read_model_db_path, should_use_read_model_db
from .read_model import db_catalog_events, db_catalog_models, sync_read_model_db
from .read_model_attempts import db_attempt_rows
from .utils.activity import shorten

def print_model_explore(
    *,
    log_path: Path,
    rows_read: int,
    skipped: int,
    groups: list[dict[str, Any]],
    catalog_path: Path,
    catalog_models: list[dict[str, Any]],
) -> None:
    print(f"TIERS from {log_path} ({rows_read} rows, {skipped} skipped lines)")
    if not groups:
        print("  no local evidence")
    for group in groups:
        label = (
            "unranked"
            if group.get("unattributed")
            else ("proven" if proven_model_group(group) else "probation")
        )
        display = (
            f"{group.get('model_display') or UNATTRIBUTED_MODEL_DISPLAY} "
            f"[{group.get('engine') or 'unknown'}]"
            if group.get("unattributed")
            else str(group["model"])
        )
        print(
            f"  {label:<9} {display} "
            f"task_type={group['task_type']} tasks={group['tasks']} "
            f"first={group['first_try_pass_rate']:.2f} pass={group['pass_rate']:.2f}"
        )

    tested_models = {str(group.get("model")) for group in groups if group.get("model")}
    candidates = catalog_explore_candidates(catalog_models, tested_models=tested_models)
    print(f"CANDIDATES from {catalog_path}")
    if not candidates:
        print("  no untested text->text candidates with context >= 32000")
    for model in candidates:
        marker = " FREE" if model.get("free") else ""
        print(
            f"  untested  {model['id']} "
            f"in={format_catalog_price(model.get('prompt_per_m'))}/M "
            f"out={format_catalog_price(model.get('completion_per_m'))}/M "
            f"ctx={int(model.get('context_length') or 0)}{marker}"
        )

def print_model_log_table(path: Path, rows_read: int, skipped: int, groups: list[dict[str, Any]]) -> None:
    print(f"Model log: {path} ({rows_read} rows, {skipped} skipped lines)")
    header = (
        f"{'task_type':<18} {'model':<32} {'lab':<20} {'harness':<16} {'tasks':>5} "
        f"{'attempts':>8} {'passed':>6} {'failed':>6} {'pass':>6} "
        f"{'first':>6} {'dur_ms':>8} {'tokens':>8} {'last_seen'}"
    )
    print(header)
    print("-" * len(header))
    for group in groups:
        duration = "" if group["median_duration_ms"] is None else str(group["median_duration_ms"])
        tokens = "" if group["median_tokens"] is None else str(group["median_tokens"])
        display = str(group.get("model_display") or group["model"])
        if group.get("unattributed"):
            display = f"{display} [{group.get('engine') or 'unknown'}]"
        elif display != group["model"]:
            display = f"{display} ({group['model']})"
        if group.get("unregistered"):
            display = f"{display} [unregistered]"
        print(
            f"{group['task_type']:<18} {shorten(display, 32):<32} "
            f"{shorten(str(group.get('lab') or '(unknown)'), 20):<20} "
            f"{shorten(str(group.get('harness') or 'unknown'), 16):<16} "
            f"{group['tasks']:>5} {group['attempts']:>8} {group['passed']:>6} "
            f"{group['failed']:>6} {group['pass_rate']:>6.2f} "
            f"{group['first_try_pass_rate']:>6.2f} {duration:>8} "
            f"{tokens:>8} {group['last_seen']}"
        )
    print("Judgment layer: docs/MODEL-NOTES.md")
    unregistered_slugs = sorted(
        {str(group.get("model") or "") for group in groups if group.get("unregistered") and group.get("model")}
    )
    if unregistered_slugs:
        print(
            f"Unregistered model slug(s): {', '.join(unregistered_slugs)}"
            "; run the identity procedure in docs/TAXONOMY.md."
        )

def run_models_command(config: AppConfig, args: argparse.Namespace) -> int:
    default_log_path = config.eval.jsonl_path.expanduser().resolve()
    log_path = (args.log or default_log_path).expanduser().resolve()
    since = validate_since_date(args.since)
    explicit_db = getattr(args, "db", None) is not None
    db_path = (getattr(args, "db", None) or default_read_model_db_path()).expanduser().resolve()
    catalog_path = (getattr(args, "catalog_file", None) or default_catalog_path()).expanduser().resolve()
    registry_path = (getattr(args, "registry", None) or default_model_registry_path()).expanduser().resolve()
    using_db = should_use_read_model_db(
        log_path=log_path,
        default_log_path=default_log_path,
        explicit_db=explicit_db,
    )
    catalog_events: list[dict[str, Any]] | None = None
    if using_db:
        try:
            sync_result = sync_read_model_db(
                db_path,
                log_path,
                catalog_path=catalog_path,
                registry_path=registry_path,
            )
            rows, identity_registry = db_attempt_rows(db_path, since=since, engine=args.engine)
            skipped = sync_result.skipped
            catalog_models_from_db = db_catalog_models(db_path)
            catalog_events = db_catalog_events(db_path, limit=6)
        except Exception as exc:
            using_db = False
            print(f"models: SQLite read model unavailable; using JSONL fallback ({exc})", file=sys.stderr)
            rows, skipped = read_model_log_rows(log_path, since=since, engine=args.engine)
            identity_registry = load_model_identity_registry(registry_path)
            catalog_models_from_db = []
    else:
        rows, skipped = read_model_log_rows(log_path, since=since, engine=args.engine)
        identity_registry = load_model_identity_registry(registry_path)
        catalog_models_from_db = []
    catalog_models = catalog_models_from_db if using_db else load_catalog_snapshot(catalog_path)
    groups = enrich_model_groups_with_identity(
        aggregate_model_log_rows(rows, task_type=args.task_type, model=args.model),
        rows,
        identity_registry,
        include_task_type=True,
        catalog_models=catalog_models,
    )
    if args.explore:
        print_model_explore(
            log_path=log_path,
            rows_read=len(rows),
            skipped=skipped,
            groups=groups,
            catalog_path=catalog_path,
            catalog_models=catalog_models,
        )
        return 0
    html_arg = getattr(args, "html", None)
    open_requested = bool(getattr(args, "open", False))
    if html_arg is not None or open_requested:
        notes_path = (getattr(args, "notes_file", None) or default_model_notes_path()).expanduser().resolve()
        scoreboard_rows = enrich_model_groups_with_identity(
            aggregate_model_scoreboard_rows(rows, task_type=args.task_type, model=args.model),
            rows,
            identity_registry,
            include_task_type=False,
            catalog_models=catalog_models,
        )
        explicit_path = None
        if html_arg not in {None, ""}:
            explicit_path = Path(str(html_arg))
        page_path = write_model_scoreboard_html(
            config,
            path=explicit_path,
            rows=scoreboard_rows,
            log_path=log_path,
            rows_read=len(rows),
            skipped=skipped,
            catalog_path=catalog_path,
            catalog_models=catalog_models,
            notes_path=notes_path,
            notes_sections=parse_model_notes_sections(notes_path),
            catalog_events=catalog_events,
        )
        print(page_path)
        if open_requested:
            open_in_browser(file_href(page_path))
        return 0
    if args.json:
        print(json.dumps(groups))
    else:
        print_model_log_table(log_path, len(rows), skipped, groups)
    return 0
