"""Shared runtime constants with no dependency on the legacy entry point."""
from pathlib import Path

from .identity import PRODUCT_NAME, TOOL_NAME

PROJECT_STALE_AFTER_S = 30.0
DEFAULT_TIMEOUT_S = 900
CHECK_TIMEOUT_S = 60
DEFAULT_SHARED_CHECK_TIMEOUT_S = 120
ACTIVITY_TAIL_BYTES = 2048
ACTIVITY_TEXT_LIMIT = 80
ARTIFACT_WRAPPER_TAIL_BYTES = 256 * 1024
ARTIFACT_LIBRARY_MAX_VERSIONS = 20
DELIVERABLE_MAX_BYTES = 20 * 1024 * 1024
WORKER_LOG_TAIL_BYTES = 64 * 1024
TASK_REPORT_FILENAMES = ("report.md", "report.html")
TEXT_DELIVERABLE_SUFFIXES = {".md", ".txt", ".log"}
IMAGE_DELIVERABLE_SUFFIXES = {".avif", ".gif", ".jpeg", ".jpg", ".png", ".svg", ".webp"}
FALLBACK_HARVEST_SUFFIXES = (
    (TEXT_DELIVERABLE_SUFFIXES - {".log"})
    | IMAGE_DELIVERABLE_SUFFIXES
    | {".html", ".htm", ".json", ".csv", ".pdf", ".mp4", ".webm", ".mov", ".gif"}
)
FALLBACK_HARVEST_MAX_FILES = 8
SHEPHERD_MODEL = f"none ({TOOL_NAME}.py)"
VERIFY_METHOD = "executed-check"
RESERVED_FIXTURE_MODELS = frozenset(
    {"proven-model", "probation-model", "mock-model", "test-model"}
)
CSP_META_TAG = (
    '<meta http-equiv="Content-Security-Policy" '
    'content="default-src \'none\'; style-src \'unsafe-inline\'; img-src data:">'
)
_REPO_ROOT = Path(__file__).resolve().parents[1]
DASHBOARD_HTML_PATH = _REPO_ROOT / "dashboard" / "dashboard.html"
HAMMERSMITH_HTML_PATH = _REPO_ROOT / "dashboard" / "hammersmith.html"
MINIMAL_DASHBOARD_HTML = """<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>%s · %s</title></head>
<body style="font-family: system-ui, sans-serif; background:#080a0f; color:#eef4ff;">
<main id="app">dashboard/dashboard.html is missing</main>
<script>
function update(states) {
  document.getElementById("app").textContent = JSON.stringify(states, null, 2);
}
</script>
</body>
</html>
""" % (PRODUCT_NAME, PRODUCT_NAME)
MODEL_SCOREBOARD_RUN_NAME = "model-scoreboard"
MODEL_SCOREBOARD_IDENTITY = "hammersmith-models"
