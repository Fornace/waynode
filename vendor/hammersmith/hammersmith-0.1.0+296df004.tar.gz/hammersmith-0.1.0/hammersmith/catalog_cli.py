"""Presentation and background-refresh helpers for the OpenRouter catalog."""

from __future__ import annotations

import argparse
import json
import sys
import threading
import time
from pathlib import Path
from typing import Any

from .catalog import (
    CATALOG_FETCH_TIMEOUT_S,
    DEFAULT_CATALOG_SOURCE,
    CatalogRefreshResult,
    catalog_changes_path,
    catalog_sort_key,
    default_catalog_path,
    load_catalog_snapshot,
    refresh_openrouter_catalog,
)
from .identity import environment_setting

CATALOG_AUTO_REFRESH_MAX_AGE_S = 24 * 60 * 60


def shorten(value: str, limit: int) -> str:
    if len(value) <= limit:
        return value
    return value[: max(1, limit - 1)] + "…"


def format_catalog_price(value: Any, *, variable: bool = False) -> str:
    if variable or value is None:
        return "var"
    amount = float(value or 0)
    if amount == 0:
        return "0"
    if amount < 0.01:
        return f"{amount:.4f}".rstrip("0").rstrip(".")
    return f"{amount:.2f}".rstrip("0").rstrip(".")


def print_catalog_table(models: list[dict[str, Any]]) -> None:
    header = f"{'id':<48} {'$/M in':>9} {'$/M out':>9} {'ctx':>8} {'FREE':<4}"
    print(header)
    print("-" * len(header))
    for model in sorted(models, key=catalog_sort_key):
        variable_pricing = bool(model.get("variable_pricing"))
        marker = "FREE" if model.get("free") else ""
        print(
            f"{shorten(str(model.get('id', '')), 48):<48} "
            f"{format_catalog_price(model.get('prompt_per_m'), variable=variable_pricing):>9} "
            f"{format_catalog_price(model.get('completion_per_m'), variable=variable_pricing):>9} "
            f"{int(model.get('context_length') or 0):>8} {marker:<4}"
        )


def read_catalog_events(path: Path, *, limit: int = 20) -> list[dict[str, Any]]:
    try:
        lines = path.expanduser().read_text(encoding="utf-8").splitlines()
    except FileNotFoundError:
        return []
    events: list[dict[str, Any]] = []
    for line in reversed(lines):
        if len(events) >= limit:
            break
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict):
            events.append(event)
    return events


def describe_catalog_event(event: dict[str, Any]) -> str:
    kind = str(event.get("kind", "event"))
    model_id = str(event.get("id", ""))
    ts = str(event.get("ts", ""))
    if kind == "price_change":
        return (
            f"{ts} {model_id} price_change: "
            f"in {format_catalog_price(event.get('old_prompt_per_m'))}"
            f" -> {format_catalog_price(event.get('new_prompt_per_m'))}, "
            f"out {format_catalog_price(event.get('old_completion_per_m'))}"
            f" -> {format_catalog_price(event.get('new_completion_per_m'))}"
        )
    if kind in {"went_free", "went_paid"}:
        return f"{ts} {model_id} {kind}"
    if kind == "pricing_variable":
        return f"{ts} {model_id} pricing_variable"
    if kind == "pricing_fixed":
        return (
            f"{ts} {model_id} pricing_fixed: "
            f"in {format_catalog_price(event.get('new_prompt_per_m'))}, "
            f"out {format_catalog_price(event.get('new_completion_per_m'))}"
        )
    if kind == "added":
        marker = " FREE" if event.get("free") else ""
        return f"{ts} {model_id} added{marker}"
    if kind == "removed":
        return f"{ts} {model_id} removed"
    return f"{ts} {model_id} {kind}"


def run_catalog_command(args: argparse.Namespace) -> int:
    snapshot_path = (args.file or default_catalog_path()).expanduser().resolve()
    if args.refresh:
        models = refresh_openrouter_catalog(
            snapshot_path,
            source=args.source or DEFAULT_CATALOG_SOURCE,
        ).models
    else:
        models = load_catalog_snapshot(snapshot_path)
    if args.changes:
        for event in read_catalog_events(catalog_changes_path(snapshot_path)):
            print(describe_catalog_event(event))
        return 0
    if args.free:
        models = [model for model in models if model.get("free")]
    if args.json:
        print(json.dumps(sorted(models, key=catalog_sort_key)))
        return 0
    if not models:
        print(f"No catalog snapshot at {snapshot_path}. Run 'hammersmith catalog --refresh'.", file=sys.stderr)
        return 1
    print_catalog_table(models)
    return 0


def catalog_snapshot_is_fresh(
    snapshot_path: Path,
    *,
    max_age_s: int = CATALOG_AUTO_REFRESH_MAX_AGE_S,
    now: float | None = None,
) -> bool:
    try:
        mtime = snapshot_path.expanduser().stat().st_mtime
    except OSError:
        return False
    return ((time.time() if now is None else now) - mtime) < max_age_s


def start_catalog_auto_refresh(
    *,
    snapshot_path: Path | None = None,
    source: str = DEFAULT_CATALOG_SOURCE,
    print_notice: bool = True,
    refresh_fn: Any | None = None,
) -> threading.Thread | None:
    try:
        if environment_setting("NO_CATALOG_REFRESH") == "1":
            return None
        path = (snapshot_path or default_catalog_path()).expanduser().resolve()
        if catalog_snapshot_is_fresh(path):
            return None
    except Exception:
        return None

    def worker() -> None:
        try:
            refresh = refresh_fn or refresh_openrouter_catalog
            result = refresh(path, source=source, timeout=CATALOG_FETCH_TIMEOUT_S)
            went_free = [event for event in result.events if event.get("kind") == "went_free"]
            if print_notice and went_free:
                sample = ", ".join(str(event.get("id")) for event in went_free[:3])
                extra = "" if len(went_free) <= 3 else f" and {len(went_free) - 3} more"
                print(f"Catalog refresh: model went FREE: {sample}{extra}", file=sys.stderr, flush=True)
        except Exception:
            pass

    try:
        thread = threading.Thread(target=worker, name="ringer-catalog-refresh", daemon=True)
        thread.start()
        return thread
    except Exception:
        return None


__all__ = [
    "CATALOG_AUTO_REFRESH_MAX_AGE_S",
    "CatalogRefreshResult",
    "catalog_snapshot_is_fresh",
    "describe_catalog_event",
    "format_catalog_price",
    "print_catalog_table",
    "read_catalog_events",
    "run_catalog_command",
    "start_catalog_auto_refresh",
]
