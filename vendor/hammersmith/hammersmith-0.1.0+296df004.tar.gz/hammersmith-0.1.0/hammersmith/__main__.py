#!/usr/bin/env python3
"""Allow running Hammersmith as a module: python -m hammersmith"""
from hammersmith.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
