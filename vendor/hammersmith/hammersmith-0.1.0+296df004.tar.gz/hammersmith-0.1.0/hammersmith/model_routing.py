"""Advisory model lanes and evidence-driven catalog routing candidates."""

from __future__ import annotations

from typing import Any, Protocol

from .model_log import RESERVED_FIXTURE_MODELS
from .model_scoreboard import PROVEN_MIN_FIRST_TRY, PROVEN_MIN_TASKS


class RoutingTask(Protocol):
    engine: str
    model: str
    task_type: str
    layout_policy: str


class RoutingEngine(Protocol):
    model_default: str


def routing_suggestion(task: RoutingTask, engine: RoutingEngine | None = None) -> str:
    """Return stable, advisory-only lane guidance for a task."""
    identity = " ".join(
        part
        for part in (
            task.engine,
            task.model,
            engine.model_default if engine is not None else "",
        )
        if part
    ).lower()
    task_shape = task.task_type.lower()
    if "sol" in identity:
        return (
            "SOL: integration authority for architecture, sequencing, serial patch "
            "integration, and final verification; delegate typing-heavy implementation. "
            "Advisory only; no automatic fallback."
        )
    if "luna" in identity:
        return (
            "Luna: contract preflight and adversarial review; validate ownership, inputs, "
            "outputs, checks, and cross-module semantics before integration. Advisory only; "
            "no automatic fallback."
        )
    if "fornace-max" in identity or "fornace_max" in identity:
        warning = (
            " Exact-layout warning: require Luna contract preflight and treat requested "
            "paths and filenames as API."
            if task.layout_policy == "exact"
            else ""
        )
        return (
            "Fornace Max: complex backend, integration, migration, evaluation, training, "
            "or substantial frontend implementation."
            f"{warning} Advisory only; no automatic fallback."
        )
    if "fornace-fast" in identity or "fornace_fast" in identity:
        warning = (
            " Warning: use Luna or SOL review for product semantics or documentation naming; "
            "copy exact paths and filenames literally."
            if "doc" in task_shape or "product" in task_shape or task.layout_policy != "exact"
            else " Copy exact paths and filenames literally."
        )
        return (
            "Fornace Fast: narrow mechanical exact-layout work, scaffolding, fixtures, "
            "formatting, or repetitive tests."
            f"{warning} Advisory only; no automatic fallback."
        )
    return (
        "General lane: match the engine and model to task complexity, contract precision, "
        "and review risk. Advisory only; no automatic fallback."
    )


def proven_model_group(group: dict[str, Any]) -> bool:
    return (
        int(group.get("tasks") or 0) >= PROVEN_MIN_TASKS
        and float(group.get("first_try_pass_rate") or 0) >= PROVEN_MIN_FIRST_TRY
    )


def catalog_model_is_text_candidate(model: dict[str, Any]) -> bool:
    try:
        context_length = int(model.get("context_length") or 0)
    except (TypeError, ValueError):
        context_length = 0
    return (
        not bool(model.get("variable_pricing"))
        and str(model.get("modality", "")).strip().lower() == "text->text"
        and context_length >= 32000
    )


def catalog_explore_candidates(
    catalog_models: list[dict[str, Any]],
    *,
    tested_models: set[str],
    limit: int = 10,
) -> list[dict[str, Any]]:
    candidates = [
        model
        for model in catalog_models
        if str(model.get("id", "")).strip() not in tested_models
        and str(model.get("id", "")).strip() not in RESERVED_FIXTURE_MODELS
        and catalog_model_is_text_candidate(model)
    ]
    return sorted(
        candidates,
        key=lambda model: (
            not bool(model.get("free")),
            float(model.get("prompt_per_m") or 0) + float(model.get("completion_per_m") or 0),
            str(model.get("id") or ""),
        ),
    )[:limit]
