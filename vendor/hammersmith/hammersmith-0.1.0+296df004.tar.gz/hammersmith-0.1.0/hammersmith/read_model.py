"""Incremental SQLite read-model synchronization for evaluation data."""

from __future__ import annotations

import contextlib
import json
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import sqlite3
except Exception:  # pragma: no cover - supports constrained Python builds.
    sqlite3 = None  # type: ignore[assignment]

from hammersmith.eval_logging import (
    model_log_int,
    model_log_row_engine,
    model_log_row_is_model_eligible,
    model_log_row_is_retry,
    model_log_row_reasoning_effort,
    model_log_text,
)
from hammersmith.identity import environment_setting
from hammersmith.model_identity import (
    default_model_registry_path,
    refresh_identity_tables,
)
from hammersmith.read_model_catalog import (
    db_catalog_events as _db_catalog_events,
    db_catalog_models as _db_catalog_models,
    default_catalog_path,
    refresh_catalog_tables,
)


STATE_DIR_NAME = ".hammersmith"


def hammersmith_home() -> Path:
    value = environment_setting("HOME")
    if value and value.strip():
        return Path(value).expanduser().resolve()
    return (Path.home() / STATE_DIR_NAME).resolve()


def default_read_model_db_path() -> Path:
    return hammersmith_home() / "hammersmith.db"


def ensure_sqlite_available() -> Any:
    if sqlite3 is None:
        raise RuntimeError("sqlite3 is unavailable")
    return sqlite3


def connect_read_model_db(path: Path) -> Any:
    sqlite = ensure_sqlite_available()
    path = path.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite.connect(str(path))
    conn.row_factory = sqlite.Row
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def connect_read_model_db_readonly(path: Path) -> Any:
    sqlite = ensure_sqlite_available()
    path = path.expanduser().resolve()
    if not path.exists():
        raise RuntimeError(f"read model database missing: {path}")
    uri_path = urllib.parse.quote(path.as_posix(), safe="/")
    conn = sqlite.connect(f"file:{uri_path}?mode=ro", uri=True)
    conn.row_factory = sqlite.Row
    conn.execute("PRAGMA busy_timeout=5000")
    return conn


def read_model_table_exists(conn: Any, name: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (name,)
    ).fetchone()
    return row is not None


def read_model_column_exists(conn: Any, table: str, column: str) -> bool:
    return any(str(row[1]) == column for row in conn.execute(f"PRAGMA table_info({table})"))


def create_read_model_schema(conn: Any) -> None:
    schema_table_exists = read_model_table_exists(conn, "schema_version")
    user_version = int(conn.execute("PRAGMA user_version").fetchone()[0] or 0)
    schema_version = None
    if schema_table_exists:
        row = conn.execute("SELECT version FROM schema_version LIMIT 1").fetchone()
        if row is not None:
            schema_version = int(row[0])
    needs_stamp = user_version != 4 or schema_version != 4
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS attempts (
            id INTEGER PRIMARY KEY, run_id TEXT, task_key TEXT, logged_at TEXT,
            engine TEXT, model TEXT, reported_model TEXT, expected_model TEXT,
            reasoning_effort TEXT, task_type TEXT, retry INTEGER, verdict TEXT,
            duration_ms INTEGER, worker_tokens INTEGER, orchestrator TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_attempts_model_task_type ON attempts(model, task_type);
        CREATE INDEX IF NOT EXISTS idx_attempts_logged_at ON attempts(logged_at);
        CREATE TABLE IF NOT EXISTS adjudications (
            id INTEGER PRIMARY KEY, run_id TEXT NOT NULL, task_key TEXT NOT NULL,
            logged_at TEXT, outcome TEXT NOT NULL, reason TEXT, adjudicator TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_adjudications_task
            ON adjudications(run_id, task_key, id);
        CREATE TABLE IF NOT EXISTS catalog_models (
            id TEXT PRIMARY KEY, name TEXT, context_length INTEGER, prompt_per_m REAL,
            completion_per_m REAL, free INTEGER, variable_pricing INTEGER,
            pricing_unknown INTEGER, fetched_at TEXT, modality TEXT
        );
        CREATE TABLE IF NOT EXISTS catalog_events (
            id INTEGER PRIMARY KEY, ts TEXT, kind TEXT, model_id TEXT, payload TEXT
        );
        CREATE TABLE IF NOT EXISTS identity (
            engine TEXT NOT NULL, model_key TEXT NOT NULL, model_display TEXT, lab TEXT,
            harness TEXT, access TEXT, alias INTEGER, confidence TEXT, source TEXT,
            last_verified TEXT, PRIMARY KEY (engine, model_key)
        );
        CREATE TABLE IF NOT EXISTS identity_defaults (
            engine TEXT PRIMARY KEY, default_model_key TEXT, harness TEXT, access TEXT
        );
        CREATE TABLE IF NOT EXISTS sync_state (key TEXT PRIMARY KEY, value TEXT);
        """
    )
    attempt_columns = {
        "reasoning_effort": "TEXT",
        "reported_model": "TEXT",
        "expected_model": "TEXT",
        "failure_class": "TEXT",
        "failure_owner": "TEXT",
        "model_eligible": "INTEGER",
    }
    for column, kind in attempt_columns.items():
        if not read_model_column_exists(conn, "attempts", column):
            conn.execute(f"ALTER TABLE attempts ADD COLUMN {column} {kind}")
    identity_columns = {"lab": "TEXT", "alias": "INTEGER", "last_verified": "TEXT"}
    for column, kind in identity_columns.items():
        if not read_model_column_exists(conn, "identity", column):
            conn.execute(f"ALTER TABLE identity ADD COLUMN {column} {kind}")
    if needs_stamp:
        conn.executescript(
            """
            DELETE FROM schema_version;
            INSERT INTO schema_version(version) VALUES (4);
            PRAGMA user_version = 4;
            """
        )


def drop_read_model_tables(conn: Any) -> None:
    conn.executescript(
        """
        DROP TABLE IF EXISTS attempts;
        DROP TABLE IF EXISTS adjudications;
        DROP TABLE IF EXISTS catalog_models;
        DROP TABLE IF EXISTS catalog_events;
        DROP TABLE IF EXISTS identity;
        DROP TABLE IF EXISTS identity_defaults;
        DROP TABLE IF EXISTS sync_state;
        DROP TABLE IF EXISTS schema_version;
        """
    )


def read_log_rows_from_offset(path: Path, offset: int) -> tuple[list[dict[str, Any]], int, int]:
    rows: list[dict[str, Any]] = []
    skipped = 0
    final_offset = offset
    try:
        with path.open("rb") as fh:
            fh.seek(offset)
            while True:
                line_start = fh.tell()
                raw_line = fh.readline()
                if not raw_line:
                    break
                if not raw_line.endswith(b"\n"):
                    final_offset = line_start
                    break
                final_offset = fh.tell()
                try:
                    row = json.loads(raw_line.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    skipped += 1
                    continue
                if not isinstance(row, dict):
                    skipped += 1
                    continue
                rows.append(row)
    except FileNotFoundError:
        return [], 0, 0
    return rows, skipped, final_offset


def insert_attempt_rows(conn: Any, rows: list[dict[str, Any]]) -> int:
    payloads: list[tuple[Any, ...]] = []
    adjudications: list[tuple[Any, ...]] = []
    for row in rows:
        if model_log_text(row.get("record_type")) == "adjudication":
            adjudications.append(
                tuple(
                    model_log_text(row.get(key))
                    for key in ("run_id", "task_key", "logged_at", "outcome", "reason", "adjudicator")
                )
            )
            continue
        payloads.append(
            (
                model_log_text(row.get("run_id")),
                model_log_text(row.get("task_key")),
                model_log_text(row.get("logged_at")),
                model_log_row_engine(row),
                model_log_text(row.get("model")),
                model_log_text(row.get("reported_model")) or None,
                model_log_text(row.get("expected_model")) or None,
                model_log_row_reasoning_effort(row),
                model_log_text(row.get("task_type")),
                1 if model_log_row_is_retry(row) else 0,
                model_log_text(row.get("verdict")),
                model_log_int(row.get("duration_ms")),
                model_log_int(row.get("worker_tokens")),
                model_log_text(row.get("orchestrator")),
                model_log_text(row.get("failure_class")) or None,
                model_log_text(row.get("failure_owner")) or None,
                1 if model_log_row_is_model_eligible(row) else 0,
            )
        )
    if payloads:
        conn.executemany(
            """
            INSERT INTO attempts (
                run_id, task_key, logged_at, engine, model, reported_model, expected_model,
                reasoning_effort, task_type, retry, verdict, duration_ms, worker_tokens,
                orchestrator, failure_class, failure_owner, model_eligible
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            payloads,
        )
    if adjudications:
        conn.executemany(
            """
            INSERT INTO adjudications (run_id, task_key, logged_at, outcome, reason, adjudicator)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            adjudications,
        )
    return len(payloads) + len(adjudications)


def read_sync_state_value(conn: Any, key: str) -> str | None:
    row = conn.execute("SELECT value FROM sync_state WHERE key = ?", (key,)).fetchone()
    return None if row is None else str(row["value"])


def read_sync_state_int(conn: Any, key: str, default: int = 0) -> int:
    value = read_sync_state_value(conn, key)
    try:
        return default if value is None else int(value)
    except ValueError:
        return default


def write_sync_state_values(conn: Any, values: dict[str, int | str]) -> None:
    conn.executemany(
        "INSERT OR REPLACE INTO sync_state(key, value) VALUES (?, ?)",
        [(key, str(value)) for key, value in values.items()],
    )


@dataclass(frozen=True)
class ReadModelSyncResult:
    db_path: Path
    log_path: Path
    attempts_inserted: int
    skipped: int
    offset: int
    rebuilt: bool


def rebuild_read_model_db(
    db_path: Path,
    log_path: Path,
    *,
    catalog_path: Path | None = None,
    registry_path: Path | None = None,
) -> ReadModelSyncResult:
    db_path = db_path.expanduser().resolve()
    log_path = log_path.expanduser().resolve()
    catalog_path = (catalog_path or default_catalog_path()).expanduser().resolve()
    registry_path = (registry_path or default_model_registry_path()).expanduser().resolve()
    with contextlib.closing(connect_read_model_db(db_path)) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            drop_read_model_tables(conn)
            create_read_model_schema(conn)
            rows, skipped, offset = read_log_rows_from_offset(log_path, 0)
            inserted = insert_attempt_rows(conn, rows)
            refresh_catalog_tables(conn, catalog_path)
            refresh_identity_tables(conn, registry_path)
            write_sync_state_values(conn, {"log_offset": offset})
            conn.commit()
        except Exception:
            conn.rollback()
            raise
    return ReadModelSyncResult(db_path, log_path, inserted, skipped, offset, True)


def sync_read_model_db(
    db_path: Path,
    log_path: Path,
    *,
    catalog_path: Path | None = None,
    registry_path: Path | None = None,
) -> ReadModelSyncResult:
    db_path = db_path.expanduser().resolve()
    log_path = log_path.expanduser().resolve()
    catalog_path = (catalog_path or default_catalog_path()).expanduser().resolve()
    registry_path = (registry_path or default_model_registry_path()).expanduser().resolve()
    try:
        log_size = log_path.stat().st_size
    except FileNotFoundError:
        log_size = 0
    with contextlib.closing(connect_read_model_db(db_path)) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            create_read_model_schema(conn)
            offset = read_sync_state_int(conn, "log_offset", 0)
            if log_size < offset:
                conn.rollback()
                return rebuild_read_model_db(
                    db_path,
                    log_path,
                    catalog_path=catalog_path,
                    registry_path=registry_path,
                )
            rows, skipped, new_offset = read_log_rows_from_offset(log_path, offset)
            inserted = insert_attempt_rows(conn, rows)
            refresh_catalog_tables(conn, catalog_path)
            refresh_identity_tables(conn, registry_path)
            write_sync_state_values(conn, {"log_offset": new_offset})
            conn.commit()
        except Exception:
            conn.rollback()
            raise
    return ReadModelSyncResult(db_path, log_path, inserted, skipped, new_offset, False)


def db_catalog_models(db_path: Path) -> list[dict[str, Any]]:
    return _db_catalog_models(db_path, connect_read_model_db_readonly)


def db_catalog_events(db_path: Path, *, limit: int = 20) -> list[dict[str, Any]]:
    return _db_catalog_events(db_path, connect_read_model_db_readonly, limit=limit)
