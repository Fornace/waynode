"""Public facade for Hammersmith failure intelligence.

Implementation lives in focused summary, model, and taxonomy modules. Imports from
this module remain the stable compatibility API.
"""
from __future__ import annotations

# Keep the dependency types and helpers that this module historically exposed.
from .config_models import FailureSummaryConfig
from .manifest_models import TaskSpec
from .prompt import compile_worker_prompt
from .runtime import VerifyResult, WorkerResult
from .utils.io import parse_env_file

from hammersmith.failure_models import FailureAssessment
from hammersmith.failure_summary import (
    LiteLLMFailureSummarizer,
    bounded_failure_excerpt,
    redact_environment_credentials,
)
from hammersmith.failure_taxonomy import (
    ENGINE_CIRCUIT_FAILURE_CLASSES,
    ENGINE_CIRCUIT_THRESHOLD,
    FAILURE_CLASSES,
    RETRYABLE_FAILURE_CLASSES,
    classify_failure,
    compile_retry_spec,
    failure_fingerprint,
    verdict_for,
)

__all__ = [
    "ENGINE_CIRCUIT_FAILURE_CLASSES",
    "ENGINE_CIRCUIT_THRESHOLD",
    "FAILURE_CLASSES",
    "RETRYABLE_FAILURE_CLASSES",
    "FailureAssessment",
    "FailureSummaryConfig",
    "LiteLLMFailureSummarizer",
    "TaskSpec",
    "VerifyResult",
    "WorkerResult",
    "bounded_failure_excerpt",
    "classify_failure",
    "compile_retry_spec",
    "compile_worker_prompt",
    "failure_fingerprint",
    "parse_env_file",
    "redact_environment_credentials",
    "verdict_for",
]
