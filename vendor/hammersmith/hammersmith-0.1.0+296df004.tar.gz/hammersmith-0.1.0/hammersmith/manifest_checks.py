"""Shell and manifest contract heuristics."""
from __future__ import annotations

import re
import shlex
from pathlib import Path

FILE_TEST_OPS = {"-e", "-f", "-d", "-s", "-r", "-w", "-x", "-L"}

FILE_POINTER_SPEC_RE = re.compile(
    r"\b(read|open|follow|see)\b[^\n.]{0,100}?/[\w~][\w./~-]*",
    re.IGNORECASE,
)


def spec_is_file_pointer(spec: str) -> bool:
    """True when the spec's substance lives in some other file.

    'Read /path/to/instructions.md and do what it says' hides the brief from
    everyone watching the run and starves the retry prompt. Long specs that
    merely reference files for CONTEXT are fine; the heuristic only fires
    when the spec is short enough that the pointer must be the whole plan.
    """
    text = spec.strip()
    if re.search(r"do (exactly )?what (it|the file|that file) says", text, re.IGNORECASE):
        return True
    if len(text) >= 600:
        return False
    return bool(FILE_POINTER_SPEC_RE.search(text))


def check_cannot_fail(check: str) -> bool:
    stripped = strip_shell_comments(check).strip()
    if stripped in {"true", ":", "exit 0"}:
        return True
    return consists_only_of_echo_commands(stripped)


def strip_shell_comments(command: str) -> str:
    result: list[str] = []
    in_single = False
    in_double = False
    escaped = False
    i = 0
    while i < len(command):
        char = command[i]
        if escaped:
            result.append(char)
            escaped = False
            i += 1
            continue
        if char == "\\" and not in_single:
            result.append(char)
            escaped = True
            i += 1
            continue
        if char == "'" and not in_double:
            in_single = not in_single
            result.append(char)
            i += 1
            continue
        if char == '"' and not in_single:
            in_double = not in_double
            result.append(char)
            i += 1
            continue
        if (
            char == "#"
            and not in_single
            and not in_double
            and (not result or result[-1].isspace())
        ):
            while i < len(command) and command[i] != "\n":
                i += 1
            continue
        result.append(char)
        i += 1
    return "".join(result)


def consists_only_of_echo_commands(command: str) -> bool:
    if not command or "||" in command or re.search(r"[|<>]", command):
        return False
    parts = [part.strip() for part in re.split(r"(?:&&|;|\n)+", command) if part.strip()]
    if not parts:
        return False
    for part in parts:
        try:
            tokens = shlex.split(part)
        except ValueError:
            return False
        if not tokens or tokens[0] != "echo":
            return False
    return True


def check_may_fail_silently(check: str) -> bool:
    stripped = strip_shell_comments(check).strip()
    if has_quiet_diff_probe(stripped):
        return not has_failure_output_branch(stripped)
    if not stripped or "||" in stripped:
        return False
    if re.search(r"(?:;|\n|\|)", stripped):
        return False
    parts = [part.strip() for part in stripped.split("&&") if part.strip()]
    return bool(parts) and all(is_silent_probe(part) for part in parts)


def has_quiet_diff_probe(command: str) -> bool:
    return any(has_command_prefix(part, ("diff", "-q")) for part in command_parts(command))


def has_failure_output_branch(command: str) -> bool:
    if "||" not in command:
        return False
    branch = command.split("||", 1)[1]
    return any(
        has_command_prefix(part, (prefix,))
        for part in command_parts(branch)
        for prefix in ("echo", "printf", "cat", "diff", "ls")
    )


def command_parts(command: str) -> list[str]:
    return [part.strip(" \t{}()") for part in re.split(r"(?:&&|\|\||;|\n)+", command) if part.strip()]


def has_command_prefix(command: str, prefix: tuple[str, ...]) -> bool:
    try:
        tokens = shlex.split(strip_common_redirections(command))
    except ValueError:
        return False
    return len(tokens) >= len(prefix) and tuple(tokens[: len(prefix)]) == prefix


def is_silent_probe(command: str) -> bool:
    return is_file_existence_test(command) or is_quiet_grep(command)


def is_quiet_grep(command: str) -> bool:
    command = strip_common_redirections(command.strip())
    try:
        tokens = shlex.split(command)
    except ValueError:
        return False
    return bool(tokens) and tokens[0] == "grep" and any(
        token == "-q" or (token.startswith("-") and "q" in token[1:]) for token in tokens[1:]
    )


def is_file_existence_test(command: str) -> bool:
    command = strip_common_redirections(command.strip())
    try:
        tokens = shlex.split(command)
    except ValueError:
        return False
    if len(tokens) >= 3 and tokens[0] == "test" and tokens[1] in FILE_TEST_OPS:
        return True
    return len(tokens) >= 4 and tokens[0] == "[" and tokens[1] in FILE_TEST_OPS and tokens[-1] == "]"


def strip_common_redirections(command: str) -> str:
    command = re.sub(r"\s+\d?>&\d+\s*$", "", command)
    command = re.sub(r"\s+\d?>\S+\s*$", "", command)
    return command.strip()


def is_relative_expect_file(path: str) -> bool:
    return bool(path.strip()) and not path.startswith("~") and not Path(path).is_absolute()


def instructs_git_commit(spec: str) -> bool:
    lower = spec.lower()
    start = 0
    while True:
        index = lower.find("git commit", start)
        if index == -1:
            return False
        prefix = lower[max(0, index - 48) : index]
        if not is_negated_git_commit(prefix):
            return True
        start = index + len("git commit")


def is_negated_git_commit(prefix: str) -> bool:
    separators = r"[\s`'\"()\[\]{}:;,.!?-]*"
    return bool(
        re.search(
            rf"(?:do\s+not|don't|never|no){separators}(?:run{separators})?$",
            prefix,
        )
    )
