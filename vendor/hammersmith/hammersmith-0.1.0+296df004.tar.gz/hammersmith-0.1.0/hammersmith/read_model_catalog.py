"""OpenRouter catalog persistence for the SQLite read model."""

from __future__ import annotations

import contextlib
import json
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Callable

from hammersmith.eval_logging import model_log_int, model_log_text
from hammersmith.identity import environment_setting


STATE_DIR_NAME = ".hammersmith"


def hammersmith_home() -> Path:
    value = environment_setting("HOME")
    if value and value.strip():
        return Path(value).expanduser().resolve()
    return (Path.home() / STATE_DIR_NAME).resolve()


def default_catalog_path() -> Path:
    return hammersmith_home() / "openrouter-catalog.json"


def catalog_changes_path(snapshot_path: Path) -> Path:
    text = str(snapshot_path)
    if text.endswith(".json"):
        return Path(text[:-5] + ".changes.jsonl")
    return snapshot_path.with_name(snapshot_path.name + ".changes.jsonl")


def load_catalog_snapshot(path: Path) -> list[dict[str, Any]]:
    try:
        data = json.loads(path.expanduser().read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    models = data.get("models") if isinstance(data, dict) else data
    if not isinstance(models, list):
        return []
    return [item for item in models if isinstance(item, dict)]


def _catalog_decimal_or_none(value: Any) -> Decimal | None:
    if value is None:
        return None
    try:
        text = str(value).strip()
        return Decimal(text) if text else None
    except (InvalidOperation, ValueError):
        return None


def normalize_catalog_model(raw: dict[str, Any], *, fetched_at: str) -> dict[str, Any]:
    pricing = raw.get("pricing")
    pricing_obj = pricing if isinstance(pricing, dict) else {}
    architecture = raw.get("architecture")
    architecture_obj = architecture if isinstance(architecture, dict) else {}
    model_id = str(raw.get("id", "")).strip()
    prompt_price = _catalog_decimal_or_none(pricing_obj.get("prompt"))
    completion_price = _catalog_decimal_or_none(pricing_obj.get("completion"))
    pricing_unknown = prompt_price is None or completion_price is None
    variable_pricing = pricing_unknown or prompt_price < 0 or completion_price < 0
    prompt_per_m = None if variable_pricing else float(prompt_price * Decimal("1000000"))
    completion_per_m = (
        None if variable_pricing else float(completion_price * Decimal("1000000"))
    )
    is_free = not variable_pricing and (
        model_id.endswith(":free") or (prompt_price == 0 and completion_price == 0)
    )
    if model_id.endswith(":free"):
        is_free = True
    try:
        context_length = int(raw.get("context_length"))
    except (TypeError, ValueError):
        context_length = 0
    return {
        "id": model_id,
        "name": str(raw.get("name", "")).strip() or model_id,
        "context_length": context_length,
        "modality": str(architecture_obj.get("modality", "")).strip(),
        "pricing": dict(pricing_obj),
        "prompt_per_m": prompt_per_m,
        "completion_per_m": completion_per_m,
        "variable_pricing": variable_pricing,
        "pricing_unknown": pricing_unknown,
        "free": is_free,
        "fetched_at": fetched_at,
    }


def normalize_catalog_for_scoreboard(model: dict[str, Any]) -> dict[str, Any]:
    if "prompt_per_m" in model and "completion_per_m" in model:
        return model
    if isinstance(model.get("pricing"), dict):
        return normalize_catalog_model(model, fetched_at=str(model.get("fetched_at") or ""))
    return model


def _sync_value(conn: Any, key: str) -> str | None:
    row = conn.execute("SELECT value FROM sync_state WHERE key = ?", (key,)).fetchone()
    return None if row is None else str(row["value"])


def _sync_int(conn: Any, key: str, default: int = 0) -> int:
    value = _sync_value(conn, key)
    try:
        return default if value is None else int(value)
    except ValueError:
        return default


def _write_sync_values(conn: Any, values: dict[str, int | str]) -> None:
    conn.executemany(
        "INSERT OR REPLACE INTO sync_state(key, value) VALUES (?, ?)",
        [(key, str(value)) for key, value in values.items()],
    )


def _file_metadata(path: Path) -> tuple[int, int]:
    try:
        stat = path.expanduser().stat()
    except FileNotFoundError:
        return -1, 0
    return int(stat.st_mtime_ns), int(stat.st_size)


def _read_events(path: Path, offset: int) -> tuple[list[dict[str, Any]], int]:
    events: list[dict[str, Any]] = []
    final_offset = offset
    try:
        with path.expanduser().open("rb") as fh:
            fh.seek(offset)
            while True:
                line_start = fh.tell()
                raw_line = fh.readline()
                if not raw_line:
                    break
                if not raw_line.endswith(b"\n"):
                    final_offset = line_start
                    break
                final_offset = fh.tell()
                try:
                    event = json.loads(raw_line.decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
                if isinstance(event, dict):
                    events.append(event)
    except FileNotFoundError:
        return [], 0
    return events, final_offset


def _insert_events(conn: Any, events: list[dict[str, Any]]) -> int:
    payloads = [
        (
            model_log_text(event.get("ts")),
            model_log_text(event.get("kind")),
            model_log_text(event.get("id")),
            json.dumps(event, sort_keys=True),
        )
        for event in events
    ]
    if payloads:
        conn.executemany(
            "INSERT INTO catalog_events(ts, kind, model_id, payload) VALUES (?, ?, ?, ?)",
            payloads,
        )
    return len(payloads)


def refresh_catalog_tables(conn: Any, catalog_path: Path) -> None:
    catalog_path = catalog_path.expanduser().resolve()
    changes_path = catalog_changes_path(catalog_path)
    catalog_mtime, catalog_size = _file_metadata(catalog_path)
    changes_mtime, changes_size = _file_metadata(changes_path)
    catalog_unchanged = (
        _sync_int(conn, "catalog_snapshot_mtime_ns", -2) == catalog_mtime
        and _sync_int(conn, "catalog_snapshot_size", -2) == catalog_size
    )
    changes_unchanged = (
        _sync_int(conn, "catalog_changes_mtime_ns", -2) == changes_mtime
        and _sync_int(conn, "catalog_changes_size", -2) == changes_size
    )
    if catalog_unchanged and changes_unchanged:
        return

    if not catalog_unchanged:
        conn.execute("DELETE FROM catalog_models")
        try:
            models = load_catalog_snapshot(catalog_path)
        except (OSError, json.JSONDecodeError, ValueError):
            models = []
        payloads: list[tuple[Any, ...]] = []
        for model in models:
            normalized = normalize_catalog_for_scoreboard(model)
            model_id = model_log_text(normalized.get("id"))
            if model_id:
                payloads.append(
                    (
                        model_id,
                        model_log_text(normalized.get("name")),
                        model_log_int(normalized.get("context_length")),
                        normalized.get("prompt_per_m"),
                        normalized.get("completion_per_m"),
                        1 if normalized.get("free") else 0,
                        1 if normalized.get("variable_pricing") else 0,
                        1 if normalized.get("pricing_unknown") else 0,
                        model_log_text(normalized.get("fetched_at")),
                        model_log_text(normalized.get("modality")),
                    )
                )
        if payloads:
            conn.executemany(
                """
                INSERT INTO catalog_models (
                    id, name, context_length, prompt_per_m, completion_per_m, free,
                    variable_pricing, pricing_unknown, fetched_at, modality
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                payloads,
            )
        _write_sync_values(
            conn,
            {"catalog_snapshot_mtime_ns": catalog_mtime, "catalog_snapshot_size": catalog_size},
        )

    if not changes_unchanged:
        prior_mtime = _sync_value(conn, "catalog_changes_mtime_ns")
        prior_size = _sync_int(conn, "catalog_changes_size", 0)
        prior_offset = _sync_int(conn, "catalog_changes_offset", 0)
        append_only = (
            prior_mtime is not None
            and changes_size >= prior_size
            and prior_offset <= changes_size
        )
        if append_only:
            events, new_offset = _read_events(changes_path, prior_offset)
        else:
            conn.execute("DELETE FROM catalog_events")
            events, new_offset = _read_events(changes_path, 0)
        _insert_events(conn, events)
        _write_sync_values(
            conn,
            {
                "catalog_changes_mtime_ns": changes_mtime,
                "catalog_changes_size": changes_size,
                "catalog_changes_offset": new_offset,
            },
        )


def db_catalog_models(db_path: Path, connector: Callable[[Path], Any]) -> list[dict[str, Any]]:
    with contextlib.closing(connector(db_path)) as conn:
        return [
            {
                "id": row["id"],
                "name": row["name"],
                "context_length": row["context_length"],
                "prompt_per_m": row["prompt_per_m"],
                "completion_per_m": row["completion_per_m"],
                "free": bool(row["free"]),
                "variable_pricing": bool(row["variable_pricing"]),
                "pricing_unknown": bool(row["pricing_unknown"]),
                "fetched_at": row["fetched_at"],
                "modality": row["modality"],
            }
            for row in conn.execute("SELECT * FROM catalog_models ORDER BY id")
        ]


def db_catalog_events(
    db_path: Path, connector: Callable[[Path], Any], *, limit: int = 20
) -> list[dict[str, Any]]:
    with contextlib.closing(connector(db_path)) as conn:
        rows = conn.execute(
            "SELECT payload FROM catalog_events ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    events: list[dict[str, Any]] = []
    for row in rows:
        try:
            event = json.loads(row["payload"])
        except (TypeError, json.JSONDecodeError):
            continue
        if isinstance(event, dict):
            events.append(event)
    return events
