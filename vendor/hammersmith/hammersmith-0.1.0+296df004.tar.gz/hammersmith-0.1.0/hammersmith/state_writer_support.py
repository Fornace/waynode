"""Artifact persistence support mixed into :class:`StateWriter`."""

from __future__ import annotations

import sys
import time
from typing import Any

from .artifacts.briefing import collect_state_deliverables
from .artifacts.library import (
    append_artifact_library_version,
    artifact_outcome_from_state,
    reconcile_artifact_library_dead_runs,
    update_artifact_library_live,
)
from .run_state import scan_run_states
from .state_io import atomic_write_json, atomic_write_text, interprocess_lock


class StateWriterSupport:
    """Non-fatal artifact and library writes kept separate from state projection."""

    def _write_status_artifact_safe(self, state: dict[str, Any]) -> None:
        try:
            if bool(state.get("finished")) or str(state.get("state")) == "finished":
                artifact_html = self.artifact_renderer.render_final_report_html(
                    state, page_path=self.artifact_path
                )
                live_html = self.artifact_renderer.render_final_report_html(
                    state, page_path=self.live_path
                )
            else:
                artifact_html = self.artifact_renderer.render_status_html(
                    state, page_path=self.artifact_path
                )
                live_html = self.artifact_renderer.render_status_html(
                    state, page_path=self.live_path
                )
            atomic_write_text(self.artifact_path, artifact_html)
            atomic_write_text(self.live_path, live_html)
        except Exception as exc:
            print(f"artifact render error (status page, non-fatal): {exc}", file=sys.stderr)

    def _write_final_report_safe(self, state: dict[str, Any]) -> None:
        if not self.artifact.enabled:
            return
        try:
            report_html = self.artifact_renderer.render_final_report_html(
                state, page_path=self.report_path
            )
            version_html = self.artifact_renderer.render_final_report_html(
                state, page_path=self.version_path
            )
            atomic_write_text(self.report_path, report_html)
            atomic_write_text(self.version_path, version_html)
            self.report_written = True
            self._append_library_version_safe(state)
            state = dict(state)
            state["report_ready"] = True
            with interprocess_lock(self.state_dir / ".state.lock"):
                atomic_write_json(self.path, state)
        except Exception as exc:
            print(f"artifact render error (final report, non-fatal): {exc}", file=sys.stderr)

    def _write_library_live_safe(self, state: dict[str, Any]) -> None:
        outcome = artifact_outcome_from_state(state)
        now = time.monotonic()
        if self._last_library_state == outcome and now - self._last_library_write_monotonic < 5:
            return
        try:
            update_artifact_library_live(
                self.state_dir,
                run_name=self.run_name,
                run_id=self.run_id,
                identity=self.identity,
                state=outcome,
                project=self.project,
            )
            self._last_library_state = outcome
            self._last_library_write_monotonic = now
        except Exception as exc:
            print(f"artifact library update error (non-fatal): {exc}", file=sys.stderr)

    def _append_library_version_safe(self, state: dict[str, Any]) -> None:
        if self.version_recorded:
            return
        totals = state.get("totals") if isinstance(state.get("totals"), dict) else {}
        outcome = artifact_outcome_from_state(state)
        try:
            append_artifact_library_version(
                self.state_dir,
                run_name=self.run_name,
                run_id=self.run_id,
                identity=self.identity,
                outcome=outcome,
                project=self.project,
                version_path=self.version_path,
                report_path=self.report_path if self.report_path != self.version_path else None,
                tasks_pass=int(totals.get("pass", state.get("pass", 0)) or 0),
                tasks_fail=int(totals.get("fail", state.get("fail", 0)) or 0),
                deliverables=collect_state_deliverables(state),
            )
            self.version_recorded = True
            self._last_library_state = outcome
            self._last_library_write_monotonic = time.monotonic()
        except Exception as exc:
            print(f"artifact library version error (non-fatal): {exc}", file=sys.stderr)

    def _reconcile_library_safe(self) -> None:
        try:
            reconcile_artifact_library_dead_runs(self.state_dir)
        except Exception as exc:
            print(f"artifact library reconcile error (non-fatal): {exc}", file=sys.stderr)

    def _write_index_safe(self) -> None:
        try:
            entries = scan_run_states(self.state_dir)
            html = self.artifact_renderer.render_artifact_index_html(entries)
            atomic_write_text(self.artifact.index_out, html)
        except Exception as exc:
            print(f"artifact render error (index, non-fatal): {exc}", file=sys.stderr)
