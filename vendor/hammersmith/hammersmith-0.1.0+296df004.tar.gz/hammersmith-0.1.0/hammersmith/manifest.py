"""Public facade for manifest models and lint helpers.

Implementations live in focused modules; imports from ``hammersmith.manifest``
remain stable for callers.
"""

from __future__ import annotations

from .config_models import DEFAULT_ENGINE_NAME
from .constants import (
    DEFAULT_SHARED_CHECK_TIMEOUT_S, DEFAULT_TIMEOUT_S, MODEL_SCOREBOARD_RUN_NAME,
)
from .identity import environment_setting
from .manifest_checks import (
    check_cannot_fail, check_may_fail_silently, instructs_git_commit,
    is_relative_expect_file, spec_is_file_pointer,
)
from .utils.activity import shorten

from .manifest_lint import (
    FILE_TEST_OPS,
    LintFinding,
    _lint_manifest_warnings,
    contract_path_covers,
    lint_manifest,
    lint_manifest_detailed,
    normalize_contract_path,
    owned_paths_overlap,
    resolve_manifest_path,
    sha256_file,
    structural_manifest_findings,
)
from .manifest_models import (
    HIERARCHY_ENV_FIELDS,
    MANIFEST_FIELDS,
    TASK_SPEC_FIELDS,
    InputPatch,
    Manifest,
    TaskSpec,
    optional_manifest_string,
)

__all__ = [
    "DEFAULT_ENGINE_NAME",
    "DEFAULT_SHARED_CHECK_TIMEOUT_S",
    "DEFAULT_TIMEOUT_S",
    "FILE_TEST_OPS",
    "HIERARCHY_ENV_FIELDS",
    "MANIFEST_FIELDS",
    "MODEL_SCOREBOARD_RUN_NAME",
    "TASK_SPEC_FIELDS",
    "InputPatch",
    "LintFinding",
    "Manifest",
    "TaskSpec",
    "check_cannot_fail",
    "check_may_fail_silently",
    "contract_path_covers",
    "environment_setting",
    "instructs_git_commit",
    "is_relative_expect_file",
    "lint_manifest",
    "lint_manifest_detailed",
    "normalize_contract_path",
    "optional_manifest_string",
    "owned_paths_overlap",
    "resolve_manifest_path",
    "sha256_file",
    "shorten",
    "spec_is_file_pointer",
    "structural_manifest_findings",
]
