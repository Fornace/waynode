# Hammersmith

![Hammersmith: verified agent orchestration](docs/hero.png)

**Define verifiable work. Hammersmith keeps hammering until the checks decide it.**

Give Hammersmith an explicit manifest of tasks, ownership boundaries, and executable checks. It runs the work in parallel and delivers artifacts whose checks actually pass.

Most AI tools stop at advice. Hammersmith is different. It runs your manifest tasks in parallel with AI workers and **executes your check command** against every result. Pass or fail is decided by running the code, not by reading the agent's summary. When something fails, Hammersmith classifies the cause and retries with the exact failure context — not a vague "try again."

Your best model plans and reviews. A swarm of workers (Codex, Grok, anything with a CLI) does the implementation in parallel. Your premium budget scales with decisions made, not lines of code written.

A swarm you can't see is a swarm you can't trust. **Hammersmith** opens a local dashboard with every run. It shows projects, nested swarms, workers, elapsed time, token burn, checks, causal failures, and versioned artifacts in real time.

## Installation

Hammersmith runs on macOS and Linux (Windows via WSL) and needs Python 3.11+.

### Install from source

```bash
git clone https://github.com/Fornace/hammersmith.git && cd hammersmith
python3 -m pip install -e .
```

This installs the `hammersmith` command globally. You can now run it from anywhere:

```bash
hammersmith --help
```

### Configure (optional)

```bash
mkdir -p ~/.config/hammersmith
cp config.sample.toml ~/.config/hammersmith/config.toml
```

Edit the config to set up your preferred engines, models, and other settings.

### Install a worker CLI

Hammersmith needs at least one worker CLI to execute tasks. Pi is the built-in default:

```bash
npm install -g @earendil-works/pi-coding-agent   # or: brew install pi
# Set your API key (pick your provider)
export GOOGLE_API_KEY="your-key"  # for Google models
# or: export OPENAI_API_KEY="your-key"
# or: export ANTHROPIC_API_KEY="your-key"
```

Other supported engines: Codex CLI, Grok Build CLI, OpenCode + OpenRouter. See [Engine Reference](docs/ENGINE-REFERENCE.md) for details.

## Quickstart

**No config file needed.** Hammersmith auto-detects your installed worker CLIs and uses sensible defaults for everything.

### 1. Install a worker CLI (if you haven't already)

```bash
npm install -g @earendil-works/pi-coding-agent   # Pi (recommended default)
export GOOGLE_API_KEY="your-key"                  # or OPENAI_API_KEY, ANTHROPIC_API_KEY
```

### 2. (Optional) Create a config

```bash
hammersmith init    # creates ~/.config/hammersmith/config.toml with defaults
```

You can skip this entirely — Hammersmith works with zero configuration.

### 3. Run the verified demo

```bash
hammersmith demo
```

The demo creates a three-task manifest, runs the tasks in parallel, executes each check, and opens the live dashboard. Once that passes, run your own manifest with `hammersmith run manifest.json`.

### Dashboard login
The local dashboard stays open until you create the first admin. Enable authentication with:
```bash
hammersmith user create admin --role admin
hammersmith hud
```
Hammersmith prompts for the password. Once an admin exists, dashboard pages and APIs require login. Manage accounts with `hammersmith user list`, `hammersmith user reset-password USERNAME`, and `hammersmith user delete USERNAME`.

### Run the demo

Want to see how it works first?

```bash
hammersmith demo                                      # 3 real workers, verified end to end
```

The demo spawns three Codex workers in parallel, verifies each artifact by executing it, and prints a verdict table. Hammersmith, the live dashboard, opens in your browser on its own. If all three say PASS, that's the whole setup.

### Run your own manifest

Write a manifest to make the task contract, ownership, retries, and checks explicit:

```bash
hammersmith run swarm.json --max-parallel 4
```

```json
{
  "run_name": "my-batch",
  "workdir": "/tmp/my-batch",
  "max_parallel": 3,
  "tasks": [
    {
      "key": "alpha",
      "spec": "Create alpha.txt containing exactly: alpha ready",
      "check": "test \"$(cat alpha.txt)\" = \"alpha ready\"",
      "expect_files": ["alpha.txt"]
    }
  ]
}
```

Each task gets its own directory, its own worker, its own log, and its own verdict. `check` is any shell command. Exit 0 is the only thing Hammersmith believes.

> **Write checks that print why they fail.** A silent `exit 1` (the `git diff --quiet` style) costs you twice: the retry prompt gets no failure context to fix against, and the eval log records an undiagnosable row. `diff` beats `diff -q`; an assert with a message beats a bare test.

When a worker pipes a test or guard through `tail`, `tee`, or another consumer,
it must enable `set -o pipefail` (or explicitly preserve the producer's status).
Otherwise the consumer can return zero while the test failed. Hammersmith injects
this rule into every worker contract and still runs the authoritative check itself.

Long failed-check output can optionally be condensed by an ultra-cheap model via
`[failure_summary]` in `config.toml`. This is fail-open and explanatory only: the
original exit code, timeout, missing outputs, and scope checks decide the verdict.
The feature is disabled by default because it sends redacted check text to the
configured OpenAI-compatible endpoint; credentials are referenced from environment
variables or an environment file. See `config.sample.toml` for the complete block.

**Identity**: runs are stamped with an orchestrator identity (shown in Hammersmith and eval rows). Resolution order: `--identity` > `HAMMERSMITH_IDENTITY` > `FLEET_IDENTITY` > a `.fleet-agent` file found walking up from the working directory (drop one in a repo root to give that repo's swarms their own name) > `identity_default` in config > short hostname.

### Manifest fields

The example above shows the smallest useful task contract. The complete field-by-field reference covers task ownership and inputs, exact layouts, run hierarchy, shared integration checks, inherited hierarchy variables, advisory routing suggestions, and the worktree lifecycle: [Manifest reference](docs/MANIFEST-REFERENCE.md).

Not sure what your tasks are yet? [`docs/interview-prompt.md`](docs/interview-prompt.md) is a prompt you can give your orchestrating agent. It interviews you about the job and produces a brief that can be compiled into an explicit manifest. Ready-made skeletons for proven patterns live in [`templates/`](templates/).

## Lint

Lint catches manifest mistakes before any worker starts, so your swarm is reliable from the first run. It checks for tests that cannot fail, silent checks, worktree deliverables that disappear, worker commits that die with deleted worktrees, serial fan-out, write collisions, and underspecified specs.

```bash
hammersmith lint templates/review-swarm/manifest.json
lint: clean (1 tasks)
```

### Migrate legacy manifests without weakening lint

Older manifests accepted several campaign-specific keys by silently discarding
them. Hammersmith keeps the strict schema and provides a separate, fail-closed
migration preview:

```bash
hammersmith migrate-manifest path/to/legacy.json
hammersmith migrate-manifest path/to/legacy.json --output path/to/hammersmith.json
```

The default is a dry run and never changes the source. `--output` must name a
different file; an existing output also requires `--force`. The command only
translates aliases whose meaning is deterministic:

- `executed_check_proof` becomes `verified`;
- `patch_export_path` and `report_export_path` are added to `expect_files`.

Conflicting canonical values, prose stored in path fields, patch files hidden in
`required_inputs`, incomplete `input_patches`, and missing parallel-frontend
`shared_check` contracts block output. The report gives the exact JSON location
and required manual action. It never guesses whether prose is an input, output,
prohibition, patch policy, or executable integration check. Use `--json` for a
machine-readable `hammersmith.manifest-migration.v1` report. See
[`docs/MANIFEST-MIGRATION.md`](docs/MANIFEST-MIGRATION.md) for the complete
review workflow.

`run` and `demo` also print lint findings after the manifest loads. Ordinary quality findings remain non-blocking warnings for backward compatibility. Structural contract errors block before any model starts: unknown task fields, outputs outside ownership, overlapping concurrent ownership, missing/mismatched/unapplicable input patches, a shared check that cannot fail, or multiple explicitly typed parallel frontend tasks without a shared check. Use `run --strict` to block on warnings too.

Every worker receives a compiled contract on its first attempt, including the exact check command, what passing proves, declared inputs/outputs, ownership boundaries, and patch materialization. Workers no longer have to fail once to discover the executable check.

The compiled contract also keeps the orchestration boundary explicit: an
ordinary worker already running under Hammersmith must not start Restate,
Trigger.dev, nested Hammersmith runs, background watchers, or
task-specific MCP servers. A task explicitly typed as orchestration may launch
only the child Hammersmith runs its specification authorizes. Hammersmith owns
persistence, timeouts, logs, hierarchy, and verification throughout.

An exact repair task can declare its envelope directly:

```json
{
  "owned_paths": ["src/auth/", "tests/test_auth.py"],
  "forbidden_paths": ["src/billing/"],
  "required_inputs": ["src/auth/service.py"],
  "expected_outputs": ["src/auth/security.py", "tests/test_auth.py"],
  "input_patches": [
    {"path": "patches/auth-base.patch", "sha256": "<64 hex characters>", "apply": true}
  ],
  "layout_policy": "exact",
  "max_attempts": 2
}
```

Unknown task keys are rejected rather than silently ignored. This is intentional: a misspelled authority field must never look active in a manifest while disappearing before worker launch.

Unknown run-level manifest keys are rejected for the same reason. Existing
manifests remain valid because all hierarchy fields are optional.

For parallel frontend work, declare one fast shared smoke instead of copying it
into every task:

```json
{
  "shared_check": "cd forgia/frontend && npm test -- navigation.test.tsx",
  "shared_check_timeout_s": 120
}
The task check remains authoritative for its owned implementation. Candidate
exports are copied to the artifact library immediately after that check passes,
before the shared smoke runs, so a later integration failure or failed sibling
cannot erase useful work. `integration_ready` becomes true only after both
checks pass.

A check that cannot fail is trusting the worker with extra steps.

## Make your agent actually use this

Between swarms, agents drift back to invisible inline work. Reminders fade, so Hammersmith includes built-in enforcement.

Run one command:

```bash
hammersmith install-agent                 # auto-detects Claude Code, Pi, Codex, OpenCode
hammersmith install-agent --target pi --target codex   # ...or pick specific ones
hammersmith install-agent --project      # Claude Code at ./.claude (repo-local)
hammersmith uninstall-agent              # remove everywhere
```

It installs the Hammersmith skill (the orchestrator playbook) into every
orchestrating harness it detects — **Claude Code** (`~/.claude/skills/`), **Pi**
(`~/.pi/agent/skills/`), **Codex** (`~/.codex/skills/`), and **OpenCode**
(`~/.config/opencode/AGENTS.md`). The skill and the nudge hook ship inside the
`hammersmith` package, so this works after a normal `pip install`, not just
editable checkouts. For Claude Code and Codex it also registers two gentle
hooks: a Bash hook that notices model-calling or harness commands running
outside a live Hammersmith run, and an edit-loop hook that notices batch
editing without a run. Pi auto-discovers skills from their frontmatter, so it
needs no hook. OpenCode loads `AGENTS.md` into every session, so it gets an
idempotent condensed routing block there (no hooks). Each hook nudges ONCE per
session, pointing the agent at the skill.

The hooks never block anything. A user who says "just do it inline" is obeyed;
uninstall with `hammersmith uninstall-agent`.

See [`docs/AGENT-SKILL.md`](docs/AGENT-SKILL.md) for the per-harness install
matrix and the update workflow.

For CI and evals, `config.sample.toml` includes `[engines.mock]` so the enforcement stack can be tested without an API bill.

## Engines are pluggable

![Identical workers, each under its own light](docs/engines.png)

Swap the worker CLI without changing how Hammersmith isolates, verifies, or logs work.

Hammersmith ships with Pi as the built-in default. Codex CLI, Grok Build CLI, and OpenCode + OpenRouter have verified configurations. Any headless CLI can be added as an engine. Per-task `engine`, `model`, and `engine_args` select the worker lane without changing Hammersmith's process isolation, verification, or logging behavior.

The complete configuration, sandboxing, installation, authentication, model-selection, and pricing notes are in the [engine reference](docs/ENGINE-REFERENCE.md).

### The universal harness: OpenCode + OpenRouter

Use OpenCode for OpenRouter-served models that lack a first-class harness. See [OpenCode + OpenRouter setup and sandboxing](docs/ENGINE-REFERENCE.md#the-universal-harness-opencode--openrouter).

### The plan lane: Grok Build CLI

Use Grok Build as a flat-rate worker lane for eligible subscriptions. See [Grok Build installation, authentication, and routing](docs/ENGINE-REFERENCE.md#the-plan-lane-grok-build-cli).

## Hammersmith: project mission control

![Hammersmith in the browser: a run's live results page with per-worker status and verification](docs/hammersmith.png)

A local web dashboard shows every run, worker, and verification result in real time. No install, no account, nothing leaves your machine. Your first run opens it automatically. Every later run streams into the same tab.

```bash
hammersmith run manifest.json   # starts Hammersmith and opens the tab for you
hammersmith hud                 # or open it any time → http://127.0.0.1:8700
```

The top of the page shows the run's live results: what the job is, a progress bar of rounds, and a section called "The work." That section lists every deliverable each worker filed, with a plain-English line explaining what the check proved. The raw check output is one click away. Below that, the agents section lists each worker. Expand a worker to see the compiled prompt it received (when recorded), the pass test Hammersmith executed separately, which engine and model are typing, and its live work stream. Past runs stay in a versioned library. A swarm whose orchestrator *died* without finishing gets its own unmissable state. This is the failure mode every dashboard forgets.

When Hammersmith supplies causal state, it replaces the generic red failure icon with a specific cause: `MODEL`, `CONTRACT`, `CHECK`, `PROVIDER`, or `HOST`. You also see the stop reason, expected-versus-observed paths, input-patch/preflight evidence, retry decision, and parent adjudication. Engine circuit state and raw versus model-eligible statistics keep infrastructure incidents out of the model story. Project metadata groups root missions, child swarms, and explicit replays while older run files retain their original flat view. The compatibility state contract is documented in [Hammersmith causality state](docs/CAUSALITY.md).

Multiple projects at once are the designed-for case: set a stable `project` on each root manifest and Hammersmith groups each root mission, recursive child swarm, replay, and worker without guessing from names. `--browser` opens a simpler per-run fallback dashboard, and `--no-dashboard` runs headless.

A native desktop build (Tauri, under `hud/`) wraps
Hammersmith on macOS and Windows; the web dashboard remains the primary surface on
every supported host. Linux desktop bundles are temporarily withheld because
current Tauri depends on a vulnerable GTK/glib line; the Python orchestrator
and browser-based Hammersmith remain supported on Linux. See
[Known limitations](docs/KNOWN_LIMITATIONS.md).

## The eval loop

![Timed, verified, logged](docs/eval-loop.png)

Every worker attempt is logged with full evidence, so your swarm improves on data instead of guesswork.

Every attempt (pass, fail, timeout, retry) is logged with its spec, engine, duration, token count, and the raw check output. Output goes to local JSONL by default. Point `[eval.postgres]` at a database to aggregate across machines. Failure rows are the point. They tell you which spec styles, engines, and task shapes actually work, so the swarm improves on evidence instead of vibes.

## Model performance log

### Model identity taxonomy

Track which models pass which checks, using your own run data.

Every task attempt is logged automatically and locally to `~/.hammersmith/runs.jsonl`. The log includes the executed-check verdict, engine, resolved model identity, task type, retry, duration, and tokens. The identity contract keeps trained model, lab, harness, access plan, and reasoning effort separate; see the normative [model identity taxonomy](docs/TAXONOMY.md).

```bash
hammersmith models          # per-(model, task_type) local scoreboard
```

The complete scoreboard fields, filters, historical backfill procedure, and interpretation notes are in the [model performance and routing reference](docs/MODEL-PERFORMANCE.md).

### Evidence-based routing

Refresh the local OpenRouter catalog and join it to your own run evidence:

```bash
hammersmith catalog
hammersmith models --explore
hammersmith models --explore --task-type docs
```

Catalog flags, snapshot and change-log paths, refresh behavior, tier definitions, and the personal promotion ladder are documented in [Evidence-based routing](docs/MODEL-PERFORMANCE.md#evidence-based-routing).

## Steering profiles

Load per-model guidance that improves worker prompts without blocking runs when the data is missing.

Hammersmith can optionally load per-model steering profiles. It prepends applicable worker rules to both first-attempt and retry prompts, prints driver guidance for the orchestrator, and collects one local observation row per attempt. The feature is fail-open: missing or malformed steering data never blocks a run. Setup, the profile contract, and the observation schema are documented in [`docs/STEERING.md`](docs/STEERING.md).

## Hard-won invariants

Every worker invocation follows four rules that prevent the most common and confusing failures. They come from real debugging experience, and you get them for free:

1. **stdin is always closed** (`< /dev/null`): headless CLI agents hang forever waiting on a TTY that isn't there.
2. **Sandbox mode is always explicit**: default sandboxes silently resolve to read-only in temp directories and block every artifact write.
3. **Verification executes the artifact**: an agent's own "done" is not evidence. Exit codes are.
4. **Raw output only**: logs and eval rows carry verbatim worker output, never a summary. Anything that needs judgment reads the raw data.

## License

This repository uses [PolyForm Shield 1.0.0](LICENSE.md), which includes a required upstream notice. PolyForm Shield is source-available and **is not an OSI-approved open-source license**. Nothing in the Hammersmith roadmap or repository policy files changes those legal terms. Before a public open-source launch, an authorized rights holder must intentionally select and apply an OSI-approved license, confirm relicensing rights for code and assets, and preserve required notices. See [NOTICE.md](NOTICE.md).

## Development and stewardship

- [Contributing](CONTRIBUTING.md)
- [Security](SECURITY.md)
- [Governance](GOVERNANCE.md)

## Requirements

- Python 3.11+ (stdlib only; `psycopg` needed only for the optional Postgres eval backend)
- At least one agent CLI (Codex works out of the box)
- Rust toolchain, only if you're building the native Hammersmith/Hammersmith app from source

![Between rounds](docs/between-rounds.png)

---

Originally built by [Jon Edwards](https://limitededitionjonathan.com) and his agent fleet. Hammersmith preserves the original project notice and attribution while adding project hierarchy, causal failure intelligence, steering profiles, and multi-project monitoring.
