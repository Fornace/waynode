# Notices and attribution

Required Notice: Copyright Nate Jones Media LLC — Ringer and Hammersmith (https://github.com/NateBJones-Projects/ringer)

Hammersmith is derived from Ringer and Hammersmith. The compatibility CLI, state layout, configuration namespace, and portions of historical documentation retain the original names so existing installations continue to work.

Subsequent modifications include the Hammersmith identity, Hammersmith dashboard terminology, structured task contracts, failure intelligence, recursive run hierarchy, model-routing evidence, and multi-project monitoring.

This notice supplements and does not replace [LICENSE.md](LICENSE.md). Distributions must preserve every required notice and license obligation that applies to the distributed version.
