"""Copy-only extraction from :mod:`ringer` for staged modularization.

The legacy entry point remains authoritative until the integration pass wires these
modules in.  Imports from ``ringer`` provide cross-slice dependencies while the
functions owned by this module are copied verbatim below.
"""
from __future__ import annotations

import contextlib
import threading
import urllib.parse
import webbrowser
from dataclasses import replace as dataclass_replace
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


def _build_ai_assist() -> AIAssistService | None:
    """Construct the AI-author service from gateway env vars, if configured."""
    gateway = GatewayConfig.from_env()
    return AIAssistService(gateway) if gateway is not None else None


from hammersmith.catalog import utc_now_iso

# Real URLs the product shell answers to (the SPA router maps them to views).
_APP_ROUTES = frozenset({"/", "/create", "/runs", "/artifacts", "/models", "/settings"})
from hammersmith.config_models import DEFAULT_HUD_PORT
from hammersmith.identity import PRODUCT_NAME
from hammersmith.models_api import build_models_api_payload
from hammersmith.browser import open_in_browser
from hammersmith.config import AppConfig
from hammersmith.control_plane.adjudications import AdjudicationStore
from hammersmith.control_plane.ai_assist import AIAssistService, GatewayConfig
from hammersmith.control_plane.bootstrap import BootstrapService
from hammersmith.control_plane.drafts import DraftStore
from hammersmith.control_plane.exports import ExportService
from hammersmith.control_plane.paths import PathCapability
from hammersmith.control_plane.query import RunQueryService
from hammersmith.control_plane.runs import RunService
from hammersmith.control_plane.validation import ValidatedPlanStore, ValidationService

from hammersmith.artifacts.library import (
    artifacts_dir,
)

from hammersmith.auth import AuthManager
from .auth_middleware import AuthMiddleware
from .auth_pages import serve_login_page
from .dashboard_html import read_dashboard_html, read_hammersmith_html
from .control_routes import serve_control_get
from .post_handlers import ControlPlaneHandlers, handle_post_request
from .responses import (
    send_response_body, serve_artifact_path, task_log_path_from_state,
)
from .run_evidence import serve_run_export, serve_run_log

class PersistentHudServer:
    def __init__(
        self,
        state_dir: Path,
        preferred_port: int = DEFAULT_HUD_PORT,
        *,
        open_viewer: bool = True,
        config: AppConfig | None = None,
        launcher: Any | None = None,
    ) -> None:
        self.state_dir = state_dir
        self.preferred_port = preferred_port
        self.open_viewer = open_viewer
        self.httpd: ThreadingHTTPServer | None = None
        self.thread: threading.Thread | None = None
        self.port: int | None = None
        self.model_log_path: Path | None = None
        self.default_model_log_path: Path = state_dir / "runs.jsonl"
        self.model_db_path: Path | None = None
        self.control_config = config
        self.control_launcher = launcher
        self.control: ControlPlaneHandlers | None = None

    def start(self) -> int:
        state_dir = self.state_dir
        artifact_root = artifacts_dir(state_dir)
        from hammersmith.constants import _REPO_ROOT
        asset_root = (_REPO_ROOT / "dashboard" / "assets").resolve()
        preferred_port = self.preferred_port
        server_ref = self
        auth_manager = AuthManager()
        auth_middleware = AuthMiddleware(auth_manager)
        loaded_config = self.control_config or AppConfig.load()
        control_config = dataclass_replace(
            loaded_config,
            state_dir=state_dir,
            eval=dataclass_replace(
                loaded_config.eval,
                jsonl_path=self.model_log_path or (state_dir / "runs.jsonl"),
            ),
        )
        plans = ValidatedPlanStore()
        query = RunQueryService(state_dir)
        validation = ValidationService(control_config, plans)
        runs = RunService(
            control_config,
            plans,
            launcher=self.control_launcher,
            query=query,
        )
        path_capability = PathCapability((state_dir, artifact_root, asset_root))
        control = ControlPlaneHandlers(
            validation=validation,
            drafts=DraftStore(state_dir),
            runs=runs,
            adjudications=AdjudicationStore(
                state_dir, eval_path=control_config.eval.jsonl_path
            ),
            paths=path_capability,
            state_dir=state_dir.resolve(),
            ai_assist=_build_ai_assist(),
        )
        self.control = control
        bootstrap = BootstrapService(control_config)
        exporter = ExportService(state_dir)

        def models_payload() -> dict[str, Any]:
            try:
                return build_models_api_payload(
                    log_path=server_ref.model_log_path or (state_dir / "runs.jsonl"),
                    default_log_path=state_dir / ".http-read-only-model-log",
                    db_path=None,
                )
            except Exception:
                return {"generated_at": utc_now_iso(), "groups": [], "rollup": [], "error": "models_unavailable"}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802
                path = urllib.parse.urlparse(self.path).path
                if not auth_middleware.require_valid_host(self):
                    return

                if path == "/login":
                    serve_login_page(self, auth_manager)
                    return

                if path.startswith("/assets/"):
                    asset_path = path_capability.resolve_relative(
                        asset_root,
                        urllib.parse.unquote(path[len("/assets/"):]),
                        require_file=True,
                    )
                    if asset_path is not None:
                        content_type = "application/octet-stream"
                        if asset_path.suffix == ".css":
                            content_type = "text/css; charset=utf-8"
                        elif asset_path.suffix == ".js":
                            content_type = "application/javascript; charset=utf-8"
                        elif asset_path.suffix in (".png", ".jpg", ".jpeg", ".gif", ".svg"):
                            content_type = f"image/{asset_path.suffix[1:]}"
                        body = asset_path.read_bytes()
                        send_response_body(self, HTTPStatus.OK, body, content_type=content_type)
                        return
                    self.send_error(HTTPStatus.NOT_FOUND)
                    return

                # The product shell is a routed SPA: every app view has a real
                # URL (/create, /runs, /runs/<id>, /artifacts, /models,
                # /settings) and the server answers them all with the same
                # shell so refresh, deep links, and Back/Forward work.
                app_route = path in _APP_ROUTES or path.startswith("/runs/")
                if app_route:
                    if not auth_middleware.is_authenticated(self):
                        self.send_response(HTTPStatus.FOUND)
                        self.send_header("Location", "/login")
                        self.send_header("Content-Length", "0")
                        self.end_headers()
                        return
                    body = read_hammersmith_html().encode("utf-8")
                    send_response_body(
                        self,
                        HTTPStatus.OK,
                        body,
                        content_type="text/html; charset=utf-8",
                    )
                    return

                if serve_control_get(
                    self,
                    path,
                    auth_middleware=auth_middleware,
                    control=control,
                    bootstrap=bootstrap,
                    query=query,
                    models_payload=models_payload,
                    state_dir=state_dir,
                ):
                    return
                if serve_run_export(
                    self, path, exporter=exporter, auth_middleware=auth_middleware
                ):
                    return

                if path.startswith("/artifacts/"):
                    if not auth_middleware.require_auth(self):
                        return
                    if not serve_artifact_path(self, artifact_root, path):
                        self.send_error(HTTPStatus.NOT_FOUND)
                    return

                if serve_run_log(
                    self, path, state_dir=state_dir, auth_middleware=auth_middleware
                ):
                    return

                self.send_error(HTTPStatus.NOT_FOUND)

            def do_POST(self) -> None:  # noqa: N802
                handle_post_request(self, auth_manager, auth_middleware, control)

            def do_PUT(self) -> None:  # noqa: N802
                handle_post_request(self, auth_manager, auth_middleware, control)

            def do_DELETE(self) -> None:  # noqa: N802
                handle_post_request(self, auth_manager, auth_middleware, control)

            def log_message(self, _format: str, *_args: Any) -> None:
                return

        try:
            self.httpd = ThreadingHTTPServer(("127.0.0.1", preferred_port), Handler)
        except OSError as exc:
            raise RuntimeError(
                f"could not start {PRODUCT_NAME} on 127.0.0.1:{preferred_port}; "
                "that port is already in use. Use --port to choose another port."
            ) from exc
        self.port = int(self.httpd.server_address[1])
        self.thread = threading.Thread(target=self.httpd.serve_forever, name="hammersmith-hud", daemon=True)
        self.thread.start()
        url = f"http://127.0.0.1:{self.port}"
        if self.open_viewer:
            with contextlib.suppress(Exception):
                webbrowser.open(url)
        print(f"{PRODUCT_NAME}: {url}", flush=True)
        return self.port

    def start_background(self) -> int:
        return self.start()

    def stop(self) -> None:
        if self.httpd is not None:
            self.httpd.shutdown()
            self.httpd.server_close()
        if self.thread is not None:
            self.thread.join(timeout=2)

class Dashboard:
    def __init__(
        self,
        state_path: Path,
        preferred_port: int,
        hud_app_path: Path | None = None,
        force_browser: bool = False,
        open_viewer: bool = True,
    ) -> None:
        self.state_path = state_path
        self.preferred_port = preferred_port
        self.hud_app_path = hud_app_path
        self.force_browser = force_browser
        self.open_viewer = open_viewer
        self.httpd: ThreadingHTTPServer | None = None
        self.thread: threading.Thread | None = None
        self.port: int | None = None

    def start(self) -> int:
        state_path = self.state_path
        artifact_root = state_path.parent.parent / "artifacts"

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802
                path = urllib.parse.urlparse(self.path).path
                if path == "/":
                    body = read_dashboard_html().encode("utf-8")
                    send_response_body(
                        self,
                        HTTPStatus.OK,
                        body,
                        content_type="text/html; charset=utf-8",
                    )
                    return
                if path == "/state.json":
                    try:
                        body = state_path.read_bytes()
                    except FileNotFoundError:
                        body = b'{"run_name":"hammersmith","identity":"unknown","started_at":"","port":null,"dashboard_port":null,"tasks":[],"totals":{"running":0,"done":0,"pass":0,"fail":0,"tokens":0}}'
                    send_response_body(
                        self,
                        HTTPStatus.OK,
                        body,
                        content_type="application/json; charset=utf-8",
                        no_store=True,
                    )
                    return
                if path.startswith("/logs/"):
                    task_key = urllib.parse.unquote(path[len("/logs/") :])
                    log_path = task_log_path_from_state(state_path, task_key)
                    if log_path is None:
                        self.send_error(HTTPStatus.NOT_FOUND)
                        return
                    body = tail_file_text(log_path, max_bytes=WORKER_LOG_TAIL_BYTES).encode("utf-8")
                    send_response_body(
                        self,
                        HTTPStatus.OK,
                        body,
                        content_type="text/plain; charset=utf-8",
                        no_store=True,
                    )
                    return
                if serve_artifact_path(self, artifact_root, path):
                    return
                self.send_error(HTTPStatus.NOT_FOUND)

            def log_message(self, _format: str, *_args: Any) -> None:
                return

        last_error: OSError | None = None
        for port in range(self.preferred_port, self.preferred_port + 50):
            try:
                self.httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            except OSError as exc:
                last_error = exc
                continue
            self.port = int(self.httpd.server_address[1])
            break
        if self.httpd is None or self.port is None:
            raise RuntimeError(f"could not start dashboard: {last_error}")
        self.thread = threading.Thread(target=self.httpd.serve_forever, name="hammersmith-dashboard", daemon=True)
        self.thread.start()
        url = f"http://localhost:{self.port}"
        # Browser-first: the persistent hud (ensure_hud_running, called from the
        # run path) is what the human watches. Only --browser opens this
        # per-run page directly; the parked Tauri app is never auto-launched.
        if self.open_viewer and self.force_browser:
            open_in_browser(url)
        # The persistent hud (:8700) is the one watch surface; this per-run
        # server is an internal state/log feed. Only advertise it when the
        # user explicitly chose the per-run page with --browser.
        if self.force_browser:
            print(f"Dashboard: {url}", flush=True)
        return self.port

    def stop(self) -> None:
        if self.httpd is not None:
            self.httpd.shutdown()
            self.httpd.server_close()
        if self.thread is not None:
            self.thread.join(timeout=2)
