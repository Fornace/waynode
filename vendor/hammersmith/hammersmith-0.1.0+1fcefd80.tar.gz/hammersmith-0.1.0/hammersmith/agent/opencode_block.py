"""OpenCode AGENTS.md marker-block text operations.

OpenCode has no skills directory or JSON hook config; its always-loaded
surface is AGENTS.md. The Hammersmith playbook is installed there as an
idempotent marker-delimited block. These functions are pure text transforms —
file I/O lives in :mod:`hammersmith.agent.installer`.
"""

from __future__ import annotations

# OpenCode has no skills directory or JSON hook config. Its always-loaded surface
# is AGENTS.md, so the playbook is installed as an idempotent marker-delimited
# block (condensed — the full SKILL.md is too large for a global instruction file).
_OPENCODE_BLOCK_BEGIN = "<!-- BEGIN hammersmith-agent -->"
_OPENCODE_BLOCK_END = "<!-- END hammersmith-agent -->"
_OPENCODE_BLOCK_BODY = """\
## Hammersmith — orchestrator routing rules

Hammersmith (`hammersmith` CLI) runs manifest tasks in parallel across cheap CLI
workers and **verifies every task by executing a check command** (exit 0 is the
only PASS). You — the orchestrating model — pay tokens only for specs,
orchestration, and review. Route work to it instead of drifting into invisible
inline edits and unverified model calls.

**TRIGGER — load this BEFORE acting, not after — whenever:** you are about to
run a script/command that calls a model or drives a conversational/eval harness
(probe, smoke, simulation, grader, persona conversation) outside a live
Hammersmith run; you are about to start an edit→test→edit loop or a batch of
similar edits across files; you are reviewing/diagnosing failed worker or model
output; you catch yourself thinking a task is "small enough to just do myself"
(that thought IS the trigger — a single task is a one-task manifest); you are
writing/reviewing a manifest, choosing a swarm pattern, picking a worker
engine, or debugging a failed run. **SKIP** for: reading/searching files, git
ops, a one-file few-line ONE-SHOT edit (once — a second pass is a loop:
TRIGGER), authoring prose/specs/docs from your own context, or pure conversation.

**Four rules that actually get broken:**
1. **You review; workers type.** Your lane: specs, checks, pattern choice,
   reading results. If you are typing impl, running probes, or babysitting a
   retry loop yourself, you have left your lane.
2. **A single task is a one-task manifest.** Same verification, zero ceremony.
3. **Beware the tiny-edit death spiral.** Each step is small enough to justify
   inline; two hours later the exception is the workflow and nothing was
   verified. The one-shot exception is ONE file, a few lines, ONCE.
4. **Runs are watched, and the screen comes up FIRST.** `hammersmith hud`
   (http://127.0.0.1:8700) before you write a spec. Never `--no-dashboard`
   except in tests.

**Key commands:**
```bash
hammersmith lint manifest.json            # always lint before run
hammersmith run manifest.json --identity <who-you-are>
hammersmith demo                          # 3-worker smoke test
hammersmith run manifest.json --dry-run   # print the plan, spawn nothing
hammersmith models --open                 # zero-LLM scoreboard HTML
hammersmith hud                           # open the live dashboard
```
Ready-made manifest skeletons live in `templates/` (review-swarm, fix-swarm,
focus-group, bakeoff, research-with-proof, probe, …). Full playbook and
field reference: `hammersmith/agent/SKILL.md` in the repo, and the README.
"""




def _build_opencode_block() -> str:
    return f"{_OPENCODE_BLOCK_BEGIN}\n{_OPENCODE_BLOCK_BODY}{_OPENCODE_BLOCK_END}"


def _replace_or_append_block(text: str, block: str) -> tuple[str, bool]:
    """Insert/replace the marker block in ``text``. Returns (new_text, changed)."""
    begin = _OPENCODE_BLOCK_BEGIN
    end = _OPENCODE_BLOCK_END
    start = text.find(begin)
    if start != -1:
        end_idx = text.find(end, start)
        if end_idx != -1:
            before = text[:start]
            after = text[end_idx + len(end) :]
            new_text = f"{before}{block}{after}"
            return new_text, new_text != text
    separator = "\n\n" if text and not text.endswith("\n\n") else ("\n" if text and not text.endswith("\n") else "")
    return f"{text}{separator}{block}\n", True


def _remove_block(text: str) -> tuple[str, bool]:
    """Remove the marker block (and one trailing blank line) from ``text``."""
    begin = _OPENCODE_BLOCK_BEGIN
    end = _OPENCODE_BLOCK_END
    start = text.find(begin)
    if start == -1:
        return text, False
    end_idx = text.find(end, start)
    if end_idx == -1:
        # Unterminated block: remove from begin to EOF.
        new_text = text[:start]
    else:
        new_text = text[:start] + text[end_idx + len(end) :]
    # Collapse up to one trailing blank line left behind.
    new_text = new_text.replace("\n\n\n", "\n\n", 1) if new_text.endswith("\n\n\n") else new_text
    return new_text.rstrip() + "\n" if new_text.strip() else "", new_text != text
