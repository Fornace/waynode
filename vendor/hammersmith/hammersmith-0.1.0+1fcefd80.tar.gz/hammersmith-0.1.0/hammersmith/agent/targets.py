"""Harness target layouts and detection for the agent installer.

Each supported orchestrating harness (Claude Code, Pi, Codex, OpenCode) has a
canonical on-disk layout for the skill, the nudge hook, and its hook-settings
file. Detection is conservative: a harness is only auto-selected when its
standard config root already exists on the machine.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from . import HOOK_FILENAME

TARGETS: tuple[str, ...] = ("claude", "pi", "codex", "opencode")
_DEFAULT_FALLBACK = "claude"


@dataclass(frozen=True)
class TargetLayout:
    """Where the skill, hook, and hook-settings live for one harness."""

    name: str
    skill_path: Path
    hook_path: Path
    settings_path: Path | None  # JSON file holding a "hooks" object (None = no hooks)
    is_project_scope: bool


def _home(project: bool) -> Path:
    return Path.cwd() if project else Path.home()


def layout_for(name: str, project: bool) -> TargetLayout:
    if name == "claude":
        root = _home(project) / ".claude"
        skill_dir = root / "skills" / "hammersmith"
        return TargetLayout(
            name=name,
            skill_path=skill_dir / "SKILL.md",
            hook_path=skill_dir / HOOK_FILENAME,
            settings_path=root / "settings.json",
            is_project_scope=project,
        )
    if name == "pi":
        # Pi skills are user-scope only (auto-discovered from ~/.pi/agent/skills).
        root = _home(False) / ".pi" / "agent"
        skill_dir = root / "skills" / "hammersmith"
        return TargetLayout(
            name=name,
            skill_path=skill_dir / "SKILL.md",
            hook_path=skill_dir / HOOK_FILENAME,
            settings_path=None,
            is_project_scope=False,
        )
    if name == "codex":
        root = _home(False) / ".codex"
        skill_dir = root / "skills" / "hammersmith"
        return TargetLayout(
            name=name,
            skill_path=skill_dir / "SKILL.md",
            hook_path=skill_dir / HOOK_FILENAME,
            settings_path=root / "hooks.json",
            is_project_scope=False,
        )
    if name == "opencode":
        # OpenCode loads AGENTS.md into every session. We manage an idempotent
        # marker-delimited block there; skill_path/hook_path are unused.
        root = _home(False) / ".config" / "opencode"
        return TargetLayout(
            name=name,
            skill_path=root / "AGENTS.md",
            hook_path=root / "AGENTS.md",
            settings_path=root / "AGENTS.md",
            is_project_scope=False,
        )
    raise ValueError(f"unknown agent target: {name!r} (known: {', '.join(TARGETS)})")


def detect_targets(project: bool) -> list[str]:
    """Return harnesses whose config roots exist under the home dir.

    Detection is intentionally conservative: we only auto-install for a
    harness when its standard directory already exists, i.e. the harness has
    been used on this machine. ``--project`` scope only affects Claude Code.
    """
    home = _home(False)
    found: list[str] = []
    if (home / ".claude").exists() or (_home(project) / ".claude").exists():
        found.append("claude")
    if (home / ".pi" / "agent").exists():
        found.append("pi")
    if (home / ".codex").exists():
        found.append("codex")
    if (home / ".config" / "opencode").exists():
        found.append("opencode")
    return found


def _normalize_targets(targets: list[str] | None, project: bool) -> list[str]:
    if targets:
        bad = [t for t in targets if t not in TARGETS]
        if bad:
            raise ValueError(
                f"unknown agent target(s): {', '.join(bad)} (known: {', '.join(TARGETS)})"
            )
        # de-duplicate, preserve order
        return list(dict.fromkeys(targets))
    detected = detect_targets(project)
    return detected or [_DEFAULT_FALLBACK]
