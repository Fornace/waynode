"""Multi-harness installer for the Hammersmith agent skill and nudge hooks.

Canonical skill + hook sources live in :mod:`hammersmith.agent` so they ship
with the package. ``install_agent`` copies the skill into every supported
orchestrating harness it detects (Claude Code, Pi, Codex) and registers the
non-blocking nudge hooks for harnesses that support them (Claude Code and
Codex share the same JSON hook schema; Pi auto-discovers skills by their
``desc`` frontmatter and needs no hook). Harness layouts and detection live in
:mod:`hammersmith.agent.targets`; the OpenCode AGENTS.md marker-block text
operations live in :mod:`hammersmith.agent.opencode_block`.

The installer copies the nudge hook to a STABLE per-harness path next to the
installed skill, so the registered hook command keeps working regardless of
where the ``hammersmith`` package itself lives (editable checkout, wheel, or
later upgrade). Each harness install is independent and idempotent.
"""

from __future__ import annotations

import json
import os
import shlex
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import HOOK_SOURCE, SKILL_SOURCE
from .opencode_block import _build_opencode_block, _remove_block, _replace_or_append_block
from .targets import TARGETS, layout_for, _normalize_targets

# --- JSON hook-settings helpers (shared by Claude settings.json + Codex hooks.json) ---


def _backup_file(path: Path) -> Path | None:
    if not path.exists():
        return None
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    backup = path.with_name(f"{path.name}.bak-{stamp}")
    shutil.copy2(path, backup)
    return backup


def _load_settings(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"settings file is not valid JSON: {path}") from exc
    if not isinstance(data, dict):
        raise ValueError(f"settings file must contain a JSON object: {path}")
    return data


def _write_settings(path: Path, settings: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    _backup_file(path)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps(settings, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def _hook_command_contains(val: Any) -> bool:
    return isinstance(val, dict) and "hammersmith_nudge.py" in str(val.get("command", ""))


def _event_has_hammersmith_hook(groups: Any) -> bool:
    if not isinstance(groups, list):
        return False
    for group in groups:
        if not isinstance(group, dict):
            continue
        handlers = group.get("hooks")
        if isinstance(handlers, list) and any(_hook_command_contains(h) for h in handlers):
            return True
    return False


def _merge_hook(
    settings: dict[str, Any], event: str, matcher: str, cmd: str
) -> bool:
    hooks = settings.setdefault("hooks", {})
    if not isinstance(hooks, dict):
        raise ValueError("settings hooks field must be a JSON object")
    groups = hooks.setdefault(event, [])
    if not isinstance(groups, list):
        raise ValueError(f"settings hooks.{event} field must be a JSON array")
    if _event_has_hammersmith_hook(groups):
        return False
    groups.append(
        {
            "matcher": matcher,
            "hooks": [{"type": "command", "command": cmd}],
        }
    )
    return True


def _remove_hammersmith_hooks(settings: dict[str, Any]) -> int:
    hooks = settings.get("hooks")
    if not isinstance(hooks, dict):
        return 0
    removed = 0
    for event in list(hooks):
        groups = hooks[event]
        if not isinstance(groups, list):
            continue
        kept_groups: list[dict[str, Any]] = []
        for group in groups:
            if not isinstance(group, dict):
                kept_groups.append(group)
                continue
            handlers = group.get("hooks")
            if not isinstance(handlers, list):
                kept_groups.append(group)
                continue
            kept_handlers = [h for h in handlers if not _hook_command_contains(h)]
            removed += len(handlers) - len(kept_handlers)
            if kept_handlers:
                new_group = dict(group)
                new_group["hooks"] = kept_handlers
                kept_groups.append(new_group)
        if kept_groups:
            hooks[event] = kept_groups
        else:
            del hooks[event]
    if not hooks:
        del settings["hooks"]
    return removed


def _hook_command(action: str, hook_path: Path) -> str:
    return f"python3 {shlex.quote(str(hook_path))} {action}"


def _install_opencode_block(path: Path) -> bool:
    """Insert/refresh the Hammersmith block in an AGENTS.md file. Returns changed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    new_text, changed = _replace_or_append_block(text, _build_opencode_block())
    if changed or not path.exists():
        _backup_file(path)
        path.write_text(new_text, encoding="utf-8")
    return changed


def _uninstall_opencode_block(path: Path) -> bool:
    """Remove the Hammersmith block from an AGENTS.md file. Returns changed."""
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8")
    new_text, changed = _remove_block(text)
    if changed:
        _backup_file(path)
        path.write_text(new_text, encoding="utf-8")
    return changed


# --- per-target install / uninstall ---


def install_for_target(name: str, project: bool) -> dict[str, Any]:
    """Install skill (+ hooks where supported) for one harness.

    Returns a small report dict. Raises if the canonical sources are missing.
    """
    if name == "opencode":
        layout = layout_for(name, project)
        changed = _install_opencode_block(layout.settings_path)
        return {
            "target": name,
            "skill_path": str(layout.settings_path),
            "hooks_registered": False,
            "hooks_changed": changed,
            "project_scope": False,
        }

    if not SKILL_SOURCE.exists():
        raise ValueError(f"canonical skill source not found: {SKILL_SOURCE}")
    layout = layout_for(name, project)

    layout.skill_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SKILL_SOURCE, layout.skill_path)

    hooks_registered = False
    hooks_changed = False
    if layout.settings_path is not None:
        # Copy the hook to a stable per-harness path next to the skill.
        shutil.copy2(HOOK_SOURCE, layout.hook_path)
        settings = _load_settings(layout.settings_path)
        pre_cmd = _hook_command("pre-bash", layout.hook_path)
        post_cmd = _hook_command("post-edit", layout.hook_path)
        changed = False
        changed |= _merge_hook(settings, "PreToolUse", "Bash", pre_cmd)
        changed |= _merge_hook(settings, "PostToolUse", "Edit|Write", post_cmd)
        if changed or not layout.settings_path.exists():
            _write_settings(layout.settings_path, settings)
            hooks_changed = changed
        hooks_registered = True

    return {
        "target": name,
        "skill_path": str(layout.skill_path),
        "hooks_registered": hooks_registered,
        "hooks_changed": hooks_changed,
        "project_scope": layout.is_project_scope,
    }


def uninstall_for_target(name: str, project: bool) -> dict[str, Any]:
    if name == "opencode":
        layout = layout_for(name, project)
        changed = _uninstall_opencode_block(layout.settings_path)
        return {
            "target": name,
            "skill_removed": changed,
            "hooks_removed": 0,
        }

    layout = layout_for(name, project)
    hooks_removed = 0
    if layout.settings_path is not None and layout.settings_path.exists():
        settings = _load_settings(layout.settings_path)
        hooks_removed = _remove_hammersmith_hooks(settings)
        if hooks_removed or "hooks" not in settings:
            _write_settings(layout.settings_path, settings)

    skill_dir = layout.skill_path.parent
    skill_removed = False
    if skill_dir.exists():
        shutil.rmtree(skill_dir)
        skill_removed = True

    return {
        "target": name,
        "skill_removed": skill_removed,
        "hooks_removed": hooks_removed,
    }


# --- entry points ---


def install_agent(project: bool = False, targets: list[str] | None = None) -> int:
    selected = _normalize_targets(targets, project)
    reports = [install_for_target(name, project) for name in selected]

    scope_word = "project" if project else "user"
    print(f"Installed Hammersmith agent for {len(reports)} target(s) ({scope_word} scope).")
    for report in reports:
        loc = "project" if report["project_scope"] else "user"
        if report["target"] == "opencode":
            action = "block refreshed" if report["hooks_changed"] else "block already present"
            line = f"  • {report['target']} [{loc}]: AGENTS.md → {report['skill_path']} ({action})"
        else:
            line = f"  • {report['target']} [{loc}]: skill → {report['skill_path']}"
            if report["hooks_registered"]:
                line += (
                    f"; hooks {'registered' if report['hooks_changed'] else 'already present'}"
                )
        print(line)
    extras = [t for t in TARGETS if t not in selected]
    if extras:
        print(f"Skipped (not requested/detected): {', '.join(extras)}.")
        print("Use `hammersmith install-agent --target <name>` to add one.")
    print("Uninstall with: hammersmith uninstall-agent")
    return 0


def uninstall_agent(project: bool = False, targets: list[str] | None = None) -> int:
    selected = _normalize_targets(targets, project)
    # When uninstalling without an explicit --target, sweep EVERY known target
    # so stale installs on harnesses no longer present are cleaned up too.
    if not targets:
        selected = list(TARGETS)
    reports = [uninstall_for_target(name, project) for name in selected]

    scope_word = "project" if project else "user"
    print(f"Uninstalled Hammersmith agent ({scope_word} scope).")
    for report in reports:
        had_anything = report["skill_removed"] or report["hooks_removed"]
        tag = "" if had_anything else " (nothing installed)"
        if report["target"] == "opencode":
            what = "block removed" if report["skill_removed"] else "block absent"
            print(f"  • {report['target']}: {what}{tag}")
        else:
            print(
                f"  • {report['target']}: skill "
                f"{'removed' if report['skill_removed'] else 'absent'}, "
                f"hooks -{report['hooks_removed']}{tag}"
            )
    return 0
