"""Agent skill + nudge-hook assets and multi-harness installer.

This package ships the canonical Hammersmith orchestrator ``SKILL.md`` and the
``hammersmith_nudge.py`` hook so that ``hammersmith install-agent`` works after
a normal ``pip install`` (not only editable checkouts). The installer copies
the skill into every supported orchestrating harness it detects (Claude Code,
Pi, Codex) and registers the non-blocking nudge hooks where the harness
supports them.
"""

from __future__ import annotations

from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
SKILL_SOURCE = PACKAGE_DIR / "SKILL.md"
HOOK_SOURCE = PACKAGE_DIR / "hammersmith_nudge.py"
HOOK_FILENAME = HOOK_SOURCE.name

__all__ = ["PACKAGE_DIR", "SKILL_SOURCE", "HOOK_SOURCE", "HOOK_FILENAME"]
