"""AI-assisted manifest authoring backed by an OpenAI-compatible gateway.

The control plane calls an external LLM gateway (for example the fornace.net
``fornace-reasoning`` model) to turn a natural-language goal into a canonical
Hammersmith manifest object. The generated manifest is always run through
:class:`~hammersmith.manifest_models.Manifest` before it is returned, so the
output is authoritatively valid (or a structured error is raised). This service
never writes, launches, or mutates anything — it only produces an inert draft
for the caller to review, validate, and launch through the existing flow.
"""
from __future__ import annotations

import json
import re
import ssl
from dataclasses import dataclass
from typing import Any

from hammersmith.manifest_models import Manifest

# Model ids on OpenAI-compatible gateways look like "fornace-reasoning" or
# "provider/model:tag". Anything outside this shape is rejected before it can
# reach the outbound request body.
_MODEL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/+-]{0,199}$")

# The gateway catalog mixes chat models with embedding/image/video models,
# which cannot draft manifests (they 403 or return non-text output). The
# picker must never offer them.
_NON_CHAT_MARKERS = ("embed", "image", "video")


def is_chat_model(model_id: str) -> bool:
    """Return False for embedding/image/video catalog entries."""
    lowered = model_id.lower()
    return not any(marker in lowered for marker in _NON_CHAT_MARKERS)


SYSTEM_PROMPT = (
    "You generate Hammersmith task manifests. Output ONLY a JSON object with "
    "this exact shape — no prose, no markdown fences, nothing else:\n"
    '{"run_name": string, "project": string, "workdir": string, "tasks": ['
    '{"key": string, "spec": string (detailed), "check": string (an executable '
    "shell command that verifies the task's outputs), \"engine\": \"pi\", "
    '"expect_files": [string], "verified": string (what the check proves), '
    '"task_type": string (code, code-fix, docs, research, probe, ...)}]}\n'
    "Rules:\n"
    "- workdir is an absolute path under /tmp/hammersmith-ai-runs/<slug>.\n"
    "- Every task's check MUST be an executable shell command that fails when "
    "the work is wrong or incomplete.\n"
    "- Split the goal into 2-4 independent parallel tasks when possible.\n"
    "- Be concrete and detailed in each spec so a worker can implement it "
    "without further questions."
)


TITLE_SYSTEM_PROMPT = (
    "You name Hammersmith runs. Output ONLY a JSON object — no prose, no "
    "markdown fences:\n"
    '{"run_name": string, "task_titles": {string: string}}\n'
    "Rules:\n"
    "- run_name: 3-7 words, human and distinctive, title case, plain text "
    "(NOT a slug), specific to the goal — never generic like 'Build Project'.\n"
    "- task_titles: every provided task key maps to a 3-6 word human title "
    "that says what the task delivers.\n"
    "- Names must read clearly to a non-technical operator scanning a list."
)


class AIAssistError(RuntimeError):
    """Raised when AI authoring fails for a mapped, client-visible reason."""

    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(code)
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class GatewayConfig:
    base_url: str
    api_key: str
    model: str
    # Reasoning tiers take 50s+ on a modest manifest goal; 90s was too tight.
    timeout_s: float = 150.0
    # Cheap fast model that titles runs/tasks after drafting.
    title_model: str = "fornace-flash"
    title_timeout_s: float = 30.0
    # None = omit the field and let the gateway apply the model's own default.
    # Several catalog models (e.g. reasoning tiers) reject any explicit value
    # other than 1, so a blanket default would break them.
    temperature: float | None = None

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> "GatewayConfig | None":
        import os

        e = env if env is not None else os.environ
        base = e.get("HAMMERSMITH_AI_GATEWAY_URL") or e.get("FORNACE_LLM_BASE_URL")
        key = e.get("HAMMERSMITH_AI_GATEWAY_KEY") or e.get("FORNACE_LLM_API_KEY")
        model = e.get("HAMMERSMITH_AI_GATEWAY_MODEL") or "fornace-reasoning"
        if not (base and key):
            return None
        temperature: float | None = None
        raw_temperature = e.get("HAMMERSMITH_AI_TEMPERATURE")
        if raw_temperature:
            try:
                temperature = float(raw_temperature)
            except ValueError:
                temperature = None
        return cls(
            base_url=base.rstrip("/"),
            api_key=key,
            model=model,
            temperature=temperature,
            title_model=e.get("HAMMERSMITH_AI_TITLE_MODEL") or "fornace-flash",
        )


def _http_error_detail(exc: "urllib.error.HTTPError") -> str:
    """Extract the gateway's own error message (the actionable part).

    Upstream bodies carry the real reason — e.g. a provider account in
    arrears or a sampling restriction — which is what the operator needs to
    see, not a bare status code. Falls back to the status code.
    """
    fallback = f"HTTP {exc.code}"
    try:
        payload = json.loads(exc.read().decode("utf-8"))
    except Exception:
        return fallback
    error = payload.get("error") if isinstance(payload, dict) else None
    message = error.get("message") if isinstance(error, dict) else None
    if isinstance(message, str) and message.strip():
        return message.strip()[:300]
    return fallback


def _ssl_context() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    try:
        import certifi

        ctx.load_verify_locations(cafile=certifi.where())
    except Exception:
        pass
    return ctx


class AIAssistService:
    def __init__(self, gateway: GatewayConfig) -> None:
        self.gateway = gateway

    def author(
        self,
        goal: str,
        *,
        constraints: dict[str, Any] | None = None,
        model: str | None = None,
    ) -> dict[str, Any]:
        goal = (goal or "").strip()
        if not goal:
            raise AIAssistError("goal_required")
        if len(goal) > 4000:
            raise AIAssistError("goal_too_long")
        effective_model = self._resolve_model(model)
        user_prompt = self._build_user_prompt(goal, constraints)
        raw = self._complete(user_prompt, effective_model)
        manifest = self._parse_manifest(raw)
        self._validate(manifest)
        titled = self._apply_titles(goal, manifest)
        return {
            "manifest": manifest,
            "model": effective_model,
            "goal": goal,
            "constraints": constraints or {},
            "titled": titled,
            "title_model": self.gateway.title_model,
        }

    def _apply_titles(self, goal: str, manifest: dict[str, Any]) -> bool:
        """Give the run and its tasks human titles via the cheap title model.

        Run/task names drafted by a manifest model are slug-like and
        unreadable in lists. The title model renames the run and prepends a
        human title line to each task spec (so the title travels through
        spec excerpts everywhere). Titling NEVER blocks authoring: any
        failure keeps the drafted names. The mutated manifest is
        re-validated; if titles broke it, the original is restored.
        """
        original_name = manifest.get("run_name")
        original_specs = {id(t): t.get("spec") for t in manifest.get("tasks", []) if isinstance(t, dict)}
        tasks = [t for t in manifest.get("tasks", []) if isinstance(t, dict) and t.get("key")]
        keys = [t["key"] for t in tasks]
        prompt = (
            f"Goal: {goal}\n"
            f"Drafted run_name: {manifest.get('run_name')}\n"
            f"Task keys: {json.dumps(keys)}"
        )
        try:
            raw = self._complete(
                prompt, self.gateway.title_model,
                system_prompt=TITLE_SYSTEM_PROMPT, timeout_s=self.gateway.title_timeout_s,
            )
            titles = self._parse_manifest(raw)
            run_name = titles.get("run_name")
            task_titles = titles.get("task_titles")
            if not isinstance(run_name, str) or not run_name.strip() or len(run_name) > 80:
                return False
            if not isinstance(task_titles, dict):
                task_titles = {}
            manifest["run_name"] = run_name.strip()
            for task in tasks:
                title = task_titles.get(task["key"])
                if not isinstance(title, str) or not title.strip() or len(title) > 80:
                    continue
                # The manifest schema is strict (unknown task fields are
                # rejected), so the title travels as the spec's first line —
                # spec excerpts (spec_short) then lead with the human title.
                spec = str(task.get("spec") or "")
                if not spec.startswith("# "):
                    task["spec"] = f"# {title.strip()}\n\n{spec}"
            self._validate(manifest)
            return True
        except Exception:
            manifest["run_name"] = original_name
            for task in tasks:
                if id(task) in original_specs:
                    task["spec"] = original_specs[id(task)]
            return False

    def _resolve_model(self, model: str | None) -> str:
        """Return the caller-requested model or the configured default.

        The override is shape-validated only; an unknown-but-well-formed id is
        left for the gateway to reject (mapped to gateway_http_error), so the
        pickable set never goes stale when the gateway catalog changes.
        """
        if model is None:
            return self.gateway.model
        candidate = model.strip()
        if not candidate:
            return self.gateway.model
        if not _MODEL_RE.match(candidate):
            raise AIAssistError("model_invalid", "unsupported model id shape")
        return candidate

    def list_models(self) -> list[str]:
        """Fetch the gateway's available model ids (OpenAI ``/v1/models``)."""
        import urllib.error
        import urllib.request

        request = urllib.request.Request(
            f"{self.gateway.base_url}/v1/models",
            headers={"Authorization": f"Bearer {self.gateway.api_key}"},
            method="GET",
        )
        try:
            with urllib.request.urlopen(
                request, timeout=15.0, context=_ssl_context()
            ) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise AIAssistError("gateway_http_error", f"HTTP {exc.code}") from exc
        except urllib.error.URLError as exc:
            raise AIAssistError("gateway_unreachable", str(exc.reason)) from exc
        except (TimeoutError, OSError) as exc:
            raise AIAssistError("gateway_timeout", str(exc)) from exc
        data = payload.get("data") if isinstance(payload, dict) else None
        if not isinstance(data, list):
            raise AIAssistError("gateway_empty_response")
        return [m["id"] for m in data if isinstance(m, dict) and isinstance(m.get("id"), str)]

    def models_payload(self) -> dict[str, Any]:
        """Model list for the picker; the configured default is always present.

        A gateway listing failure degrades to just the default rather than an
        error, so the picker never blocks authoring.
        """
        try:
            models = [model for model in self.list_models() if is_chat_model(model)]
        except AIAssistError:
            models = []
        if self.gateway.model not in models:
            models.insert(0, self.gateway.model)
        return {"models": models, "default": self.gateway.model}

    def _build_user_prompt(self, goal: str, constraints: dict[str, Any] | None) -> str:
        parts = [f"Goal: {goal}"]
        if constraints:
            allowed = {"project", "engine", "max_tasks", "workdir_root", "task_type"}
            extras = {k: v for k, v in constraints.items() if k in allowed and v}
            if extras:
                parts.append("Constraints: " + json.dumps(extras))
        return "\n".join(parts)

    def _complete(
        self,
        user_prompt: str,
        model: str,
        *,
        system_prompt: str = SYSTEM_PROMPT,
        timeout_s: float | None = None,
    ) -> str:
        import urllib.error
        import urllib.request

        request_body: dict[str, Any] = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }
        if self.gateway.temperature is not None:
            request_body["temperature"] = self.gateway.temperature
        body = json.dumps(request_body).encode("utf-8")
        request = urllib.request.Request(
            f"{self.gateway.base_url}/v1/chat/completions",
            data=body,
            headers={
                "Authorization": f"Bearer {self.gateway.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(
                request, timeout=timeout_s or self.gateway.timeout_s, context=_ssl_context()
            ) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raise AIAssistError("gateway_http_error", _http_error_detail(exc)) from exc
        except urllib.error.URLError as exc:
            raise AIAssistError("gateway_unreachable", str(exc.reason)) from exc
        except (TimeoutError, OSError) as exc:
            raise AIAssistError("gateway_timeout", str(exc)) from exc
        choices = payload.get("choices") if isinstance(payload, dict) else None
        if not isinstance(choices, list) or not choices:
            raise AIAssistError("gateway_empty_response")
        message = choices[0].get("message", {}) if isinstance(choices[0], dict) else {}
        content = message.get("content") if isinstance(message, dict) else None
        if not isinstance(content, str) or not content.strip():
            raise AIAssistError("gateway_empty_response")
        return content

    def _parse_manifest(self, content: str) -> dict[str, Any]:
        text = content.strip()
        if text.startswith("```"):
            text = text.strip("`")
            if text.lower().startswith("json"):
                text = text[4:]
            text = text.strip()
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            raise AIAssistError("manifest_not_json", str(exc)) from exc
        if not isinstance(value, dict):
            raise AIAssistError("manifest_not_object")
        return value

    def _validate(self, manifest: dict[str, Any]) -> None:
        try:
            Manifest.from_obj(manifest)
        except Exception as exc:
            raise AIAssistError("manifest_invalid", str(exc)) from exc
