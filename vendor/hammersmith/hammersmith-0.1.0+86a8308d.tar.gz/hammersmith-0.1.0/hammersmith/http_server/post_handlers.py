"""Strict JSON mutation routing for the local Hammersmith control plane."""

from __future__ import annotations

import json
import subprocess
import sys
import urllib.parse
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from typing import Any, TYPE_CHECKING
from pathlib import Path

from hammersmith.control_plane.adjudications import AdjudicationConflict, AdjudicationStore
from hammersmith.control_plane.ai_assist import AIAssistError, AIAssistService
from hammersmith.control_plane.drafts import DraftConflict, DraftNotFound, DraftStore
from hammersmith.control_plane.paths import PathCapability
from hammersmith.control_plane.runs import RunConflict, RunService
from hammersmith.control_plane.validation import PlanConflict, ValidationService

from .responses import send_json_response

if TYPE_CHECKING:
    from hammersmith.auth import AuthManager
    from .auth_middleware import AuthMiddleware

MAX_JSON_BYTES = 64 * 1024


@dataclass
class ControlPlaneHandlers:
    validation: ValidationService
    drafts: DraftStore
    runs: RunService
    adjudications: AdjudicationStore
    paths: PathCapability
    state_dir: Path
    ai_assist: AIAssistService | None = None


class RequestError(ValueError):
    def __init__(self, status: HTTPStatus, code: str) -> None:
        super().__init__(code)
        self.status = status
        self.code = code


def _read_json(handler: BaseHTTPRequestHandler) -> dict[str, Any]:
    content_type = handler.headers.get("Content-Type", "").split(";", 1)[0].strip().casefold()
    if content_type != "application/json":
        raise RequestError(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "json_content_type_required")
    if handler.headers.get("Transfer-Encoding"):
        raise RequestError(HTTPStatus.BAD_REQUEST, "transfer_encoding_not_supported")
    values = handler.headers.get_all("Content-Length", [])
    if len(values) != 1:
        raise RequestError(HTTPStatus.LENGTH_REQUIRED, "content_length_required")
    try:
        length = int(values[0])
    except (TypeError, ValueError, OverflowError) as exc:
        raise RequestError(HTTPStatus.BAD_REQUEST, "invalid_content_length") from exc
    if length < 0:
        raise RequestError(HTTPStatus.BAD_REQUEST, "invalid_content_length")
    if length > MAX_JSON_BYTES:
        raise RequestError(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "request_body_too_large")
    try:
        value = json.loads(handler.rfile.read(length))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise RequestError(HTTPStatus.BAD_REQUEST, "invalid_json") from exc
    if not isinstance(value, dict):
        raise RequestError(HTTPStatus.BAD_REQUEST, "json_object_required")
    return value


def _strict(data: dict[str, Any], required: set[str], optional: set[str] = frozenset()) -> None:
    unknown = set(data) - required - optional
    if unknown:
        raise RequestError(HTTPStatus.BAD_REQUEST, "unknown_request_field")
    if not required.issubset(data):
        raise RequestError(HTTPStatus.BAD_REQUEST, "missing_request_field")


def _error(
    handler: BaseHTTPRequestHandler,
    status: HTTPStatus,
    code: str,
    message: str | None = None,
    **extra: Any,
) -> None:
    send_json_response(
        handler,
        {"error": {"code": code, "message": message or code.replace("_", " ")}, **extra},
        status=status,
    )


def handle_auth_login(
    handler: BaseHTTPRequestHandler,
    auth_manager: AuthManager,
    auth_middleware: AuthMiddleware,
) -> None:
    if not auth_middleware.require_origin(handler):
        return
    if not auth_middleware.allowed_login_attempt(handler):
        _error(handler, HTTPStatus.TOO_MANY_REQUESTS, "login_rate_limited")
        return
    try:
        data = _read_json(handler)
        _strict(data, {"username", "password"})
        if not isinstance(data["username"], str) or not isinstance(data["password"], str):
            raise RequestError(HTTPStatus.BAD_REQUEST, "invalid_credentials_schema")
        if len(data["username"]) > 128 or len(data["password"]) > 1024:
            raise RequestError(HTTPStatus.BAD_REQUEST, "credentials_too_large")
    except RequestError as exc:
        _error(handler, exc.status, exc.code)
        return
    if not auth_manager.has_admin():
        _error(handler, HTTPStatus.FORBIDDEN, "no_admin_configured")
        return
    try:
        token = auth_manager.authenticate(data["username"], data["password"])
    except Exception:
        token = None
    if token is None:
        _error(handler, HTTPStatus.UNAUTHORIZED, "invalid_credentials")
        return
    body = {"success": True}
    encoded = json.dumps(body, sort_keys=True).encode()
    handler.send_response(HTTPStatus.OK)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Set-Cookie", f"session={token}; Path=/; HttpOnly; SameSite=Strict")
    handler.send_header("Content-Length", str(len(encoded)))
    handler.end_headers()
    handler.wfile.write(encoded)


def _draft_id(path: str) -> str | None:
    prefix = "/api/drafts/"
    return urllib.parse.unquote(path[len(prefix):]) if path.startswith(prefix) else None


def _run_action_parts(path: str) -> list[str]:
    return [urllib.parse.unquote(item) for item in path.strip("/").split("/")]


def handle_post_request(
    handler: BaseHTTPRequestHandler,
    auth_manager: AuthManager,
    auth_middleware: AuthMiddleware,
    control: ControlPlaneHandlers | None = None,
) -> None:
    path = urllib.parse.urlparse(handler.path).path
    method = handler.command.upper()
    if path == "/api/auth/login" and method == "POST":
        handle_auth_login(handler, auth_manager, auth_middleware)
        return
    if path == "/api/auth/me" and method == "POST":
        if auth_middleware.require_valid_host(handler) and auth_middleware.require_auth(handler):
            actor, role = auth_middleware.actor(handler)
            send_json_response(handler, {"username": actor, "role": role})
        return
    if control is None:
        handler.send_error(HTTPStatus.NOT_FOUND)
        return
    roles = {"viewer", "user", "admin"} if path == "/api/auth/logout" else {"user", "admin"}
    if not auth_middleware.require_mutation(handler, roles=roles):
        return
    actor, role = auth_middleware.actor(handler)
    admin = role == "admin"
    try:
        data = _read_json(handler)
        if path == "/api/auth/logout" and method == "POST":
            _strict(data, set())
            token = auth_middleware.get_session_token(handler)
            if token:
                auth_manager.logout(token)
            send_json_response(handler, {"success": True})
            return
        if path == "/api/drafts" and method == "POST":
            _strict(data, {"manifest"})
            if not isinstance(data["manifest"], dict):
                raise RequestError(HTTPStatus.BAD_REQUEST, "manifest_object_required")
            send_json_response(handler, control.drafts.create(data["manifest"], owner=actor), status=HTTPStatus.CREATED)
            return
        draft_id = _draft_id(path)
        if draft_id is not None and method == "PUT":
            _strict(data, {"manifest", "revision"})
            send_json_response(
                handler,
                control.drafts.update(
                    draft_id, data["manifest"], revision=data["revision"], actor=actor, admin=admin
                ),
            )
            return
        if draft_id is not None and method == "DELETE":
            _strict(data, {"revision"})
            send_json_response(
                handler,
                control.drafts.delete(draft_id, revision=data["revision"], actor=actor, admin=admin),
            )
            return
        if path == "/api/manifests/validate" and method == "POST":
            _strict(data, {"manifest"})
            send_json_response(handler, control.validation.validate(data["manifest"], actor=actor))
            return
        if path == "/api/ai/author-manifest" and method == "POST":
            if control.ai_assist is None:
                _error(handler, HTTPStatus.SERVICE_UNAVAILABLE, "ai_assist_not_configured")
                return
            _strict(data, {"goal"}, {"constraints", "model"})
            constraints = data.get("constraints")
            if constraints is not None and not isinstance(constraints, dict):
                raise RequestError(HTTPStatus.BAD_REQUEST, "constraints_object_required")
            model = data.get("model")
            if model is not None and not isinstance(model, str):
                raise RequestError(HTTPStatus.BAD_REQUEST, "model_string_required")
            try:
                result = control.ai_assist.author(data["goal"], constraints=constraints, model=model)
            except AIAssistError as exc:
                if exc.code == "gateway_timeout":
                    status = HTTPStatus.GATEWAY_TIMEOUT
                elif exc.code.startswith("gateway_"):
                    status = HTTPStatus.BAD_GATEWAY
                else:
                    status = HTTPStatus.BAD_REQUEST
                _error(handler, status, exc.code, message=exc.detail or None, detail=exc.detail)
                return
            send_json_response(handler, result, status=HTTPStatus.CREATED)
            return
        if path == "/api/runs" and method == "POST":
            _strict(data, {"validated_plan_id", "digest", "confirmation"})
            receipt = control.runs.launch(
                plan_id=data["validated_plan_id"],
                digest=data["digest"],
                confirmation=data["confirmation"],
                idempotency_key=handler.headers.get("Idempotency-Key", ""),
                actor=actor,
                admin=admin,
            )
            send_json_response(handler, receipt, status=HTTPStatus.ACCEPTED)
            return
        parts = _run_action_parts(path)
        if len(parts) == 4 and parts[:2] == ["api", "runs"] and parts[3] == "cancel" and method == "POST":
            _strict(data, {"confirmation"})
            receipt = control.runs.cancel(
                parts[2],
                confirmation=data["confirmation"],
                idempotency_key=handler.headers.get("Idempotency-Key", ""),
                actor=actor,
                admin=admin,
            )
            send_json_response(handler, receipt, status=HTTPStatus.ACCEPTED)
            return
        if (
            len(parts) == 4 and parts[:2] == ["api", "runs"]
            and parts[3] == "replay-draft" and method == "POST"
        ):
            _strict(data, {"kind", "confirmation"})
            draft = control.runs.replay_draft(
                parts[2],
                drafts=control.drafts,
                kind=data["kind"],
                confirmation=data["confirmation"],
                idempotency_key=handler.headers.get("Idempotency-Key", ""),
                actor=actor,
                admin=admin,
            )
            send_json_response(handler, draft, status=HTTPStatus.CREATED)
            return
        if (
            len(parts) == 6 and parts[:2] == ["api", "runs"]
            and parts[3] == "tasks" and parts[5] == "adjudications" and method == "POST"
        ):
            _strict(data, {"outcome", "reason"})
            owner = control.runs.owner_for_run(parts[2])
            if not admin and owner != actor:
                raise RunConflict("adjudication is unavailable for this actor")
            receipt = control.adjudications.append(
                run_id=parts[2], task_key=parts[4], outcome=data["outcome"], reason=data["reason"],
                actor=actor, idempotency_key=handler.headers.get("Idempotency-Key", ""),
            )
            send_json_response(handler, receipt, status=HTTPStatus.CREATED)
            return
        if path == "/api/open-folder" and method == "POST":
            _strict(data, set(), {"run_id"})
            run_id = data.get("run_id", "")
            if run_id and not admin and control.runs.owner_for_run(run_id) != actor:
                raise RunConflict("folder action is unavailable for this actor")
            relative = "artifacts"
            if run_id:
                relative = f"artifacts/deliverables/{run_id}"
            target = control.paths.resolve_relative(control.state_dir, relative)
            if target is None or not target.is_dir():
                raise DraftNotFound("folder not found")
            if sys.platform != "darwin":
                _error(handler, HTTPStatus.NOT_IMPLEMENTED, "folder_open_not_supported")
                return
            try:
                subprocess.Popen(
                    ["open", str(target)],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            except OSError:
                _error(handler, HTTPStatus.SERVICE_UNAVAILABLE, "folder_open_failed")
                return
            send_json_response(handler, {"opened": True})
            return
    except RequestError as exc:
        _error(handler, exc.status, exc.code)
        return
    except DraftNotFound:
        _error(handler, HTTPStatus.NOT_FOUND, "not_found")
        return
    except DraftConflict as exc:
        _error(
            handler,
            HTTPStatus.CONFLICT,
            "stale_revision",
            current=exc.current or {},
        )
        return
    except (RunConflict, AdjudicationConflict, PlanConflict) as exc:
        code = "conflict"
        message = str(exc)
        if "stale" in message:
            code = "stale_revision"
        elif "expired" in message:
            code = "plan_expired"
        elif "digest" in message:
            code = "digest_mismatch"
        elif "unowned" in message or "owner handle" in message:
            code = "cancel_unavailable"
        _error(handler, HTTPStatus.CONFLICT, code)
        return
    except (TypeError, ValueError, OverflowError):
        _error(handler, HTTPStatus.BAD_REQUEST, "invalid_request")
        return
    handler.send_error(HTTPStatus.NOT_FOUND)
